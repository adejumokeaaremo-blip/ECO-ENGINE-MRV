/**
 * ECO ENGINE — lightweight demo store (design.md §10).
 * React external store + localStorage persistence. Holds facilities, monitoring
 * plans, submissions/uploads, DQI scores, hash-chained audit trail, demo settings.
 * Page agents: consume via the exported hooks/actions, never redefine data.
 */
import { useSyncExternalStore } from 'react'
import {
  FACILITIES,
  PERSONAS,
  VERIFICATION_QUEUE_SEED,
  DEMO_TODAY,
  type Facility,
  type Persona,
  type VerificationStatus,
} from './demo-data'

/* ---------------------------------------------------------------- types */

export type Role = Persona['role']

export interface MonitoringPlanVersion {
  version: string
  status: 'Draft' | 'Submitted' | 'Approved'
  approvedOn: string | null
  note: string
}

export interface MonitoringPlan {
  facilityId: string
  currentVersion: string
  versions: MonitoringPlanVersion[]
}

export interface ValidationResult {
  check: string
  result: 'pass' | 'warn' | 'fail'
  detail: string
}

export interface Submission {
  id: string
  facilityId: string
  streamLabel: string
  period: string
  activityValue: string
  aiEstimate: string
  uncertainty: string
  flag: string | null
  status: VerificationStatus
  note: string
  submittedBy: string
  submittedAt: string
  validation: ValidationResult[]
  verifiedBy: string | null
  verifiedAt: string | null
  verificationComment: string | null
}

export interface AuditEntry {
  seq: number
  ts: string
  actor: string
  role: Role | 'system'
  action: string
  entity: string
  detail: string
  prevHash: string
  hash: string
}

export interface DemoSettings {
  role: Role
  tourSeen: Partial<Record<Role, boolean>>
  watermark: boolean
}

export interface StoreState {
  facilities: Facility[]
  plans: MonitoringPlan[]
  submissions: Submission[]
  audit: AuditEntry[] // chronological, oldest first
  settings: DemoSettings
}

/* ------------------------------------------------- hash chain (demo-grade) */

/** Synchronous sha-256-style digest (cyrb53-based; demonstrator use only). */
export function demoHash(input: string): string {
  let h1 = 0xdeadbeef ^ 0x9f2c
  let h2 = 0x41c6ce57 ^ 0xe41a
  let out = ''
  // stretch the input so long payloads still fold in deterministically
  const s = input + '·ECO-ENGINE·' + input.length
  for (let round = 0; round < 5; round++) {
    for (let i = 0; i < s.length; i++) {
      const ch = s.charCodeAt(i)
      h1 = Math.imul(h1 ^ ch, 2654435761 + round)
      h2 = Math.imul(h2 ^ ch, 1597334677 + round)
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909)
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909)
    out +=
      (h2 >>> 0).toString(16).padStart(8, '0') + (h1 >>> 0).toString(16).padStart(8, '0')
  }
  return '0x' + out.slice(0, 40)
}

export function truncateHash(hash: string): string {
  if (hash.length <= 14) return hash
  return `${hash.slice(0, 6)}…${hash.slice(-4)}`
}

/* ------------------------------------------------------------------ seed */

const GENESIS = '0x0000000000000000000000000000000000000000'

function seedAudit(): AuditEntry[] {
  const raw: Array<Omit<AuditEntry, 'seq' | 'prevHash' | 'hash'>> = [
    {
      ts: '2025-08-14T10:22:00Z',
      actor: 'A. Bello',
      role: 'regulator',
      action: 'FACILITY_APPROVED',
      entity: 'FAC-RIV-004',
      detail: 'NigerDelta Flow Station 4 onboarding approved',
    },
    {
      ts: '2025-09-19T09:05:00Z',
      actor: 'A. Bello',
      role: 'regulator',
      action: 'FACILITY_APPROVED',
      entity: 'FAC-KOG-002',
      detail: 'Sahel Cement Works, Line 2 onboarding approved · monitoring plan v1.0 approved',
    },
    {
      ts: '2026-06-02T14:41:00Z',
      actor: 'Engr. T. Wokoma',
      role: 'operator',
      action: 'PLAN_VERSION_APPROVED',
      entity: 'FAC-RIV-004',
      detail: 'Monitoring plan v1.2 approved (3 streams)',
    },
    {
      ts: '2026-04-15T08:12:00Z',
      actor: 'Engr. T. Wokoma',
      role: 'operator',
      action: 'UPLOAD_SUBMITTED',
      entity: 'SUB-2606-114',
      detail: 'Flaring — March 2026 · 3.05 MMscf/d · evidence hashed (meter export FL-201)',
    },
    {
      ts: '2026-04-15T08:12:04Z',
      actor: 'ECO ENGINE',
      role: 'system',
      action: 'AI_ESTIMATE_GENERATED',
      entity: 'SUB-2606-114',
      detail: '5,614 tCO2e ±8% · GGFR/IPCC 2006 factor · flag: intensity shift +45%',
    },
    {
      ts: '2026-03-15T11:30:00Z',
      actor: 'Engr. T. Wokoma',
      role: 'operator',
      action: 'UPLOAD_SUBMITTED',
      entity: 'SUB-2606-118',
      detail: 'Clinker — February 2026 · 118,432.00 t · belt scale BS-22 export',
    },
    {
      ts: '2026-03-15T11:30:05Z',
      actor: 'ECO ENGINE',
      role: 'system',
      action: 'AI_ESTIMATE_GENERATED',
      entity: 'SUB-2606-118',
      detail: '61,585 tCO2e ±5% · flag: repeated identical values',
    },
    {
      ts: '2026-03-16T09:18:00Z',
      actor: 'Dr. F. Okafor',
      role: 'verifier',
      action: 'SUBMISSION_QUERIED',
      entity: 'SUB-2606-118',
      detail: 'Queried — verifier requested belt-scale raw logs',
    },
    {
      ts: '2026-07-15T07:45:00Z',
      actor: 'Engr. T. Wokoma',
      role: 'operator',
      action: 'UPLOAD_SUBMITTED',
      entity: 'SUB-2607-003',
      detail: 'Fuel gas — June 2026 · 1.42 MMscf/d',
    },
    {
      ts: '2026-07-15T07:45:03Z',
      actor: 'ECO ENGINE',
      role: 'system',
      action: 'AI_ESTIMATE_GENERATED',
      entity: 'SUB-2607-003',
      detail: '2,602 tCO2e ±6% · no flags',
    },
    {
      ts: '2026-07-15T08:02:00Z',
      actor: 'Engr. T. Wokoma',
      role: 'operator',
      action: 'UPLOAD_SUBMITTED',
      entity: 'SUB-2607-007',
      detail: 'Petcoke — June 2026 · 9,588 t',
    },
    {
      ts: '2026-07-15T08:02:04Z',
      actor: 'ECO ENGINE',
      role: 'system',
      action: 'AI_ESTIMATE_GENERATED',
      entity: 'SUB-2607-007',
      detail: '28,417 tCO2e ±7% · flag: peer deviation (borderline)',
    },
    {
      ts: '2026-07-15T09:00:00Z',
      actor: 'Dr. F. Okafor',
      role: 'verifier',
      action: 'LOGIN',
      entity: 'session',
      detail: 'Verifier signed in (demo session)',
    },
  ]
  let prev = GENESIS
  return raw.map((e, i) => {
    const hash = demoHash(`${prev}|${e.ts}|${e.actor}|${e.action}|${e.entity}|${e.detail}`)
    const entry: AuditEntry = { seq: i + 1, ...e, prevHash: prev, hash }
    prev = hash
    return entry
  })
}

function seedSubmissions(): Submission[] {
  const by: Record<string, Partial<Submission>> = {
    'SUB-2606-114': {
      submittedBy: 'Engr. T. Wokoma',
      submittedAt: '2026-04-15T08:12:00Z',
      validation: [
        { check: 'schema', result: 'pass', detail: 'All required fields present' },
        { check: 'units', result: 'pass', detail: 'MMscf/d matches plan stream S1' },
        { check: 'range', result: 'warn', detail: '3.05 MMscf/d > +30% of trailing 6-month mean' },
        { check: 'duplicates', result: 'pass', detail: 'No duplicate period' },
      ],
    },
    'SUB-2606-118': {
      submittedBy: 'Engr. T. Wokoma',
      submittedAt: '2026-03-15T11:30:00Z',
      verifiedBy: null,
      verificationComment: 'Please attach belt-scale BS-22 raw logs for February.',
      validation: [
        { check: 'schema', result: 'pass', detail: 'All required fields present' },
        { check: 'units', result: 'pass', detail: 't/month matches plan stream S1' },
        { check: 'range', result: 'pass', detail: 'Within expected band' },
        { check: 'duplicates', result: 'warn', detail: 'Identical to January 2026 to the decimal' },
      ],
    },
    'SUB-2607-003': {
      submittedBy: 'Engr. T. Wokoma',
      submittedAt: '2026-07-15T07:45:00Z',
      validation: [
        { check: 'schema', result: 'pass', detail: 'All required fields present' },
        { check: 'units', result: 'pass', detail: 'MMscf/d matches plan stream S2' },
        { check: 'range', result: 'pass', detail: 'Within expected band' },
        { check: 'duplicates', result: 'pass', detail: 'No duplicate period' },
      ],
    },
    'SUB-2607-007': {
      submittedBy: 'Engr. T. Wokoma',
      submittedAt: '2026-07-15T08:02:00Z',
      validation: [
        { check: 'schema', result: 'pass', detail: 'All required fields present' },
        { check: 'units', result: 'pass', detail: 't/month matches plan stream S2' },
        { check: 'range', result: 'warn', detail: 'Borderline peer deviation (> 2σ, marginal)' },
        { check: 'duplicates', result: 'pass', detail: 'No duplicate period' },
      ],
    },
  }
  return VERIFICATION_QUEUE_SEED.map((q): Submission => {
    const e = by[q.id]
    return {
      ...q,
      submittedBy: e?.submittedBy ?? 'Engr. T. Wokoma',
      submittedAt: e?.submittedAt ?? `${DEMO_TODAY}T08:00:00Z`,
      validation: e?.validation ?? [],
      verifiedBy: e?.verifiedBy ?? null,
      verifiedAt: e?.verifiedAt ?? null,
      verificationComment: e?.verificationComment ?? null,
    }
  })
}

function seedState(): StoreState {
  return {
    facilities: FACILITIES,
    plans: FACILITIES.map((f) => ({
      facilityId: f.id,
      currentVersion: f.plan.version,
      versions: [
        {
          version: f.plan.version,
          status: 'Approved',
          approvedOn: f.plan.approvedOn,
          note: `${f.streams.length} streams · approved ${f.plan.approvedOn}`,
        },
        ...(f.id === 'FAC-RIV-004'
          ? [
              {
                version: 'v1.1',
                status: 'Approved' as const,
                approvedOn: '14 Aug 2025',
                note: 'Initial approved plan',
              },
              {
                version: 'v1.3',
                status: 'Draft' as const,
                approvedOn: null,
                note: 'Draft — adds biogas pilot stream (not yet submitted)',
              },
            ]
          : []),
      ],
    })),
    submissions: seedSubmissions(),
    audit: seedAudit(),
    settings: { role: 'operator', tourSeen: {}, watermark: true },
  }
}

/* ----------------------------------------------------------------- store */

const STORAGE_KEY = 'ecoengine-demo-v1'
const listeners = new Set<() => void>()

function load(): StoreState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw) {
      const parsed = JSON.parse(raw) as StoreState
      if (parsed && Array.isArray(parsed.audit) && parsed.audit.length > 0) return parsed
    }
  } catch {
    /* corrupted storage → reseed */
  }
  return seedState()
}

let state: StoreState = load()

function persist() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
  } catch {
    /* storage unavailable — demonstrator continues in-memory */
  }
}

function setState(next: StoreState) {
  state = next
  persist()
  listeners.forEach((l) => l())
}

function subscribe(fn: () => void) {
  listeners.add(fn)
  return () => listeners.delete(fn)
}

function getSnapshot(): StoreState {
  return state
}

/** Select a stable slice of the store. */
export function useStore<T>(selector: (s: StoreState) => T): T {
  return useSyncExternalStore(subscribe, () => selector(getSnapshot()))
}

/* ----------------------------------------------------------------- hooks */

export function useFacilities(): Facility[] {
  return useStore((s) => s.facilities)
}

export function useSubmissions(): Submission[] {
  return useStore((s) => s.submissions)
}

export function useAuditTrail(): AuditEntry[] {
  return useStore((s) => s.audit)
}

export interface DqiScore {
  facilityId: string
  facilityName: string
  dqi: number
  trend: { from: number; to: number }
}

let dqiCache: { src: Facility[]; out: DqiScore[] } | null = null
function dqiOf(facilities: Facility[]): DqiScore[] {
  if (!dqiCache || dqiCache.src !== facilities) {
    dqiCache = {
      src: facilities,
      out: facilities.map((f) => ({
        facilityId: f.id,
        facilityName: f.name,
        dqi: f.dqi,
        trend: f.dqiTrend,
      })),
    }
  }
  return dqiCache.out
}

export function useDqi(): DqiScore[] {
  return useStore((s) => dqiOf(s.facilities))
}

export function usePlans(): MonitoringPlan[] {
  return useStore((s) => s.plans)
}

export function useRole(): {
  role: Role
  persona: Persona
  setRole: (r: Role) => void
  tourSeen: Partial<Record<Role, boolean>>
  markTourSeen: (r: Role) => void
} {
  const role = useStore((s) => s.settings.role)
  const tourSeen = useStore((s) => s.settings.tourSeen)
  const persona = PERSONAS.find((p) => p.role === role) ?? PERSONAS[0]
  return {
    role,
    persona,
    tourSeen,
    setRole: (r) => setState({ ...state, settings: { ...state.settings, role: r } }),
    markTourSeen: (r) =>
      setState({
        ...state,
        settings: { ...state.settings, tourSeen: { ...state.settings.tourSeen, [r]: true } },
      }),
  }
}

/* ---------------------------------------------------------------- actions */

function nowIso(): string {
  // Demonstrator "today" is pinned to 15 July 2026; keep wall-clock time.
  const t = new Date()
  const hh = String(t.getHours()).padStart(2, '0')
  const mm = String(t.getMinutes()).padStart(2, '0')
  const ss = String(t.getSeconds()).padStart(2, '0')
  return `${DEMO_TODAY}T${hh}:${mm}:${ss}Z`
}

export function appendAudit(input: {
  actor: string
  role: Role | 'system'
  action: string
  entity: string
  detail: string
}): AuditEntry {
  const prevEntry = state.audit[state.audit.length - 1]
  const prevHash = prevEntry ? prevEntry.hash : GENESIS
  const ts = nowIso()
  const hash = demoHash(
    `${prevHash}|${ts}|${input.actor}|${input.action}|${input.entity}|${input.detail}`,
  )
  const entry: AuditEntry = {
    seq: (prevEntry?.seq ?? 0) + 1,
    ts,
    ...input,
    prevHash,
    hash,
  }
  setState({ ...state, audit: [...state.audit, entry] })
  return entry
}

let uploadCounter = 8
export function submitUpload(input: {
  facilityId: string
  streamLabel: string
  period: string
  activityValue: string
  aiEstimate: string
  uncertainty: string
  flag?: string | null
}): Submission {
  uploadCounter += 1
  const id = `SUB-2607-${String(uploadCounter).padStart(3, '0')}`
  const persona = PERSONAS.find((p) => p.role === state.settings.role) ?? PERSONAS[0]
  const sub: Submission = {
    id,
    facilityId: input.facilityId,
    streamLabel: input.streamLabel,
    period: input.period,
    activityValue: input.activityValue,
    aiEstimate: input.aiEstimate,
    uncertainty: input.uncertainty,
    flag: input.flag ?? null,
    status: 'Pending',
    note: '',
    submittedBy: persona.name,
    submittedAt: nowIso(),
    validation: [
      { check: 'schema', result: 'pass', detail: 'All required fields present' },
      { check: 'units', result: 'pass', detail: 'Unit matches monitoring plan stream' },
      {
        check: 'range',
        result: input.flag ? 'warn' : 'pass',
        detail: input.flag ? `Flag: ${input.flag}` : 'Within expected band',
      },
      { check: 'duplicates', result: 'pass', detail: 'No duplicate period' },
    ],
    verifiedBy: null,
    verifiedAt: null,
    verificationComment: null,
  }
  setState({ ...state, submissions: [sub, ...state.submissions] })
  appendAudit({
    actor: persona.name,
    role: state.settings.role,
    action: 'UPLOAD_SUBMITTED',
    entity: id,
    detail: `${input.streamLabel} — ${input.period} · ${input.activityValue}`,
  })
  appendAudit({
    actor: 'ECO ENGINE',
    role: 'system',
    action: 'AI_ESTIMATE_GENERATED',
    entity: id,
    detail: `${input.aiEstimate} ${input.uncertainty}${input.flag ? ` · flag: ${input.flag}` : ' · no flags'}`,
  })
  return sub
}

export function verifySubmission(
  id: string,
  action: 'Accepted' | 'Queried' | 'Rejected',
  comment: string,
): Submission | null {
  const verifier = PERSONAS.find((p) => p.role === 'verifier') ?? PERSONAS[1]
  const sub = state.submissions.find((s) => s.id === id)
  if (!sub) return null
  const ts = nowIso()
  const updated: Submission = {
    ...sub,
    status: action,
    verifiedBy: verifier.name,
    verifiedAt: ts,
    verificationComment: comment || null,
  }
  setState({
    ...state,
    submissions: state.submissions.map((s) => (s.id === id ? updated : s)),
  })
  appendAudit({
    actor: verifier.name,
    role: 'verifier',
    action:
      action === 'Accepted'
        ? 'SUBMISSION_ACCEPTED'
        : action === 'Rejected'
          ? 'SUBMISSION_REJECTED'
          : 'SUBMISSION_QUERIED',
    entity: id,
    detail: comment ? `${action} — ${comment}` : `${action}`,
  })
  return updated
}

export function resetDemo(): void {
  try {
    localStorage.removeItem(STORAGE_KEY)
  } catch {
    /* ignore */
  }
  uploadCounter = 8
  setState(seedState())
}

/** Recompute the chain from genesis; returns the first broken seq or null. */
export function verifyChain(entries: AuditEntry[] = state.audit): number | null {
  let prev = GENESIS
  for (const e of entries) {
    const hash = demoHash(`${prev}|${e.ts}|${e.actor}|${e.action}|${e.entity}|${e.detail}`)
    if (e.prevHash !== prev || e.hash !== hash) return e.seq
    prev = e.hash
  }
  return null
}
