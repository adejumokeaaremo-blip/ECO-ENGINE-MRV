/**
 * ECO ENGINE — Demo Data Constants (design.md §8 — single source of truth).
 * Page agents: import from here, never redefine.
 */

export const DEMO_TODAY = '2026-07-15' // 15 July 2026
export const REPORTING_RULE =
  'Reporting deadline: 15th of the following month — June 2026 reports are due today.'

export const COMPANY = {
  name: 'ECO-ENGINE MRV SYSTEM COMPANY LTD',
  rc: 'RC 9666441',
  incorporated: '8 July 2026',
  city: 'Abuja, FCT',
  email: 'hello@ecoengine.ng (demo)',
  address: '4th Floor, Rivers House, Central Business District, Abuja (demo address)',
} as const

export type StreamMethod = 'metered' | 'estimated'

export interface Stream {
  id: string
  label: string
  unit: string
  method: string
  meter: string
  calibrationDue: string | null
  tier: 'Tier 1' | 'Tier 2' | 'Tier 3'
  frequency: 'monthly'
  ipccCategory: string
}

export interface MonthPoint {
  month: string // e.g. 'Jul 2025'
  value: number
}

export interface Facility {
  id: string // FAC-RIV-004
  name: string
  operatorOrg: string
  sector: string
  lga: string
  state: string
  coords: { lat: number; lon: number }
  status: 'Draft' | 'Submitted' | 'Approved'
  approvedOn: string
  permits: string[]
  units: string[]
  plan: { version: string; approvedOn: string }
  streams: Stream[]
  baselineNote: string
  anomalyNote: string
  dqi: number
  dqiTrend: { from: number; to: number }
  verifiedYtd: number // tCO2e
  historyLabel: string
  history: MonthPoint[] // primary stream 12-month history
}

export const FACILITIES: Facility[] = [
  {
    id: 'FAC-RIV-004',
    name: 'NigerDelta Flow Station 4',
    operatorOrg: 'Delta Crest Energy Ltd (demo)',
    sector: 'Oil & Gas (upstream)',
    lga: 'Ahoada East LGA',
    state: 'Rivers State',
    coords: { lat: 4.8812, lon: 6.6478 }, // demo coordinates
    status: 'Approved',
    approvedOn: '14 Aug 2025',
    permits: [
      'NUPRC operating licence OL/2024/118 (demo)',
      'NMDPRA permit P/2025/0342 (demo)',
      'NESREA effluent permit EA/RIV/2211 (demo)',
    ],
    units: ['Flaring stack FL-01', 'Gas engine gensets GE-01…GE-03', 'Diesel standby gensets DG-01/02'],
    plan: { version: 'v1.2', approvedOn: '02 Jun 2026' },
    streams: [
      {
        id: 'S1',
        label: 'Associated gas flared',
        unit: 'MMscf/d',
        method: 'metered',
        meter: 'ultrasonic meter FL-201',
        calibrationDue: '15 Sep 2026',
        tier: 'Tier 2',
        frequency: 'monthly',
        ipccCategory: '1.B.2 Oil & Natural Gas',
      },
      {
        id: 'S2',
        label: 'Fuel gas consumed',
        unit: 'MMscf/d',
        method: 'metered',
        meter: 'meter FG-104',
        calibrationDue: '02 Nov 2026',
        tier: 'Tier 2',
        frequency: 'monthly',
        ipccCategory: '1.A.1 Energy Industries',
      },
      {
        id: 'S3',
        label: 'Diesel consumed (gensets)',
        unit: 'litres/month',
        method: 'estimated from delivery records',
        meter: 'delivery records',
        calibrationDue: null,
        tier: 'Tier 1',
        frequency: 'monthly',
        ipccCategory: '1.A.1 Energy Industries',
      },
    ],
    baselineNote: 'flaring baseline ≈ 2.1 MMscf/d',
    anomalyNote:
      'March 2026 = 3.05 MMscf/d (+45%) → anomaly flag "implausible intensity shift" (the queue item the verifier accepts in the demo script)',
    dqi: 86,
    dqiTrend: { from: 82, to: 86 },
    verifiedYtd: 386400,
    historyLabel: 'Associated gas flared (MMscf/d), Jul 2025 – Jun 2026',
    history: [
      { month: 'Jul 2025', value: 2.08 },
      { month: 'Aug 2025', value: 2.12 },
      { month: 'Sep 2025', value: 2.05 },
      { month: 'Oct 2025', value: 2.14 },
      { month: 'Nov 2025', value: 2.09 },
      { month: 'Dec 2025', value: 2.16 },
      { month: 'Jan 2026', value: 2.11 },
      { month: 'Feb 2026', value: 2.07 },
      { month: 'Mar 2026', value: 3.05 }, // anomaly: implausible intensity shift +45%
      { month: 'Apr 2026', value: 2.13 },
      { month: 'May 2026', value: 2.08 },
      { month: 'Jun 2026', value: 2.04 },
    ],
  },
  {
    id: 'FAC-KOG-002',
    name: 'Sahel Cement Works, Line 2',
    operatorOrg: 'Sahel Cement Company Ltd (demo)',
    sector: 'Cement',
    lga: 'Obajana',
    state: 'Kogi State',
    coords: { lat: 7.9131, lon: 6.4381 }, // demo
    status: 'Approved',
    approvedOn: '19 Sep 2025',
    permits: ['NESREA permit EA/KOG/0987 (demo)', 'Kogi State EIA approval EIA/KOG/2025/041 (demo)'],
    units: ['Kiln line KL-2 (4,000 tpd)', 'Raw mill RM-2', 'Petcoke mill PM-2'],
    plan: { version: 'v1.0', approvedOn: '19 Sep 2025' },
    streams: [
      {
        id: 'S1',
        label: 'Clinker production',
        unit: 't/month',
        method: 'metered',
        meter: 'belt scale BS-22',
        calibrationDue: '30 Aug 2026',
        tier: 'Tier 3',
        frequency: 'monthly',
        ipccCategory: '2.A.1 Cement Production',
      },
      {
        id: 'S2',
        label: 'Kiln fuel — petcoke',
        unit: 't/month',
        method: 'metered',
        meter: 'weighfeeder WF-07',
        calibrationDue: '30 Aug 2026',
        tier: 'Tier 2',
        frequency: 'monthly',
        ipccCategory: '1.A.2 (reported under 2.A.1 memo in demo)',
      },
      {
        id: 'S3',
        label: 'Kiln fuel — natural gas',
        unit: 'MMscf/month',
        method: 'metered',
        meter: 'metered KG-03',
        calibrationDue: null,
        tier: 'Tier 2',
        frequency: 'monthly',
        ipccCategory: '1.A.2 (reported under 2.A.1 memo in demo)',
      },
    ],
    baselineNote: 'clinker ≈ 118,000 t/month',
    anomalyNote:
      'February 2026 values identical to January to the decimal (118,432.00 t) → anomaly flag "repeated identical values"',
    dqi: 71,
    dqiTrend: { from: 66, to: 71 },
    verifiedYtd: 1131000,
    historyLabel: 'Clinker production (t/month), Jul 2025 – Jun 2026',
    history: [
      { month: 'Jul 2025', value: 116204 },
      { month: 'Aug 2025', value: 119310 },
      { month: 'Sep 2025', value: 117088 },
      { month: 'Oct 2025', value: 120155 },
      { month: 'Nov 2025', value: 117942 },
      { month: 'Dec 2025', value: 115630 },
      { month: 'Jan 2026', value: 118432.0 },
      { month: 'Feb 2026', value: 118432.0 }, // anomaly: repeated identical values
      { month: 'Mar 2026', value: 119870 },
      { month: 'Apr 2026', value: 118104 },
      { month: 'May 2026', value: 120430 },
      { month: 'Jun 2026', value: 117715 },
    ],
  },
]

export interface Persona {
  role: 'operator' | 'verifier' | 'regulator' | 'compiler'
  name: string
  title: string
  org: string
  detail: string
  initials: string
  home: string
}

export const PERSONAS: Persona[] = [
  {
    role: 'operator',
    name: 'Engr. T. Wokoma',
    title: 'Facility Environmental Manager',
    org: 'Delta Crest Energy Ltd (demo)',
    detail: 'Facility Environmental Manager, Delta Crest Energy Ltd (demo)',
    initials: 'TW',
    home: '/operator',
  },
  {
    role: 'verifier',
    name: 'Dr. F. Okafor',
    title: 'Accredited Verifier (ISO 14065)',
    org: 'Greenline Assurance Partners (demo)',
    detail:
      'Accredited Verifier (ISO 14065), accreditation AV/2024/0142 (demo), Greenline Assurance Partners (demo)',
    initials: 'FO',
    home: '/verifier',
  },
  {
    role: 'regulator',
    name: 'A. Bello',
    title: 'Deputy Director, MRV Directorate',
    org: 'National Council on Climate Change (NCCC)',
    detail: 'Deputy Director, MRV Directorate, National Council on Climate Change (NCCC)',
    initials: 'AB',
    home: '/regulator',
  },
  {
    role: 'compiler',
    name: 'S. Eze',
    title: 'National Inventory Compiler',
    org: 'NIMO — National Inventory Management Office',
    detail: 'National Inventory Compiler, NIMO — National Inventory Management Office',
    initials: 'SE',
    home: '/compiler',
  },
]

export interface EmissionFactor {
  factor: string
  value: string
  source: string
}

/** Emission factor library (illustrative, IPCC 2006/2019-aligned — demonstration data) */
export const EF_LIBRARY: EmissionFactor[] = [
  {
    factor: 'Natural gas combustion',
    value: '56,100 kg CO₂/TJ',
    source: 'IPCC 2006, Vol. 2, Ch. 2, Table 2.2 (default)',
  },
  {
    factor: 'Associated gas flaring',
    value: '60.3 t CO₂e/MMscf (derived)',
    source: 'Derived per GGFR guidance + IPCC 2006 Vol. 2 Ch. 4 — illustrative',
  },
  {
    factor: 'Diesel (gas/diesel oil)',
    value: '74,100 kg CO₂/TJ',
    source: 'IPCC 2006, Vol. 2, Ch. 2, Table 2.2 (default)',
  },
  {
    factor: 'Petroleum coke',
    value: '97,500 kg CO₂/TJ',
    source: 'IPCC 2006, Vol. 2, Ch. 2, Table 2.2 (default)',
  },
  {
    factor: 'Clinker process CO₂',
    value: '0.52 t CO₂/t clinker (+2% CKD correction)',
    source: 'IPCC 2006, Vol. 3, Ch. 2, Eq. 2.4',
  },
]

/** IPCC source-category mapping */
export const IPCC_MAPPING = [
  { scope: 'Facility A combustion', category: '1.A.1 Energy Industries' },
  { scope: 'Facility A flaring', category: '1.B.2 Oil & Natural Gas' },
  {
    scope: 'Facility B combustion + process',
    category: '2.A.1 Cement Production (process) / 1.A.2 (combustion, reported under 2.A.1 memo in demo)',
  },
] as const

/** Anomaly rule set (demo) */
export const ANOMALY_RULES = [
  'intensity shift vs trailing 6-month mean > ±30%',
  'repeated identical values across consecutive periods',
  'factor out of accepted range',
  'peer deviation > 2σ',
] as const

export type VerificationStatus = 'Pending' | 'Queried' | 'Accepted' | 'Rejected'

export interface QueueSeedItem {
  id: string
  facilityId: string
  streamLabel: string
  period: string
  activityValue: string
  aiEstimate: string
  uncertainty: string
  flag: string | null
  status: VerificationStatus
  note: string
}

/** Verification queue seed (4 items) */
export const VERIFICATION_QUEUE_SEED: QueueSeedItem[] = [
  {
    id: 'SUB-2606-114',
    facilityId: 'FAC-RIV-004',
    streamLabel: 'flaring',
    period: 'March 2026',
    activityValue: '3.05 MMscf/d',
    aiEstimate: '5,614 tCO2e',
    uncertainty: '±8%',
    flag: 'intensity shift +45%',
    status: 'Pending',
    note: 'the demo accepts this one (operator note + evidence explains a turnaround flare event)',
  },
  {
    id: 'SUB-2606-118',
    facilityId: 'FAC-KOG-002',
    streamLabel: 'clinker',
    period: 'February 2026',
    activityValue: '118,432.00 t',
    aiEstimate: '61,585 tCO2e',
    uncertainty: '±5%',
    flag: 'repeated identical values',
    status: 'Queried',
    note: 'verifier asked for belt-scale raw logs',
  },
  {
    id: 'SUB-2607-003',
    facilityId: 'FAC-RIV-004',
    streamLabel: 'fuel gas',
    period: 'June 2026',
    activityValue: '1.42 MMscf/d',
    aiEstimate: '2,602 tCO2e',
    uncertainty: '±6%',
    flag: null,
    status: 'Pending',
    note: 'no flags',
  },
  {
    id: 'SUB-2607-007',
    facilityId: 'FAC-KOG-002',
    streamLabel: 'petcoke',
    period: 'June 2026',
    activityValue: '9,588 t',
    aiEstimate: '28,417 tCO2e',
    uncertainty: '±7%',
    flag: 'peer deviation (borderline)',
    status: 'Pending',
    note: 'borderline peer deviation',
  },
]

/** DQI components (weights) */
export const DQI_WEIGHTS = [
  { component: 'metered-vs-estimated share', weight: 30 },
  { component: 'calibration status', weight: 20 },
  { component: 'completeness', weight: 20 },
  { component: 'timeliness', weight: 15 },
  { component: 'verification history', weight: 15 },
] as const

/** Hero stats band (landing, design home.md §1) */
export const HERO_STATS = [
  { value: 386400, format: '386,400', label: 'tCO₂e verified — Facility A YTD (demo)' },
  { value: 2, format: '2', label: 'industrial facilities on the rails (demo)' },
  { value: 3, format: '3', label: 'IPCC 2006 source categories mapped' },
  { value: 100, format: '100%', label: 'of figures accepted by a human verifier' },
] as const
