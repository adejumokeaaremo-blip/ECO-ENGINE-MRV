import { BrowserRouter, Routes, Route } from 'react-router'
import { Toaster } from 'sonner'
import Layout from './components/Layout'
import AppShell from './components/app/AppShell'
import Home from './pages/home/Home'
import Stub from './pages/Stub'
import OperatorDashboard from './pages/operator/Dashboard'
import Facility from './pages/operator/Facility'
import MonitoringPlan from './pages/operator/MonitoringPlan'
import Uploads from './pages/operator/Uploads'
import Dqi from './pages/operator/Dqi'
import Disclosures from './pages/operator/Disclosures'
import VerifierQueue from './pages/verifier/Queue'
import VerifierReview from './pages/verifier/Review'
import RegulatorDashboard from './pages/regulator/Dashboard'
import RegulatorFacility from './pages/regulator/Facility'
import Compliance from './pages/regulator/Compliance'
import CompilerExport from './pages/compiler/Export'
import AuditTrail from './pages/audit/AuditTrail'
import Settings from './pages/settings/Settings'

/**
 * Routing contract (one pattern, used consistently):
 * both Layout (landing) and AppShell (authenticated) render <Outlet/>
 * with nested <Route> children. All app routes render inside AppShell.
 */
export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* public landing */}
        <Route element={<Layout />}>
          <Route index element={<Home />} />
        </Route>

        {/* authenticated demonstrator (app shell) */}
        <Route element={<AppShell />}>
          <Route path="/operator" element={<OperatorDashboard />} />
          <Route path="/operator/facility" element={<Facility />} />
          <Route path="/operator/plan" element={<MonitoringPlan />} />
          <Route path="/operator/uploads" element={<Uploads />} />
          <Route path="/operator/dqi" element={<Dqi />} />
          <Route path="/operator/disclosures" element={<Disclosures />} />
          <Route path="/verifier" element={<VerifierQueue />} />
          <Route path="/verifier/review/:id" element={<VerifierReview />} />
          <Route path="/regulator" element={<RegulatorDashboard />} />
          <Route path="/regulator/facilities/:id" element={<RegulatorFacility />} />
          <Route path="/regulator/compliance" element={<Compliance />} />
          <Route path="/compiler" element={<CompilerExport />} />
          <Route path="/audit" element={<AuditTrail />} />
          <Route path="/settings" element={<Settings />} />
        </Route>

        <Route path="*" element={<Stub name="404 — Not on the record" />} />
      </Routes>
      <Toaster position="bottom-right" />
    </BrowserRouter>
  )
}
