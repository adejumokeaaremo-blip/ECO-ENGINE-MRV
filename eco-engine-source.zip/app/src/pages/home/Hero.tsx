import { lazy, Suspense, useRef } from 'react'
import gsap from 'gsap'
import { useGSAP } from '@gsap/react'
import { HERO_STATS } from '@/lib/demo-data'
import { CountUp, SplitChars, prefersReducedMotion } from './shared'

const ParticleField = lazy(() => import('./ParticleField'))

/**
 * Hero (home.md §1): 100vh dark, particle ledger field, char-split H1,
 * ruled-frame flare image, bottom stats band with count-ups.
 */
export default function Hero() {
  const root = useRef<HTMLElement>(null)

  useGSAP(
    () => {
      if (prefersReducedMotion()) return
      const q = gsap.utils.selector(root)
      gsap.fromTo(
        q('[data-hero-kicker]'),
        { opacity: 0 },
        { opacity: 1, duration: 0.6, delay: 0.3, ease: 'power2.out' },
      )
      gsap.fromTo(
        q('[data-split-char]'),
        { y: 60, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.9,
          delay: 0.3,
          stagger: 0.02,
          ease: 'power3.out',
        },
      )
      gsap.fromTo(
        q('[data-hero-sub],[data-hero-ctas]'),
        { y: 24, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.8, delay: 0.9, stagger: 0.12, ease: 'power3.out' },
      )
      gsap.fromTo(
        q('[data-hero-image]'),
        { clipPath: 'inset(100% 0 0 0)' },
        { clipPath: 'inset(0% 0 0 0)', duration: 1.1, delay: 0.5, ease: 'power3.inOut' },
      )
      gsap.fromTo(
        q('[data-hero-caption]'),
        { opacity: 0 },
        { opacity: 1, duration: 0.6, delay: 1.4 },
      )
    },
    { scope: root },
  )

  return (
    <section
      ref={root}
      className="relative flex min-h-[calc(100dvh-2rem)] flex-col overflow-hidden"
      style={{ background: 'linear-gradient(180deg, #093845 0%, #062832 100%)' }}
    >
      {/* CSS fallback texture: static ledger grid at 10% under the particle field */}
      <div
        className="absolute inset-0 opacity-10"
        style={{ backgroundImage: 'url(/ledger-grid.svg)', backgroundSize: '800px 800px' }}
        aria-hidden="true"
      />
      <Suspense fallback={null}>
        <ParticleField />
      </Suspense>

      <div className="relative mx-auto flex w-full max-w-[1280px] flex-1 items-center gap-12 px-8 pb-10 pt-32 max-md:px-5 lg:gap-16">
        {/* left 60% */}
        <div className="w-full lg:w-3/5">
          <p data-hero-kicker className="kicker text-copper-light">
            ECO-ENGINE MRV SYSTEM COMPANY LTD · RC 9666441 · ABUJA
          </p>
          <h1 className="mt-6 font-display text-[64px] leading-[1.0] tracking-[-0.005em] text-ivory md:text-[88px]">
            <span className="block overflow-hidden pb-1">
              <SplitChars text="Trust is the product." />
            </span>
            <span className="block overflow-hidden pb-1">
              <SplitChars text="We build the ledger." />
            </span>
          </h1>
          <p
            data-hero-sub
            className="mt-6 max-w-[520px] font-sans text-[16px] leading-[1.6] text-ivory/75"
          >
            Nigeria&rsquo;s climate-data rails — a digital MRV platform where industrial emissions are
            measured, AI-estimated, and verified by a human before they enter the national record.
          </p>
          <div data-hero-ctas className="mt-8 flex flex-wrap items-center gap-4">
            <a
              href="#roles"
              className="rounded-[2px] bg-copper px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ivory transition-all duration-200 hover:-translate-y-px hover:bg-copper-light hover:text-ink"
            >
              Enter the demonstrator
            </a>
            <a
              href="#method"
              className="rounded-[2px] border border-ivory/40 px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ivory transition-all duration-200 hover:-translate-y-px hover:border-ivory hover:bg-ivory/5"
            >
              Read the method
            </a>
          </div>
        </div>

        {/* right 40% */}
        <div className="hidden w-2/5 lg:block">
          <div data-hero-image className="border border-ivory/20" style={{ clipPath: 'inset(0 0 0 0)' }}>
            <img
              src="/flare-station.png"
              alt="Niger Delta flow station flare stack at dusk — duotone demonstration photograph"
              className="h-[62vh] w-full object-cover"
            />
          </div>
          <p data-hero-caption className="mt-3 font-mono text-[11px] tracking-[0.02em] text-ivory/50">
            NigerDelta Flow Station 4 · Rivers State · demonstration facility
          </p>
        </div>
      </div>

      {/* bottom stats band */}
      <div className="relative border-t border-ivory/15">
        <div className="mx-auto grid max-w-[1280px] grid-cols-2 gap-8 px-8 py-8 max-md:px-5 lg:grid-cols-4">
          {HERO_STATS.map((s) => (
            <div key={s.label}>
              <CountUp
                value={s.value}
                format={(v) =>
                  s.format.includes('%')
                    ? `${Math.round(v)}%`
                    : Math.round(v).toLocaleString('en-US')
                }
                duration={1400}
                className="font-display text-[40px] leading-none text-ivory md:text-[56px]"
              />
              <p className="mt-2 font-sans text-[10px] font-semibold uppercase tracking-kicker text-ivory/50">
                {s.label}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
