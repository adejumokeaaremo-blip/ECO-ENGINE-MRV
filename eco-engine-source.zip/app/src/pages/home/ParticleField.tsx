import { useEffect, useMemo, useRef, useState } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import * as THREE from 'three'

const COUNT_X = 40
const COUNT_Y = 25
const TOTAL = COUNT_X * COUNT_Y // 1,000 points (design ≤ 1,200)

/**
 * Hero particle ledger field (home.md §1): ~1,000 points in a loose 3D ledger
 * grid, petrol-teal at 40% opacity with ~5% copper; slow drift (0.02 rad/s)
 * + subtle mouse parallax; fades in 0→0.4 over 2s; pauses off-screen/hidden tab.
 */
function LedgerPoints() {
  const group = useRef<THREE.Group>(null)
  const material = useRef<THREE.PointsMaterial>(null)
  const pointer = useRef({ x: 0, y: 0 })
  const bornAt = useRef<number | null>(null)

  const { positions, colors } = useMemo(() => {
    const positions = new Float32Array(TOTAL * 3)
    const colors = new Float32Array(TOTAL * 3)
    const petrol = new THREE.Color('#2E7D8F')
    const copper = new THREE.Color('#D98E4A')
    let i = 0
    for (let ix = 0; ix < COUNT_X; ix++) {
      for (let iy = 0; iy < COUNT_Y; iy++) {
        const jx = (Math.sin(i * 12.9898) * 43758.5453) % 1
        const jy = (Math.sin(i * 78.233) * 12543.1234) % 1
        const jz = (Math.sin(i * 39.425) * 32111.4321) % 1
        positions[i * 3] = (ix / (COUNT_X - 1) - 0.5) * 22 + jx * 0.5
        positions[i * 3 + 1] = (iy / (COUNT_Y - 1) - 0.5) * 12 + jy * 0.5
        positions[i * 3 + 2] = jz * 4 - 2
        const c = i % 20 === 0 ? copper : petrol // ~5% copper
        colors[i * 3] = c.r
        colors[i * 3 + 1] = c.g
        colors[i * 3 + 2] = c.b
        i++
      }
    }
    return { positions, colors }
  }, [])

  useEffect(() => {
    const onMove = (e: PointerEvent) => {
      pointer.current.x = (e.clientX / window.innerWidth - 0.5) * 2
      pointer.current.y = (e.clientY / window.innerHeight - 0.5) * 2
    }
    window.addEventListener('pointermove', onMove, { passive: true })
    return () => window.removeEventListener('pointermove', onMove)
  }, [])

  useFrame((state, delta) => {
    const g = group.current
    if (!g) return
    if (bornAt.current === null) bornAt.current = state.clock.elapsedTime
    // slow drift rotation 0.02 rad/s
    g.rotation.y += delta * 0.02
    // subtle mouse parallax (±~10px world equivalent), lerp decay
    g.position.x += (pointer.current.x * 0.4 - g.position.x) * 0.05
    g.position.y += (-pointer.current.y * 0.25 - g.position.y) * 0.05
    // fade in opacity 0 → 0.4 over 2s
    const m = material.current
    if (m) {
      const t = Math.min(1, (state.clock.elapsedTime - bornAt.current) / 2)
      m.opacity = 0.4 * t
    }
  })

  return (
    <group ref={group}>
      <points>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[positions, 3]} />
          <bufferAttribute attach="attributes-color" args={[colors, 3]} />
        </bufferGeometry>
        <pointsMaterial
          ref={material}
          size={0.05}
          vertexColors
          transparent
          opacity={0}
          sizeAttenuation
          depthWrite={false}
        />
      </points>
    </group>
  )
}

export default function ParticleField() {
  const wrap = useRef<HTMLDivElement>(null)
  const [active, setActive] = useState(true)

  useEffect(() => {
    const el = wrap.current
    if (!el) return
    const io = new IntersectionObserver((entries) => setActive(entries[0].isIntersecting), {
      threshold: 0,
    })
    io.observe(el)
    const onVis = () => setActive(!document.hidden)
    document.addEventListener('visibilitychange', onVis)
    return () => {
      io.disconnect()
      document.removeEventListener('visibilitychange', onVis)
    }
  }, [])

  const reduced =
    typeof window !== 'undefined' &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches

  if (reduced) return null // static ledger-grid fallback shows through

  return (
    <div ref={wrap} className="absolute inset-0" aria-hidden="true">
      {active && (
        <Canvas
          camera={{ position: [0, 0, 10], fov: 55 }}
          dpr={[1, 2]}
          gl={{ antialias: true, alpha: true }}
          style={{ position: 'absolute', inset: 0 }}
        >
          <LedgerPoints />
        </Canvas>
      )}
    </div>
  )
}
