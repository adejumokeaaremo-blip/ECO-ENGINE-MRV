import { useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { useGSAP } from '@gsap/react'
import LedgerRule from '@/components/app/LedgerRule'
import { prefersReducedMotion } from './shared'

gsap.registerPlugin(ScrollTrigger)

/** Section 7 — Who builds this (home.md §7, dark). */
export default function Founders() {
  const root = useRef<HTMLElement>(null)

  useGSAP(
    () => {
      if (prefersReducedMotion()) return
      const q = gsap.utils.selector(root)
      gsap.fromTo(
        q('[data-founders-image]'),
        { clipPath: 'inset(0 100% 0 0)' },
        {
          clipPath: 'inset(0 0% 0 0)',
          duration: 1,
          ease: 'power3.inOut',
          scrollTrigger: { trigger: root.current, start: 'top 70%', once: true },
        },
      )
      gsap.fromTo(
        q('[data-founders-text]'),
        { y: 28, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.7,
          stagger: 0.1,
          ease: 'power3.out',
          scrollTrigger: { trigger: root.current, start: 'top 68%', once: true },
        },
      )
    },
    { scope: root },
  )

  return (
    <section ref={root} className="bg-petrol-deep text-ivory">
      <div className="mx-auto grid max-w-[1280px] items-center gap-12 px-8 py-24 max-md:px-5 md:py-32 lg:grid-cols-2 lg:gap-16">
        <div data-founders-image className="border border-ivory/20">
          <img
            src="/founders-portrait.png"
            alt="Editorial duotone portrait of the two ECO ENGINE founders"
            className="w-full object-cover"
          />
        </div>

        <div>
          <div data-founders-text>
            <LedgerRule dark />
            <p className="kicker mt-6 text-copper-light">05 — The Company</p>
          </div>
          <h2 data-founders-text className="mt-4 font-display text-[36px] leading-[1.1] md:text-[48px]">
            Private infrastructure. National standard.
          </h2>
          <p data-founders-text className="mt-6 max-w-[520px] font-sans text-[15px] leading-[1.7] text-ivory/75">
            ECO-ENGINE MRV SYSTEM COMPANY LTD was incorporated in Abuja on 8 July 2026 (RC 9666441)
            to operate Nigeria&rsquo;s climate-data rails as neutral, private infrastructure aligned to
            the national standard.
          </p>
          <div data-founders-text className="mt-10 space-y-6 border-t border-ivory/15 pt-8">
            <div>
              <p className="font-display text-[24px] leading-none">Adejumoke R. Aremo</p>
              <p className="mt-1 font-sans text-[13px] text-ivory/60">Co-founder &amp; CEO</p>
            </div>
            <div>
              <p className="font-display text-[24px] leading-none">Aroyehun A. Sunkanmi</p>
              <p className="mt-1 font-sans text-[13px] text-ivory/60">Co-founder &amp; COO</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
