import { useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { useGSAP } from '@gsap/react'
import AILabel from '@/components/app/AILabel'
import LedgerRule from '@/components/app/LedgerRule'
import { prefersReducedMotion } from './shared'

gsap.registerPlugin(ScrollTrigger)

/**
 * Section 4 — "The AI accelerates. The human decides." (home.md §4).
 * 50/50 split with vertical line rule: mocked AI estimate card (left, sand)
 * vs verifier panel (right, ivory).
 */
export default function SplitSection() {
  const root = useRef<HTMLElement>(null)

  useGSAP(
    () => {
      if (prefersReducedMotion()) return
      const q = gsap.utils.selector(root)
      gsap.fromTo(
        q('[data-split-left]'),
        { x: -60, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: { trigger: root.current, start: 'top 70%', once: true },
        },
      )
      gsap.fromTo(
        q('[data-split-right]'),
        { x: 60, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: { trigger: root.current, start: 'top 70%', once: true },
        },
      )
      gsap.fromTo(
        q('[data-ai-square]'),
        { scale: 1 },
        {
          scale: 1.3,
          duration: 0.25,
          yoyo: true,
          repeat: 1,
          ease: 'power2.inOut',
          scrollTrigger: { trigger: q('[data-ai-square]')[0], start: 'top 80%', once: true },
        },
      )
      gsap.fromTo(
        q('[data-action-chip]'),
        { y: 16, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.5,
          stagger: 0.1,
          ease: 'power3.out',
          scrollTrigger: { trigger: q('[data-split-right]')[0], start: 'top 65%', once: true },
        },
      )
    },
    { scope: root },
  )

  return (
    <section ref={root} className="bg-sand text-ink">
      <div className="mx-auto max-w-[1280px] px-8 py-24 max-md:px-5 md:py-32">
        <LedgerRule />
        <h2 className="mt-8 max-w-[1000px] font-display text-[40px] leading-[1.05] md:text-[64px]">
          The AI accelerates. <span className="text-copper">The human decides.</span>
        </h2>

        <div className="mt-16 grid md:grid-cols-2">
          {/* left — THE ENGINE (sand) */}
          <div data-split-left className="border-line/60 py-10 max-md:border-b max-md:pb-12 md:pr-12">
            <p className="kicker text-muted">The Engine</p>
            <div className="mt-6 border border-line bg-ivory p-8 shadow-panel">
              <p className="kicker text-muted">SUB-2606-114 · March 2026</p>
              <p className="mt-4 font-display text-[56px] leading-none text-copper md:text-[72px]">
                5,614 tCO₂e
              </p>
              <p className="mt-3 font-mono text-[12px] leading-[1.5] text-muted">
                ±8% uncertainty · GGFR/IPCC 2006 factor · provenance attached
              </p>
              <div className="mt-6 border-t border-line/60 pt-5">
                <AILabel size="lg" />
              </div>
              <p className="mt-4 inline-flex items-center gap-2 border border-alert/50 px-[10px] py-[6px] font-sans text-[10px] font-semibold uppercase tracking-chip text-alert">
                Flag: intensity shift +45% vs 6-month mean
              </p>
            </div>
          </div>

          {/* right — THE VERIFIER (ivory panel) */}
          <div data-split-right className="bg-ivory py-10 max-md:pt-12 md:border-l md:border-line/60 md:pl-12">
            <p className="kicker text-muted">The Verifier</p>
            <div className="mt-6 flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center bg-petrol font-mono text-[13px] font-medium text-ivory">
                FO
              </span>
              <div>
                <p className="font-sans text-[15px] font-semibold">Dr. F. Okafor</p>
                <p className="font-sans text-[12px] text-muted">Accredited Verifier (ISO 14065)</p>
              </div>
            </div>
            <blockquote className="mt-8 font-display text-[24px] leading-[1.25] text-ink md:text-[28px]">
              &ldquo;The engine shows its arithmetic. I check the evidence, and I sign. That signature
              is the product.&rdquo;
            </blockquote>
            <div className="mt-8 flex flex-wrap gap-3">
              <span
                data-action-chip
                className="rounded-[2px] bg-petrol px-[14px] py-[8px] font-sans text-[11px] font-semibold uppercase tracking-chip text-ivory"
              >
                Accept
              </span>
              <span
                data-action-chip
                className="rounded-[2px] border border-copper px-[14px] py-[8px] font-sans text-[11px] font-semibold uppercase tracking-chip text-copper"
              >
                Query
              </span>
              <span
                data-action-chip
                className="rounded-[2px] bg-alert px-[14px] py-[8px] font-sans text-[11px] font-semibold uppercase tracking-chip text-ivory"
              >
                Reject
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
