import { useState } from 'react'
import { useNavigate } from 'react-router'
import { motion, AnimatePresence } from 'framer-motion'
import { X } from 'lucide-react'
import LedgerRule from '@/components/app/LedgerRule'
import { PERSONAS, type Persona } from '@/lib/demo-data'
import { useRole } from '@/lib/store'

const ROLE_MANDATES: Record<Persona['role'], string> = {
  operator: 'Onboards the facility, keeps the monitoring plan, uploads activity data.',
  verifier: 'Reviews every AI estimate against the evidence. Accept, Query, Reject.',
  regulator: 'Read-only national oversight: portfolio, DQI, compliance calendar, alerts.',
  compiler: 'Builds the AD/EF Inventory Export by IPCC category for the national inventory.',
}

const ROLE_NAMES: Record<Persona['role'], string> = {
  operator: 'Facility Operator',
  verifier: 'Verifier',
  regulator: 'Regulator — NCCC',
  compiler: 'Inventory Compiler — NIMO',
}

/**
 * Section 5 — Roles / Enter the demonstrator (home.md §5, dark; the login).
 * Framer Motion only in this component tree (columns stagger + §6.13 modal).
 */
export default function Roles() {
  const [selected, setSelected] = useState<Persona | null>(null)
  const { setRole } = useRole()
  const navigate = useNavigate()

  const enter = (p: Persona) => {
    setRole(p.role)
    setSelected(null)
    navigate(p.home)
  }

  return (
    <section id="roles" className="bg-petrol-deep text-ivory">
      <div className="mx-auto max-w-[1280px] px-8 py-24 max-md:px-5 md:py-32">
        <LedgerRule dark />
        <p className="kicker mt-6 text-copper-light">03 — Enter the Demonstrator</p>
        <h2 className="mt-4 font-display text-[36px] leading-[1.1] md:text-[48px]">
          Four seats at one ledger.
        </h2>

        <div className="mt-16 grid md:grid-cols-2 lg:grid-cols-4">
          {PERSONAS.map((p, i) => (
            <motion.button
              key={p.role}
              type="button"
              onClick={() => setSelected(p)}
              initial={{ opacity: 0, y: 32 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-15%' }}
              transition={{ duration: 0.7, delay: i * 0.12, ease: [0.22, 1, 0.36, 1] }}
              className="group border-t border-ivory/15 px-0 py-8 text-left transition-colors lg:border-l lg:border-t-0 lg:px-8 lg:first:border-l-0 lg:first:pl-0"
            >
              <span
                className="block h-px w-full origin-left scale-x-0 bg-copper transition-transform duration-300 group-hover:scale-x-100"
                aria-hidden="true"
              />
              <span className="mt-6 block font-display text-[56px] leading-none text-[#2E8B9A] transition-colors duration-300 group-hover:text-copper">
                {String(i + 1).padStart(2, '0')}
              </span>
              <span className="mt-4 block font-sans text-[18px] font-semibold tracking-[0.01em]">
                {ROLE_NAMES[p.role]}
              </span>
              <span className="mt-2 block font-sans text-[13px] leading-[1.6] text-ivory/65">
                {ROLE_MANDATES[p.role]}
              </span>
              <span className="mt-4 block font-mono text-[11px] leading-[1.5] tracking-[0.02em] text-ivory/45">
                {p.name} · {p.org}
              </span>
              <span className="link-sweep mt-6 inline-block font-sans text-[13px] font-semibold text-copper-light">
                Enter as →
              </span>
            </motion.button>
          ))}
        </div>
      </div>

      {/* demo login modal (design.md §6.13) */}
      <AnimatePresence>
        {selected && (
          <motion.div
            key="backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-0 z-[60] flex items-center justify-center bg-petrol-deep/60 p-5 backdrop-blur-[4px]"
            onClick={() => setSelected(null)}
          >
            <motion.div
              key="panel"
              role="dialog"
              aria-modal="true"
              aria-label="Enter the demonstrator"
              initial={{ opacity: 0, scale: 0.97 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.97 }}
              transition={{ duration: 0.25, ease: [0.22, 1, 0.36, 1] }}
              className="w-full max-w-[560px] rounded-[2px] border border-line bg-ivory p-8 text-ink"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-start justify-between">
                <div>
                  <p className="kicker text-muted">Demonstrator login</p>
                  <h3 className="mt-2 font-display text-[32px] leading-none">Enter the demonstrator</h3>
                </div>
                <button
                  type="button"
                  aria-label="Close"
                  onClick={() => setSelected(null)}
                  className="rounded-[2px] p-1.5 text-muted transition-colors hover:text-ink"
                >
                  <X className="h-4 w-4" strokeWidth={1.75} />
                </button>
              </div>

              <div className="mt-6 flex items-center gap-4 border border-line/60 bg-sand p-4">
                <span className="flex h-10 w-10 items-center justify-center bg-petrol font-mono text-[13px] font-medium text-ivory">
                  {selected.initials}
                </span>
                <div>
                  <p className="font-sans text-[15px] font-semibold">{selected.name}</p>
                  <p className="font-sans text-[12px] text-muted">{selected.detail}</p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => enter(selected)}
                className="mt-6 w-full rounded-[2px] bg-copper px-[18px] py-[12px] font-sans text-[13px] font-semibold text-ivory transition-all duration-200 hover:-translate-y-px hover:bg-copper-light hover:text-ink"
              >
                Continue as {selected.name}
              </button>
              <p className="mt-4 text-center font-sans text-[12px] text-muted">
                Demonstration build — no password required. All data is demonstration data.
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  )
}
