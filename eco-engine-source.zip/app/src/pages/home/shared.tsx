import { useEffect, useRef, useState, type ReactNode } from 'react'

export const EASE_PRIMARY = 'cubic-bezier(0.22, 1, 0.36, 1)'

export function prefersReducedMotion(): boolean {
  return (
    typeof window !== 'undefined' &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches
  )
}

/** Count-up numeral: animates 0→value over `duration` ms when 40% in view. */
export function CountUp({
  value,
  format,
  duration = 1200,
  className,
}: {
  value: number
  format?: (v: number) => string
  duration?: number
  className?: string
}) {
  const ref = useRef<HTMLSpanElement>(null)
  const [display, setDisplay] = useState(() =>
    prefersReducedMotion() ? (format ? format(value) : value.toLocaleString('en-US')) : '0',
  )
  const started = useRef(false)

  useEffect(() => {
    const el = ref.current
    if (!el) return
    const render = (v: number) => setDisplay(format ? format(v) : Math.round(v).toLocaleString('en-US'))
    if (prefersReducedMotion()) return
    const io = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !started.current) {
          started.current = true
          const t0 = performance.now()
          const tick = (now: number) => {
            const p = Math.min(1, (now - t0) / duration)
            render(value * (1 - Math.pow(1 - p, 3)))
            if (p < 1) requestAnimationFrame(tick)
          }
          requestAnimationFrame(tick)
          io.disconnect()
        }
      },
      { threshold: 0.4 },
    )
    io.observe(el)
    return () => io.disconnect()
  }, [value, duration, format])

  return (
    <span ref={ref} className={className}>
      {display}
    </span>
  )
}

/** Splits text into per-char spans for GSAP kinetic-type animation. */
export function SplitChars({ text, className }: { text: string; className?: string }) {
  return (
    <span className={className} aria-label={text} role="text">
      {text.split('').map((ch, i) => (
        <span key={i} className="inline-block will-change-transform" data-split-char aria-hidden="true">
          {ch === ' ' ? ' ' : ch}
        </span>
      ))}
    </span>
  )
}

/** Splits text into per-word spans (word-level reveal). */
export function SplitWords({ text, className }: { text: string; className?: string }) {
  return (
    <span className={className} aria-label={text} role="text">
      {text.split(' ').map((w, i) => (
        <span key={i} className="inline-block will-change-transform" data-split-word aria-hidden="true">
          {w}
          {i < text.split(' ').length - 1 ? ' ' : ''}
        </span>
      ))}
    </span>
  )
}

/** Standard scroll reveal wrapper (opacity 0→1, translateY →0, once) using IntersectionObserver. */
export function Reveal({
  children,
  delay = 0,
  y = 32,
  className,
}: {
  children: ReactNode
  delay?: number
  y?: number
  className?: string
}) {
  const ref = useRef<HTMLDivElement>(null)
  const [shown, setShown] = useState(() => prefersReducedMotion())
  useEffect(() => {
    const el = ref.current
    if (!el) return
    if (prefersReducedMotion()) return
    const io = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setShown(true)
          io.disconnect()
        }
      },
      { threshold: 0.2 },
    )
    io.observe(el)
    return () => io.disconnect()
  }, [])
  return (
    <div
      ref={ref}
      className={className}
      style={{
        opacity: shown ? 1 : 0,
        transform: shown ? 'translateY(0)' : `translateY(${y}px)`,
        transition: `opacity 0.7s ${EASE_PRIMARY} ${delay}ms, transform 0.7s ${EASE_PRIMARY} ${delay}ms`,
      }}
    >
      {children}
    </div>
  )
}
