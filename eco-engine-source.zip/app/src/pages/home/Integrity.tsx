import { useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { useGSAP } from '@gsap/react'
import LedgerRule from '@/components/app/LedgerRule'
import { demoHash, truncateHash } from '@/lib/store'
import { prefersReducedMotion } from './shared'

gsap.registerPlugin(ScrollTrigger)

const PRINCIPLES = [
  {
    title: 'Tamper-evident by construction',
    desc: 'Every submission, estimate, decision and login is a hash-chained log entry.',
  },
  {
    title: 'Verified-only outputs',
    desc: 'Disclosure packs and the Inventory Export are generated exclusively from regulator-verified data, and say so on their face.',
  },
  {
    title: 'Published data quality',
    desc: 'A 0–100 DQI per stream and facility: metered share, calibration, completeness, timeliness, verification history. Immutable history.',
  },
]

const CHAIN_STEPS = ['login', 'upload', 'estimate', 'accept', 'export']

/** Deterministic demo chain for the integrity visual (module-level, computed once). */
const CHAIN_HASHES: string[] = (() => {
  const out: string[] = []
  let prev = '0x0000…0000'
  for (const step of CHAIN_STEPS) {
    const h = demoHash(`demo-chain|${prev}|${step}`)
    out.push(h)
    prev = h
  }
  return out
})()

/** Section 6 — Integrity architecture (home.md §6, light). */
export default function Integrity() {
  const root = useRef<HTMLElement>(null)
  const hashes = CHAIN_HASHES

  useGSAP(
    () => {
      if (prefersReducedMotion()) return
      const q = gsap.utils.selector(root)

      gsap.fromTo(
        q('[data-integrity-row]'),
        { y: 32, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.7,
          stagger: 0.15,
          ease: 'power3.out',
          scrollTrigger: { trigger: root.current, start: 'top 72%', once: true },
        },
      )

      // hash-chain draw: links draw sequentially, then nodes pop, copper pulse once
      const links = q('[data-chain-link]')
      links.forEach((el) => {
        const len = (el as unknown as SVGGeometryElement).getTotalLength?.() ?? 60
        gsap.set(el, { strokeDasharray: len, strokeDashoffset: len })
      })
      gsap.set(q('[data-chain-node]'), { scale: 0, transformOrigin: 'center' })
      const tl = gsap.timeline({
        scrollTrigger: { trigger: q('[data-chain]')[0], start: 'top 78%', once: true },
      })
      CHAIN_STEPS.forEach((_, i) => {
        tl.to(q('[data-chain-node]')[i], { scale: 1, duration: 0.4, ease: 'back.out(2)' }, i * 0.55)
        if (i < links.length) {
          tl.to(links[i], { strokeDashoffset: 0, duration: 0.5, ease: 'power2.inOut' }, i * 0.55 + 0.2)
        }
      })
      tl.to(q('[data-chain-node]')[3], { scale: 1.15, duration: 0.2, yoyo: true, repeat: 1 }, '>-0.1')

      // map pins pop with copper ring pulse
      gsap.fromTo(
        q('[data-map-pin]'),
        { scale: 0 },
        {
          scale: 1,
          duration: 0.6,
          stagger: 0.3,
          ease: 'back.out(2.5)',
          scrollTrigger: { trigger: q('[data-map]')[0], start: 'top 75%', once: true },
        },
      )
      gsap.fromTo(
        q('[data-map-ring]'),
        { scale: 0.6, opacity: 0.9 },
        {
          scale: 1.8,
          opacity: 0,
          duration: 1.2,
          stagger: 0.3,
          ease: 'power2.out',
          scrollTrigger: { trigger: q('[data-map]')[0], start: 'top 75%', once: true },
        },
      )
    },
    { scope: root },
  )

  return (
    <section id="integrity" ref={root} className="bg-sand text-ink">
      <div className="mx-auto grid max-w-[1280px] gap-16 px-8 py-24 max-md:px-5 md:py-32 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <LedgerRule />
          <p className="kicker mt-6 text-muted">04 — Integrity</p>
          <h2 className="mt-4 max-w-[700px] font-display text-[36px] leading-[1.1] md:text-[48px]">
            Built so that trust does not depend on us.
          </h2>

          <div className="mt-12">
            {PRINCIPLES.map((p, i) => (
              <div key={p.title} data-integrity-row className="border-t border-line/60 py-8 last:border-b">
                <div className="flex items-baseline gap-6">
                  <span className="font-mono text-[12px] text-copper">{String(i + 1).padStart(2, '0')}</span>
                  <div>
                    <h3 className="font-sans text-[18px] font-semibold tracking-[0.01em]">{p.title}</h3>
                    <p className="mt-2 max-w-[560px] font-sans text-[14px] leading-[1.6] text-ink/75">
                      {p.desc}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* animated 5-node hash chain */}
          <div data-chain className="mt-12 overflow-x-auto border border-line/60 bg-ivory p-6">
            <svg viewBox="0 0 760 110" className="min-w-[640px]" role="img" aria-label="Hash-chained audit trail: login, upload, estimate, accept, export">
              {CHAIN_STEPS.slice(0, -1).map((_, i) => (
                <line
                  key={i}
                  data-chain-link
                  x1={86 + i * 152}
                  y1={34}
                  x2={86 + (i + 1) * 152 - 24}
                  y2={34}
                  stroke="#0F4C5C"
                  strokeWidth="1.5"
                />
              ))}
              {CHAIN_STEPS.map((step, i) => (
                <g key={step}>
                  <rect
                    data-chain-node
                    x={86 + i * 152 - 12}
                    y={22}
                    width={24}
                    height={24}
                    fill={i === 3 ? '#B5651D' : '#0F4C5C'}
                  />
                  <text
                    x={86 + i * 152}
                    y={66}
                    textAnchor="middle"
                    fontSize="11"
                    fontFamily="Liter, sans-serif"
                    fontWeight="600"
                    letterSpacing="1.5"
                    fill="#1C2B28"
                    style={{ textTransform: 'uppercase' }}
                  >
                    {step.toUpperCase()}
                  </text>
                  <text
                    x={86 + i * 152}
                    y={86}
                    textAnchor="middle"
                    fontSize="10"
                    fontFamily="'IBM Plex Mono', monospace"
                    fill="#5F7168"
                  >
                    {truncateHash(hashes[i])}
                  </text>
                </g>
              ))}
            </svg>
            <p className="mt-4 font-mono text-[11px] tracking-[0.02em] text-muted">
              Each entry stores the hash of the one before it. Alter any record and the chain breaks.
            </p>
          </div>
        </div>

        {/* right rail (sticky): nigeria map */}
        <div className="lg:col-span-1">
          <div className="lg:sticky lg:top-32">
            <div data-map className="relative border border-line/60 bg-ivory p-6">
              <img src="/nigeria-map.svg" alt="Stylised outline map of Nigeria with facility pins" className="w-full" />
              {/* animated pin overlays aligned to the SVG pins */}
              <span
                className="absolute"
                style={{ left: '33.8%', top: '84.5%' }}
                aria-hidden="true"
              >
                <span data-map-ring className="absolute h-6 w-6 -translate-x-1/2 -translate-y-1/2 border border-copper" />
                <span data-map-pin className="absolute h-3 w-3 -translate-x-1/2 -translate-y-1/2 bg-copper" />
              </span>
              <span
                className="absolute"
                style={{ left: '32.4%', top: '58.5%' }}
                aria-hidden="true"
              >
                <span data-map-ring className="absolute h-6 w-6 -translate-x-1/2 -translate-y-1/2 border border-copper" />
                <span data-map-pin className="absolute h-3 w-3 -translate-x-1/2 -translate-y-1/2 bg-copper" />
              </span>
            </div>
            <p className="mt-3 font-mono text-[11px] leading-[1.5] tracking-[0.02em] text-muted">
              Demonstration portfolio — two facilities, two sectors, one national standard.
            </p>
            <p className="mt-2 font-mono text-[11px] tracking-[0.02em] text-muted">
              ● Rivers State — NigerDelta Flow Station 4
              <br />● Kogi State — Sahel Cement Works, Line 2
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
