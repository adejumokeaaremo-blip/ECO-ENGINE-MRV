import { useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { useGSAP } from '@gsap/react'
import LedgerRule from '@/components/app/LedgerRule'
import { prefersReducedMotion } from './shared'

gsap.registerPlugin(ScrollTrigger)

const STATIONS = [
  {
    num: '01',
    title: 'One Upload',
    desc: 'Operator submits activity data with hashed evidence. Schema, units, range and duplicate checks run instantly.',
  },
  {
    num: '02',
    title: 'AI estimation',
    desc: 'The engine computes CO₂e with IPCC 2006/2019 factors, full provenance and uncertainty — and flags anomalies.',
  },
  {
    num: '03',
    title: 'Human verification',
    desc: 'An accredited verifier reviews evidence, reasoning and flags. Accept, Query, or Reject. The human decides.',
  },
  {
    num: '04',
    title: 'The official record',
    desc: 'Accepted figures enter a tamper-evident, hash-chained ledger. DQI is published.',
  },
  {
    num: '05',
    title: 'Disclosure & inventory',
    desc: 'IFRS S2 / GRI 305 packs and the IPCC-category Inventory Export are generated from verified data only.',
  },
]

/**
 * Section 3 — The method (home.md §3): pinned 220vh scroll sequence, dark.
 * Horizontal 5-station ledger; track fills petrol with scroll; nodes light
 * copper when reached; active station opaque, others 35%.
 * Falls back to a stacked list on small screens / reduced motion.
 */
export default function Method() {
  const root = useRef<HTMLElement>(null)

  useGSAP(
    () => {
      const q = gsap.utils.selector(root)
      const stations = q('[data-method-station]')
      const nodes = q('[data-method-node]')
      const mm = gsap.matchMedia()

      mm.add('(min-width: 1024px)', () => {
        if (prefersReducedMotion()) {
          gsap.set(stations, { opacity: 1, y: 0 })
          return
        }
        const setActive = (idx: number) => {
          stations.forEach((el, i) => {
            gsap.to(el, {
              opacity: i === idx ? 1 : 0.35,
              y: i === idx ? 0 : 20,
              duration: 0.45,
              ease: 'power3.out',
              overwrite: 'auto',
            })
          })
          nodes.forEach((el, i) => {
            const lit = i <= idx
            ;(el as HTMLElement).style.backgroundColor = lit ? '#B5651D' : 'transparent'
            ;(el as HTMLElement).style.borderColor = lit ? '#B5651D' : 'rgba(245,240,230,0.35)'
          })
        }
        setActive(0)
        const tl = gsap.timeline({
          scrollTrigger: {
            trigger: root.current,
            start: 'top top',
            end: '+=220%',
            pin: true,
            scrub: 0.6,
            onUpdate: (self) => {
              setActive(Math.min(STATIONS.length - 1, Math.floor(self.progress * STATIONS.length)))
            },
          },
        })
        tl.fromTo(q('[data-method-fill]'), { scaleX: 0 }, { scaleX: 1, ease: 'none', duration: 1 }, 0)
        return () => {
          tl.scrollTrigger?.kill()
          tl.kill()
        }
      })

      // small screens: simple staggered reveal, no pin
      mm.add('(max-width: 1023px)', () => {
        if (prefersReducedMotion()) {
          gsap.set(stations, { opacity: 1, y: 0 })
          return
        }
        gsap.set(q('[data-method-track]'), { display: 'none' })
        stations.forEach((el) => {
          gsap.fromTo(
            el,
            { opacity: 0, y: 32 },
            {
              opacity: 1,
              y: 0,
              duration: 0.7,
              ease: 'power3.out',
              scrollTrigger: { trigger: el, start: 'top 82%', once: true },
            },
          )
        })
      })

      return () => mm.revert()
    },
    { scope: root },
  )

  return (
    <section id="method" ref={root} className="bg-petrol-deep text-ivory">
      <div className="mx-auto flex min-h-[100dvh] max-w-[1280px] flex-col justify-center px-8 py-24 max-md:px-5">
        <LedgerRule dark />
        <p className="kicker mt-6 text-copper-light">02 — The Method · Stage 1</p>
        <h2 className="mt-4 max-w-[820px] font-display text-[36px] leading-[1.1] md:text-[48px]">
          From a single upload to the national inventory.
        </h2>

        {/* progress track with 5 square nodes */}
        <div data-method-track className="relative mt-16 hidden h-px bg-ivory/15 lg:block">
          <div
            data-method-fill
            className="absolute inset-y-0 left-0 h-px w-full origin-left bg-petrol"
            style={{ transform: 'scaleX(0)', backgroundColor: '#2E8B9A' }}
          />
          {STATIONS.map((s, i) => (
            <span
              key={s.num}
              data-method-node
              className="absolute top-1/2 h-[10px] w-[10px] -translate-x-1/2 -translate-y-1/2 border transition-colors duration-300"
              style={{ left: `${((i + 0.5) / STATIONS.length) * 100}%`, borderColor: 'rgba(245,240,230,0.35)' }}
            />
          ))}
        </div>

        {/* stations */}
        <div className="mt-12 grid gap-10 lg:grid-cols-5 lg:gap-8">
          {STATIONS.map((s) => (
            <div key={s.num} data-method-station className="lg:opacity-35">
              <p className="font-display text-[64px] leading-none text-copper lg:text-[96px]">{s.num}</p>
              <h3 className="mt-4 font-sans text-[18px] font-semibold tracking-[0.01em] text-ivory">
                {s.title}
              </h3>
              <p className="mt-2 font-sans text-[14px] leading-[1.6] text-ivory/70">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
