import { useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { useGSAP } from '@gsap/react'
import LedgerRule from '@/components/app/LedgerRule'
import { CountUp, SplitWords, prefersReducedMotion } from './shared'

gsap.registerPlugin(ScrollTrigger)

const GAP_STATS = [
  {
    value: 3,
    format: (v: number) => `${Math.round(v)}`,
    label: 'reporting regimes a single facility must satisfy (NCCC, IFRS S2, GRI 305)',
  },
  {
    value: 40,
    format: (v: number) => `±${Math.round(v)}%`,
    label: 'typical gap between top-down estimates and facility-level reality',
  },
  {
    value: 15,
    format: (v: number) => `${Math.round(v)}th`,
    label: 'day of the month by which activity data is due, every month',
  },
]

/** Section 2 — The gap (home.md §2, light sand). */
export default function Gap() {
  const root = useRef<HTMLElement>(null)

  useGSAP(
    () => {
      if (prefersReducedMotion()) return
      const q = gsap.utils.selector(root)
      gsap.fromTo(
        q('[data-gap-rule]'),
        { scaleX: 0 },
        {
          scaleX: 1,
          transformOrigin: 'left',
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: { trigger: root.current, start: 'top 75%', once: true },
        },
      )
      gsap.fromTo(
        q('[data-split-word]'),
        { y: 28, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.7,
          stagger: 0.04,
          ease: 'power3.out',
          scrollTrigger: { trigger: root.current, start: 'top 72%', once: true },
        },
      )
      gsap.fromTo(
        q('[data-gap-body]'),
        { y: 24, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.7,
          delay: 0.2,
          ease: 'power3.out',
          scrollTrigger: { trigger: root.current, start: 'top 70%', once: true },
        },
      )
      gsap.fromTo(
        q('[data-gap-stat]'),
        { y: 32, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.7,
          stagger: 0.15,
          ease: 'power3.out',
          scrollTrigger: { trigger: q('[data-gap-stats]')[0], start: 'top 78%', once: true },
        },
      )
    },
    { scope: root },
  )

  return (
    <section id="gap" ref={root} className="bg-sand text-ink">
      <div className="mx-auto max-w-[1280px] px-8 py-24 max-md:px-5 md:py-32">
        <div data-gap-rule>
          <LedgerRule />
        </div>
        <p className="kicker mt-6 text-muted">01 — The Gap</p>
        <h2 className="mt-4 max-w-[900px] font-display text-[36px] leading-[1.1] md:text-[48px]">
          <SplitWords text="Nigeria cannot trade, report, or regulate what it cannot measure." />
        </h2>
        <p data-gap-body className="mt-8 max-w-[640px] font-sans text-[16px] leading-[1.6] text-ink/80">
          Nigeria&rsquo;s NDC and Long-Term Low-Emission Development Strategy commit the country to
          transparent reporting under the Paris Agreement&rsquo;s Enhanced Transparency Framework. Yet
          industrial emissions data still moves in spreadsheets, PDFs and email — unverifiable,
          unauditable, and disconnected from the national inventory. Regulators cannot see who
          reported. Operators cannot prove quality. Verifiers cannot scale.
        </p>

        <div data-gap-stats className="mt-16">
          {GAP_STATS.map((s) => (
            <div
              key={s.label}
              data-gap-stat
              className="flex items-center gap-8 border-t border-line/60 py-8 last:border-b max-md:flex-col max-md:items-start max-md:gap-3"
            >
              <CountUp
                value={s.value}
                format={s.format}
                duration={1200}
                className="w-[260px] shrink-0 font-display text-[56px] leading-none text-petrol md:text-[72px]"
              />
              <p className="max-w-[560px] font-sans text-[15px] leading-[1.6] text-ink/75">{s.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
