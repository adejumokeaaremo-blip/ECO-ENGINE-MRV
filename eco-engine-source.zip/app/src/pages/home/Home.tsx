import { useEffect } from 'react'
import Lenis from 'lenis'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import Hero from './Hero'
import Gap from './Gap'
import Method from './Method'
import SplitSection from './SplitSection'
import Roles from './Roles'
import Integrity from './Integrity'
import Founders from './Founders'
import { prefersReducedMotion } from './shared'

gsap.registerPlugin(ScrollTrigger)

/**
 * Page 01 — Landing / Home (`/`). Composition per design/home.md:
 * hero particle ledger field · the MRV gap · pinned 5-step workflow ·
 * "The AI accelerates. The human decides." split · role entry ·
 * integrity architecture · founders. (Navbar/Footer/demo strip live in Layout.)
 */
export default function Home() {
  useEffect(() => {
    if (prefersReducedMotion()) return
    const lenis = new Lenis({ lerp: 0.1, smoothWheel: true })
    lenis.on('scroll', ScrollTrigger.update)
    const tick = (time: number) => lenis.raf(time * 1000)
    gsap.ticker.add(tick)
    gsap.ticker.lagSmoothing(0)
    // smooth-scroll anchors through Lenis
    const onClick = (e: MouseEvent) => {
      const a = (e.target as HTMLElement).closest('a[href^="#"]') as HTMLAnchorElement | null
      if (!a) return
      const el = document.querySelector(a.getAttribute('href') ?? '')
      if (el) {
        e.preventDefault()
        lenis.scrollTo(el as HTMLElement, { offset: -64 })
      }
    }
    document.addEventListener('click', onClick)
    return () => {
      document.removeEventListener('click', onClick)
      gsap.ticker.remove(tick)
      lenis.destroy()
    }
  }, [])

  return (
    <main>
      <Hero />
      <Gap />
      <Method />
      <SplitSection />
      <Roles />
      <Integrity />
      <Founders />
    </main>
  )
}
