/**
 * Page 13 — Inventory Export Builder (`/compiler`), compiler-export.md.
 * Persona: S. Eze — National Inventory Compiler, NIMO.
 * Verified-only rule: every package is generated from regulator-verified data.
 */
import { useEffect, useMemo, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import {
  Check,
  ChevronRight,
  Download,
  FileDown,
  Package,
  X,
} from 'lucide-react'
import { toast } from 'sonner'
import JSZip from 'jszip'
import StatusChip from '@/components/app/StatusChip'
import HashChip from '@/components/app/HashChip'
import LedgerRule from '@/components/app/LedgerRule'
import DataTable, {
  DataTableCell,
  DataTableHead,
  DataTableRow,
} from '@/components/app/DataTable'
import { appendAudit, demoHash, truncateHash, useRole } from '@/lib/store'
import { EF_LIBRARY } from '@/lib/demo-data'
import { cn } from '@/lib/utils'

/* -------------------------------------------------- demo package constants */

type Sector = 'oil' | 'cement'

interface AdRow {
  category: string
  facility: string
  parameter: string
  value: string
  unit: string
  periods: number
  sector: Sector
}

/** AD table (compiler-export.md §2) — monthly averages over verified periods. */
const AD_ROWS: AdRow[] = [
  { category: '1.B.2 Oil & natural gas', facility: 'FS-4', parameter: 'Associated gas flared', value: '25.6', unit: 'MMscf/month avg', periods: 12, sector: 'oil' },
  { category: '1.A.1 Energy industries', facility: 'FS-4', parameter: 'Natural gas combusted', value: '16.9', unit: 'MMscf/month avg', periods: 12, sector: 'oil' },
  { category: '1.A.1 Energy industries', facility: 'FS-4', parameter: 'Diesel (gensets)', value: '17,900', unit: 'L/month avg', periods: 12, sector: 'oil' },
  { category: '2.A.1 Cement production', facility: 'SCW-L2', parameter: 'Clinker produced', value: '118,200', unit: 't/month avg', periods: 11, sector: 'cement' },
  { category: '2.A.1 Cement production (fuel)', facility: 'SCW-L2', parameter: 'Petcoke', value: '9,590', unit: 't/month avg', periods: 11, sector: 'cement' },
]

interface EfRow {
  category: string
  parameter: string
  ef: string
  provenance: string
  sector: Sector
}

/** EF table — factor values verbatim from EF_LIBRARY (design.md §8). */
const EF_ROWS: EfRow[] = [
  { category: '1.A.1', parameter: 'Natural gas combustion', ef: EF_LIBRARY[0].value, provenance: 'IPCC 2006 Vol. 2 Ch. 2 Table 2.2 (default) · 2006 · global default', sector: 'oil' },
  { category: '1.B.2', parameter: 'Associated gas flaring', ef: EF_LIBRARY[1].value, provenance: 'Derived per GGFR guidance + IPCC 2006 Vol. 2 Ch. 4 · illustrative · demo', sector: 'oil' },
  { category: '1.A.1', parameter: 'Diesel (gas/diesel oil)', ef: EF_LIBRARY[2].value, provenance: 'IPCC 2006 Vol. 2 Ch. 2 Table 2.2 (default) · 2006 · global default', sector: 'oil' },
  { category: '2.A.1', parameter: 'Clinker process CO₂', ef: EF_LIBRARY[4].value, provenance: 'IPCC 2006 Vol. 3 Ch. 2 Eq. 2.4 · 2006 · default', sector: 'cement' },
  { category: '2.A.1 (fuel)', parameter: 'Petroleum coke', ef: EF_LIBRARY[3].value, provenance: 'IPCC 2006 Vol. 2 Ch. 2 Table 2.2 (default) · 2006 · global default', sector: 'cement' },
]

interface EmRow {
  category: string
  tco2e: number
  uncertainty: string
  share: string
  sector: Sector
}

/** Emissions & uncertainty — excludes the Feb-2026 clinker query period. */
const EM_ROWS: EmRow[] = [
  { category: '2.A.1 Cement production', tco2e: 1028300, uncertainty: '±5%', share: '69%', sector: 'cement' },
  { category: '1.B.2 Oil & natural gas', tco2e: 247960, uncertainty: '±8%', share: '17%', sector: 'oil' },
  { category: '1.A.1 Energy industries', tco2e: 212740, uncertainty: '±7%', share: '14%', sector: 'oil' },
]

interface PackageRecord {
  id: string
  period: string
  generatedBy: string
  generatedAt: string
  categories: number
  total: string
  hash: string
  status: 'Sealed' | 'Received by NIMO'
}

const PACKAGE_HISTORY_SEED: PackageRecord[] = [
  {
    id: 'EXP-2026-FY26-001',
    period: 'FY Jul 2025 – Jun 2026',
    generatedBy: 'S. Eze',
    generatedAt: '14 Jul 2026 17:02',
    categories: 3,
    total: '1,489,000',
    hash: '0xc41a9f2c7b22d3a16e7751de3c8fd4e077ab88f0',
    status: 'Sealed',
  },
  {
    id: 'EXP-2026-Q3-002',
    period: 'Q3 FY26 (Jan – Mar 2026)',
    generatedBy: 'S. Eze',
    generatedAt: '02 Apr 2026 16:20',
    categories: 3,
    total: '372,400',
    hash: '0x77ab51de6e77d4e03c8f9f2c7b22d3a1c41a09c3',
    status: 'Received by NIMO',
  },
]

const GENERATION_STEPS = [
  'collecting verified records',
  'mapping categories',
  'attaching factor provenance',
  'computing uncertainty',
  'sealing package hash',
]

/* ---------------------------------------------------------------- helpers */

function csvEscape(v: string): string {
  return /[",\n]/.test(v) ? `"${v.replace(/"/g, '""')}"` : v
}

function csvString(headers: string[], rows: string[][]): string {
  return [
    '# Generated from regulator-verified data — ECO ENGINE demonstrator (demonstration data)',
    headers.map(csvEscape).join(','),
    ...rows.map((r) => r.map(csvEscape).join(',')),
  ].join('\n')
}

function downloadBlob(filename: string, blob: Blob) {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(url)
}

/** Oranienbaum numeral count-up (1.2s, on scroll into view, 30% threshold). */
function CountUp({
  value,
  format,
  className,
}: {
  value: number
  format: (v: number) => string
  className?: string
}) {
  const reduced =
    typeof window !== 'undefined' &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches
  const [display, setDisplay] = useState(() => (reduced ? format(value) : format(0)))
  const ref = useRef<HTMLSpanElement | null>(null)
  const started = useRef(false)
  useEffect(() => {
    const el = ref.current
    if (!el || reduced) return
    const io = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !started.current) {
          started.current = true
          const t0 = performance.now()
          const tick = (now: number) => {
            const p = Math.min(1, (now - t0) / 1200)
            const eased = 1 - Math.pow(1 - p, 3)
            setDisplay(format(value * eased))
            if (p < 1) requestAnimationFrame(tick)
          }
          requestAnimationFrame(tick)
          io.disconnect()
        }
      },
      { threshold: 0.3 },
    )
    io.observe(el)
    return () => io.disconnect()
  }, [value, format, reduced])
  return (
    <span ref={ref} className={className}>
      {display}
    </span>
  )
}

const fmtMt = (v: number) => (v / 1_000_000).toFixed(3)
const fmtVar = (v: number) => `+${v.toFixed(1)}%`

/* ------------------------------------------------------------------ page */

export default function Export() {
  const { persona } = useRole()
  const [period, setPeriod] = useState('fy26')
  const [sectors, setSectors] = useState<Record<Sector, boolean>>({ oil: true, cement: true })
  const [generating, setGenerating] = useState(false)
  const [stepIdx, setStepIdx] = useState(0)
  const [generation, setGeneration] = useState(0)
  const [packages, setPackages] = useState<PackageRecord[]>(PACKAGE_HISTORY_SEED)
  const [openPackage, setOpenPackage] = useState<PackageRecord | null>(null)
  const [received, setReceived] = useState(false)
  const [confirmReceive, setConfirmReceive] = useState(false)

  const activeSectors = useMemo(
    () => (Object.keys(sectors) as Sector[]).filter((s) => sectors[s]),
    [sectors],
  )
  const adRows = AD_ROWS.filter((r) => activeSectors.includes(r.sector))
  const efRows = EF_ROWS.filter((r) => activeSectors.includes(r.sector))
  const emRows = EM_ROWS.filter((r) => activeSectors.includes(r.sector))
  const emTotal = emRows.reduce((a, r) => a + r.tco2e, 0)
  const latest = packages[0]

  const generate = () => {
    if (generating) return
    setGenerating(true)
    setStepIdx(0)
    GENERATION_STEPS.forEach((_, i) => {
      setTimeout(() => setStepIdx(i), i * 450)
    })
    setTimeout(() => {
      const seq = packages.length + 1
      const id = `EXP-2026-FY26-${String(seq).padStart(3, '0')}`
      const hash = demoHash(`${id}|${period}|${activeSectors.join('+')}|${emTotal}`)
      const rec: PackageRecord = {
        id,
        period: 'FY Jul 2025 – Jun 2026',
        generatedBy: 'S. Eze',
        generatedAt: '15 Jul 2026 ' + new Date().toTimeString().slice(0, 5),
        categories: new Set(emRows.map((r) => r.category.split(' ')[0])).size,
        total: emTotal.toLocaleString('en-US'),
        hash,
        status: 'Sealed',
      }
      setPackages((p) => [rec, ...p])
      setReceived(false)
      setGenerating(false)
      setGeneration((g) => g + 1)
      appendAudit({
        actor: persona.name,
        role: 'compiler',
        action: 'EXPORT_GENERATED',
        entity: id,
        detail: `Inventory export package sealed — ${emRows.length} IPCC categories · ${emTotal.toLocaleString('en-US')} tCO2e · generated from regulator-verified data`,
      })
      toast.success(`Package ${id} sealed — logged to audit chain.`)
    }, GENERATION_STEPS.length * 450 + 500)
  }

  const markReceived = () => {
    setConfirmReceive(false)
    setReceived(true)
    appendAudit({
      actor: persona.name,
      role: 'compiler',
      action: 'EXPORT_RECEIVED',
      entity: latest.id,
      detail: `Package ${latest.id} acknowledged by NIMO receiving officer`,
    })
    setPackages((p) => p.map((r, i) => (i === 0 ? { ...r, status: 'Received by NIMO' } : r)))
    toast.success('Package marked received — logged to audit chain.')
  }

  const downloadCsv = (name: string, headers: string[], rows: string[][]) => {
    downloadBlob(name, new Blob([csvString(headers, rows)], { type: 'text/csv;charset=utf-8' }))
    toast(`${name} — generated from regulator-verified data.`)
  }

  const downloadZip = async () => {
    const zip = new JSZip()
    zip.file(
      'activity-data.csv',
      csvString(
        ['IPCC category', 'Facility', 'Parameter', 'Value', 'Unit', 'Periods'],
        adRows.map((r) => [r.category, r.facility, r.parameter, r.value, r.unit, String(r.periods)]),
      ),
    )
    zip.file(
      'emission-factors.csv',
      csvString(
        ['IPCC category', 'Parameter', 'EF value', 'Provenance'],
        efRows.map((r) => [r.category, r.parameter, r.ef, r.provenance]),
      ),
    )
    zip.file(
      'emissions-uncertainty.csv',
      csvString(
        ['IPCC category', 'Emissions (tCO2e)', 'Uncertainty', 'Share'],
        [
          ...emRows.map((r) => [r.category, String(r.tco2e), r.uncertainty, r.share]),
          ['Total', String(emTotal), '±5.4%', '100%'],
        ],
      ),
    )
    zip.file(
      'reconciliation-note.txt',
      [
        'Generated from regulator-verified data.',
        `Bottom-up (this package): ${fmtMt(emTotal)} MtCO2e`,
        'Top-down sectoral estimate: 1.412 MtCO2e',
        'Variance: +5.4% — within combined uncertainty (±7.1%).',
        'Largest contributor: flaring volumes above sectoral model assumption for Q1 2026 — consistent with verified turnaround events.',
        `Package hash: ${latest.hash}`,
      ].join('\n'),
    )
    const blob = await zip.generateAsync({ type: 'blob' })
    downloadBlob(`${latest.id}.zip`, blob)
    toast(`${latest.id}.zip — generated from regulator-verified data.`)
  }

  const stagger = (i: number) => ({
    initial: { opacity: 0, y: 8 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.4, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] as [number, number, number, number] },
  })

  return (
    <div className="flex flex-col gap-10">
      {/* §1 — page header */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        className="flex flex-wrap items-end justify-between gap-4"
      >
        <div>
          <p className="kicker text-muted">NIMO / Inventory Export</p>
          <h1 className="mt-2 font-display text-[40px] leading-[1.05] text-ink">Inventory export.</h1>
          <p className="mt-3 max-w-[560px] font-sans text-[15px] leading-[1.6] text-muted">
            From verified facility records to the national inventory — formatted for the IPCC
            inventory software / RISQ.
          </p>
        </div>
        <StatusChip status="Generated from regulator-verified data" kind="verified" />
      </motion.div>

      {/* §2 — builder + preview */}
      <div className="grid grid-cols-1 gap-8 lg:grid-cols-5">
        {/* builder panel */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
          className="rounded-[2px] border border-line/60 bg-ivory p-6 lg:col-span-2"
        >
          <LedgerRule className="mb-4" />
          <p className="kicker text-muted">Build a package</p>

          <div className="mt-5 flex flex-col gap-5">
            <motion.div {...stagger(0)}>
              <label htmlFor="period" className="kicker block text-muted">Period</label>
              <select
                id="period"
                value={period}
                onChange={(e) => setPeriod(e.target.value)}
                className="mt-2 w-full rounded-[2px] border border-line bg-sand px-3 py-2.5 font-mono text-[13px] text-ink focus:border-copper"
              >
                <option value="fy26">FY Jul 2025 – Jun 2026</option>
                <option value="q4">Q4 FY26 (Apr – Jun 2026)</option>
                <option value="custom">Custom range…</option>
              </select>
            </motion.div>

            <motion.div {...stagger(1)}>
              <p className="kicker text-muted">Sector scope</p>
              <div className="mt-2 flex flex-col gap-2">
                {(
                  [
                    ['oil', 'Oil & gas'],
                    ['cement', 'Cement'],
                  ] as [Sector, string][]
                ).map(([key, label]) => (
                  <label key={key} className="flex cursor-pointer items-center gap-3 font-sans text-[14px] text-ink">
                    <input
                      type="checkbox"
                      checked={sectors[key]}
                      onChange={() => setSectors((s) => ({ ...s, [key]: !s[key] }))}
                      className="h-4 w-4 rounded-[2px] border-line accent-[#0F4C5C]"
                    />
                    {label}
                  </label>
                ))}
              </div>
              <p className="mt-3 font-sans text-[13px] leading-[1.5] text-muted">
                Facilities map to IPCC 2006 categories via their approved monitoring plans.
              </p>
            </motion.div>

            {/* coverage check */}
            <motion.div {...stagger(2)} className="rounded-[2px] border border-line/60 bg-sand p-4">
              <p className="kicker text-muted">Coverage check</p>
              <div className="mt-3 flex flex-col gap-3">
                <div className="flex items-start gap-2">
                  <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-petrol" strokeWidth={2.5} />
                  <p className="font-sans text-[13px] leading-[1.5] text-ink">
                    NigerDelta Flow Station 4 · <span className="font-mono text-[12px] text-petrol">12/12 months verified</span>
                  </p>
                </div>
                <div className="flex items-start gap-2">
                  <span className="mt-[5px] h-[6px] w-[6px] shrink-0 bg-copper" />
                  <p className="font-sans text-[13px] leading-[1.5] text-ink">
                    Sahel Cement Works L2 ·{' '}
                    <span className="font-mono text-[12px] text-copper">
                      11/12 months verified — Feb 2026 under query, excluded
                    </span>
                  </p>
                </div>
                <p className="font-sans text-[12px] leading-[1.5] text-muted">
                  Only verified periods enter a package. Exclusions are listed in the
                  reconciliation note.
                </p>
              </div>
            </motion.div>

            <motion.div {...stagger(3)}>
              <button
                type="button"
                onClick={generate}
                disabled={generating || activeSectors.length === 0}
                className={cn(
                  'w-full rounded-[2px] bg-copper px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ivory transition-all duration-200',
                  'hover:-translate-y-px hover:bg-copper-light hover:text-ink',
                  'disabled:translate-y-0 disabled:opacity-40',
                )}
              >
                {generating ? 'Generating…' : 'Generate package'}
              </button>
              {/* generation progress hairline + cycling captions */}
              <div className="mt-3 h-[2px] w-full bg-line/40">
                <motion.div
                  className="h-full bg-copper"
                  initial={false}
                  animate={{ width: generating ? `${((stepIdx + 1) / GENERATION_STEPS.length) * 100}%` : generation > 0 ? '100%' : '0%' }}
                  transition={{ duration: 0.4, ease: [0.4, 0, 0.2, 1] }}
                />
              </div>
              <div className="mt-2 h-4">
                <AnimatePresence mode="wait">
                  {generating && (
                    <motion.p
                      key={stepIdx}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: 0.3 }}
                      className="data-s text-copper"
                    >
                      {GENERATION_STEPS[stepIdx]}
                      {stepIdx < GENERATION_STEPS.length - 1 ? ' →' : '…'}
                    </motion.p>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>
          </div>
        </motion.div>

        {/* preview area */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
          className="lg:col-span-3"
        >
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="kicker text-muted">
              Package preview — FY Jul 2025–Jun 2026 (demonstration data)
            </p>
            <HashChip hash={latest.hash} />
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={`${generation}-${activeSectors.join('-')}`}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.4 }}
              className="mt-4 flex flex-col gap-8"
            >
              {/* AD table */}
              <motion.div {...stagger(0)}>
                <div className="mb-2 flex items-center justify-between">
                  <p className="kicker text-ink">Activity data (AD)</p>
                  <button
                    type="button"
                    onClick={() =>
                      downloadCsv(
                        'activity-data.csv',
                        ['IPCC category', 'Facility', 'Parameter', 'Value', 'Unit', 'Periods'],
                        adRows.map((r) => [r.category, r.facility, r.parameter, r.value, r.unit, String(r.periods)]),
                      )
                    }
                    className="link-sweep flex items-center gap-1.5 font-sans text-[12px] font-semibold uppercase tracking-[0.12em] text-petrol"
                  >
                    <FileDown className="h-3.5 w-3.5" strokeWidth={1.75} /> CSV
                  </button>
                </div>
                <DataTable>
                  <DataTableHead columns={['IPCC category', 'Facility', 'Parameter', 'Value', 'Unit', 'Periods']} />
                  <tbody>
                    {adRows.map((r) => (
                      <DataTableRow key={r.category + r.parameter}>
                        <DataTableCell>{r.category}</DataTableCell>
                        <DataTableCell>{r.facility}</DataTableCell>
                        <DataTableCell mono={false}>{r.parameter}</DataTableCell>
                        <DataTableCell>{r.value}</DataTableCell>
                        <DataTableCell className="text-muted">{r.unit}</DataTableCell>
                        <DataTableCell>{r.periods}</DataTableCell>
                      </DataTableRow>
                    ))}
                  </tbody>
                </DataTable>
              </motion.div>

              {/* EF table */}
              <motion.div {...stagger(1)}>
                <div className="mb-2 flex items-center justify-between">
                  <p className="kicker text-ink">Emission factors (EF) — provenance</p>
                  <button
                    type="button"
                    onClick={() =>
                      downloadCsv(
                        'emission-factors.csv',
                        ['IPCC category', 'Parameter', 'EF value', 'Provenance'],
                        efRows.map((r) => [r.category, r.parameter, r.ef, r.provenance]),
                      )
                    }
                    className="link-sweep flex items-center gap-1.5 font-sans text-[12px] font-semibold uppercase tracking-[0.12em] text-petrol"
                  >
                    <FileDown className="h-3.5 w-3.5" strokeWidth={1.75} /> CSV
                  </button>
                </div>
                <DataTable>
                  <DataTableHead columns={['Category', 'Parameter', 'EF value', 'Provenance (source · version · year · region)']} />
                  <tbody>
                    {efRows.map((r) => (
                      <DataTableRow key={r.category + r.parameter}>
                        <DataTableCell>{r.category}</DataTableCell>
                        <DataTableCell mono={false}>{r.parameter}</DataTableCell>
                        <DataTableCell>{r.ef}</DataTableCell>
                        <DataTableCell className="text-[11px] text-muted">{r.provenance}</DataTableCell>
                      </DataTableRow>
                    ))}
                  </tbody>
                </DataTable>
              </motion.div>

              {/* emissions & uncertainty */}
              <motion.div {...stagger(2)}>
                <div className="mb-2 flex items-center justify-between">
                  <p className="kicker text-ink">Emissions & uncertainty</p>
                  <div className="flex items-center gap-4">
                    <button
                      type="button"
                      onClick={() =>
                        downloadCsv(
                          'emissions-uncertainty.csv',
                          ['IPCC category', 'Emissions (tCO2e)', 'Uncertainty', 'Share'],
                          [
                            ...emRows.map((r) => [r.category, String(r.tco2e), r.uncertainty, r.share]),
                            ['Total', String(emTotal), '±5.4%', '100%'],
                          ],
                        )
                      }
                      className="link-sweep flex items-center gap-1.5 font-sans text-[12px] font-semibold uppercase tracking-[0.12em] text-petrol"
                    >
                      <FileDown className="h-3.5 w-3.5" strokeWidth={1.75} /> CSV
                    </button>
                    <button
                      type="button"
                      onClick={downloadZip}
                      className="flex items-center gap-2 rounded-[2px] bg-petrol px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ivory transition-all duration-200 hover:-translate-y-px hover:bg-petrol-deep"
                    >
                      <Download className="h-3.5 w-3.5" strokeWidth={1.75} />
                      Download package (.zip)
                    </button>
                  </div>
                </div>
                <DataTable>
                  <DataTableHead columns={['IPCC category', 'Emissions (tCO₂e)', 'Uncertainty', 'Share']} />
                  <tbody>
                    {emRows.map((r) => (
                      <DataTableRow key={r.category}>
                        <DataTableCell>{r.category}</DataTableCell>
                        <DataTableCell>{r.tco2e.toLocaleString('en-US')}</DataTableCell>
                        <DataTableCell>{r.uncertainty}</DataTableCell>
                        <DataTableCell className="text-muted">{r.share}</DataTableCell>
                      </DataTableRow>
                    ))}
                    <tr className="border-b border-line/40 bg-petrol/[0.06]">
                      <DataTableCell className="font-semibold text-petrol">Total</DataTableCell>
                      <DataTableCell className="font-semibold text-petrol">
                        {emTotal.toLocaleString('en-US')}
                      </DataTableCell>
                      <DataTableCell className="font-semibold text-petrol">±5.4%</DataTableCell>
                      <DataTableCell className="font-semibold text-petrol">100%</DataTableCell>
                    </tr>
                  </tbody>
                </DataTable>
                <p className="mt-2 font-sans text-[12px] text-muted">
                  Excludes the Feb-2026 clinker query period. Generated from regulator-verified data.
                </p>
              </motion.div>
            </motion.div>
          </AnimatePresence>
        </motion.div>
      </div>

      {/* §3 — reconciliation note (dark band) */}
      <section className="-mx-8 bg-petrol-deep px-8 py-12">
        <div className="mx-auto max-w-[1200px]">
          <LedgerRule dark className="mb-4" />
          <p className="kicker text-copper-light">Reconciliation vs top-down</p>
          <div className="mt-8 grid grid-cols-1 gap-10 md:grid-cols-3">
            <div>
              <p className="kicker text-ivory/50">Bottom-up — this package</p>
              <p className="mt-2 font-display text-[48px] leading-none text-ivory">
                <CountUp value={emTotal} format={fmtMt} />
                <span className="text-[0.5em]"> MtCO₂e</span>
              </p>
            </div>
            <div>
              <p className="kicker text-ivory/50">Top-down sectoral estimate</p>
              <p className="mt-2 font-display text-[48px] leading-none text-ivory">
                <CountUp value={1412000} format={fmtMt} />
                <span className="text-[0.5em]"> MtCO₂e</span>
              </p>
            </div>
            <div>
              <p className="kicker text-ivory/50">Variance</p>
              <p className="mt-2 font-display text-[48px] leading-none text-copper-light">
                <CountUp value={5.4} format={fmtVar} />
              </p>
            </div>
          </div>
          <p className="mt-8 max-w-[720px] font-sans text-[13px] leading-[1.6] text-ivory/70">
            Variance within combined uncertainty (±7.1%). Largest contributor: flaring volumes
            above sectoral model assumption for Q1 2026 — consistent with verified turnaround
            events. Note sealed with package hash <span className="font-mono text-[11px] text-copper-light">{truncateHash(latest.hash)}</span>.
          </p>
        </div>
      </section>

      {/* §4 — handover checklist */}
      <motion.section
        initial={{ opacity: 0, y: 16 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-15%' }}
        transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        className="rounded-[2px] border border-line/60 bg-ivory p-6"
      >
        <LedgerRule className="mb-4" />
        <p className="kicker text-muted">Handover checklist — DADS-compatible receiving layer</p>
        <div className="mt-5 flex flex-col gap-3">
          {[
            'AD package complete for scope',
            'EF provenance strings attached',
            'Uncertainty propagated per IPCC 2006 Vol. 1 Ch. 3',
            'Exclusions documented (Feb 2026 clinker)',
            'Reconciliation note attached',
          ].map((item, i) => (
            <motion.div
              key={item}
              initial={{ opacity: 0, x: -6 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.3, delay: i * 0.25 }}
              className="flex items-center gap-3"
            >
              <span className="flex h-4 w-4 items-center justify-center rounded-[2px] bg-petrol">
                <Check className="h-3 w-3 text-ivory" strokeWidth={3} />
              </span>
              <span className="font-sans text-[14px] text-ink">{item}</span>
            </motion.div>
          ))}
          <motion.div
            initial={{ opacity: 0, x: -6 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.3, delay: 5 * 0.25 }}
            className="flex items-center gap-3"
          >
            <span className="flex h-4 w-4 items-center justify-center rounded-[2px] bg-petrol">
              <Check className="h-3 w-3 text-ivory" strokeWidth={3} />
            </span>
            <span className="font-sans text-[14px] text-ink">Package hash sealed</span>
            <HashChip hash={latest.hash} />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: -6 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.3, delay: 6 * 0.25 }}
            className="flex flex-wrap items-center gap-3"
          >
            <span
              className={cn(
                'flex h-4 w-4 items-center justify-center rounded-[2px]',
                received || latest.status === 'Received by NIMO' ? 'bg-petrol' : 'border border-copper',
              )}
            >
              {(received || latest.status === 'Received by NIMO') && (
                <Check className="h-3 w-3 text-ivory" strokeWidth={3} />
              )}
            </span>
            <span className={cn('font-sans text-[14px]', received || latest.status === 'Received by NIMO' ? 'text-ink' : 'text-copper')}>
              Acknowledged by NIMO receiving officer
            </span>
            {!(received || latest.status === 'Received by NIMO') && (
              <button
                type="button"
                onClick={() => setConfirmReceive(true)}
                className="rounded-[2px] border border-copper px-3 py-1.5 font-sans text-[11px] font-semibold uppercase tracking-[0.12em] text-copper transition-all duration-200 hover:-translate-y-px hover:bg-copper hover:text-ivory"
              >
                Mark received
              </button>
            )}
            {(received || latest.status === 'Received by NIMO') && (
              <StatusChip status="Received by NIMO" kind="verified" />
            )}
          </motion.div>
        </div>
      </motion.section>

      {/* §5 — package history */}
      <section>
        <LedgerRule className="mb-4" />
        <p className="kicker text-muted">Package history</p>
        <div className="mt-4">
          <DataTable>
            <DataTableHead columns={['Package ID', 'Period', 'Generated by / at', 'Categories', 'Total tCO₂e', 'Hash', 'Status', '']} />
            <tbody>
              {packages.map((p, i) => (
                <DataTableRow key={p.id} onClick={() => setOpenPackage(p)} className="motion-safe:animate-none">
                  <DataTableCell>
                    <motion.span
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.35, delay: i * 0.04 }}
                      className="inline-flex items-center gap-2"
                    >
                      <Package className="h-3.5 w-3.5 text-muted" strokeWidth={1.75} />
                      {p.id}
                    </motion.span>
                  </DataTableCell>
                  <DataTableCell>{p.period}</DataTableCell>
                  <DataTableCell>{p.generatedBy} · {p.generatedAt}</DataTableCell>
                  <DataTableCell>{p.categories} cats</DataTableCell>
                  <DataTableCell>{p.total}</DataTableCell>
                  <DataTableCell mono={false}>
                    <HashChip hash={p.hash} />
                  </DataTableCell>
                  <DataTableCell mono={false}>
                    <StatusChip status={p.status} kind="verified" />
                  </DataTableCell>
                  <DataTableCell>
                    <ChevronRight className="h-4 w-4 text-muted" strokeWidth={1.75} />
                  </DataTableCell>
                </DataTableRow>
              ))}
            </tbody>
          </DataTable>
        </div>
      </section>

      {/* package manifest drawer */}
      <AnimatePresence>
        {openPackage && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25 }}
              onClick={() => setOpenPackage(null)}
              className="fixed inset-0 z-50 bg-petrol-deep/60 backdrop-blur-[4px]"
            />
            <motion.aside
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
              className="fixed right-0 top-0 z-50 flex h-full w-full max-w-[560px] flex-col border-l border-line bg-ivory"
            >
              <div className="flex items-start justify-between border-b border-line/60 p-6">
                <div>
                  <p className="kicker text-muted">Package manifest</p>
                  <h3 className="mt-2 font-sans text-[18px] font-semibold tracking-[0.01em] text-ink">
                    {openPackage.id}
                  </h3>
                  <p className="data-s mt-1 text-muted">{openPackage.period}</p>
                </div>
                <div className="flex items-center gap-3">
                  <StatusChip status={openPackage.status} kind="verified" />
                  <button
                    type="button"
                    onClick={() => setOpenPackage(null)}
                    aria-label="Close"
                    className="rounded-[2px] p-1.5 text-muted transition-colors hover:text-ink"
                  >
                    <X className="h-4 w-4" strokeWidth={1.75} />
                  </button>
                </div>
              </div>
              <div className="flex-1 overflow-y-auto p-6">
                <div className="flex flex-col gap-5">
                  {[
                    ['Generated by / at', `${openPackage.generatedBy} · ${openPackage.generatedAt}`],
                    ['IPCC categories', `${openPackage.categories} — 1.A.1 · 1.B.2 · 2.A.1`],
                    ['Total emissions', `${openPackage.total} tCO₂e ±5.4%`],
                    ['Scope', 'Oil & gas · Cement — verified periods only (Feb 2026 clinker excluded)'],
                  ].map(([k, v]) => (
                    <div key={k} className="flex flex-col gap-1 border-b border-line/40 pb-3">
                      <span className="kicker text-muted">{k}</span>
                      <span className="font-sans text-[14px] text-ink">{v}</span>
                    </div>
                  ))}
                  <div className="flex flex-col gap-1 border-b border-line/40 pb-3">
                    <span className="kicker text-muted">Package hash</span>
                    <HashChip hash={openPackage.hash} expanded />
                  </div>
                  <p className="font-sans text-[12px] leading-[1.5] text-muted">
                    Generated from regulator-verified data. Manifest snapshot: AD / EF / uncertainty
                    tables as sealed at generation time; checklist state and provenance strings
                    frozen under the package hash.
                  </p>
                </div>
              </div>
              <div className="border-t border-line/60 p-6">
                <button
                  type="button"
                  onClick={() => {
                    setOpenPackage(null)
                    toast('Open the audit trail to inspect this package on the chain.')
                  }}
                  className="link-sweep font-sans text-[13px] font-semibold text-petrol"
                >
                  View on audit chain →
                </button>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* mark-received confirmation modal */}
      <AnimatePresence>
        {confirmReceive && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25 }}
              onClick={() => setConfirmReceive(false)}
              className="fixed inset-0 z-50 bg-petrol-deep/60 backdrop-blur-[4px]"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.97 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.97 }}
              transition={{ duration: 0.25 }}
              className="fixed left-1/2 top-1/2 z-50 w-[min(560px,calc(100vw-40px))] -translate-x-1/2 -translate-y-1/2 rounded-[2px] border border-line bg-ivory p-6"
              role="dialog"
              aria-modal="true"
            >
              <p className="kicker text-muted">Confirm receipt</p>
              <h3 className="mt-2 font-sans text-[18px] font-semibold text-ink">
                Mark {latest.id} as received by NIMO?
              </h3>
              <p className="mt-3 font-sans text-[13px] leading-[1.6] text-muted">
                This records the receiving officer's acknowledgement against package hash{' '}
                <span className="font-mono text-[11px]">{truncateHash(latest.hash)}</span> and
                appends the event to the audit chain. It cannot be undone in the demonstrator.
              </p>
              <div className="mt-6 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setConfirmReceive(false)}
                  className="rounded-[2px] border border-ink/30 px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ink transition-all duration-200 hover:-translate-y-px hover:border-ink hover:bg-sand"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={markReceived}
                  className="rounded-[2px] bg-petrol px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ivory transition-all duration-200 hover:-translate-y-px hover:bg-petrol-deep"
                >
                  Mark received
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  )
}
