/**
 * Page 08 — Verifier Queue (`/verifier`), per design/verifier-queue.md.
 * Workload KPIs · filter bar · queue table with anomaly severity + age ·
 * queue discipline strip (dark) · recently decided ledger feed.
 * Rows link to the signature review workspace (/verifier/review/:id).
 */
import { useMemo, useState } from 'react'
import { Link, useNavigate } from 'react-router'
import { motion } from 'framer-motion'
import { ArrowDown, ArrowUp, ArrowUpDown, Search } from 'lucide-react'
import { cn } from '@/lib/utils'
import { FACILITIES } from '@/lib/demo-data'
import { useAuditTrail, useSubmissions } from '@/lib/store'
import type { Submission } from '@/lib/store'
import KpiStat from '@/components/app/KpiStat'
import LedgerRule from '@/components/app/LedgerRule'
import AILabel from '@/components/app/AILabel'
import HashChip from '@/components/app/HashChip'
import StatusChip from '@/components/app/StatusChip'
import DataTable, {
  DataTableCell,
  DataTableEmpty,
  DataTableRow,
} from '@/components/app/DataTable'
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet'
import {
  AGE_DAYS,
  AGE_DISPLAY,
  STREAM_LABEL,
  flagRuleExplanation,
  flagSeverity,
} from './review-detail'

const EASE = [0.22, 1, 0.36, 1] as [number, number, number, number]

type StatusFilter = 'Pending' | 'Queried' | 'Decided' | null
type SortKey = 'age' | 'estimate'

function estimateValue(s: Submission): number {
  return Number(s.aiEstimate.replace(/[^\d.]/g, '')) || 0
}

function ageDays(s: Submission): number {
  if (AGE_DAYS[s.id] !== undefined) return AGE_DAYS[s.id]
  const t = Date.parse(s.submittedAt)
  if (Number.isNaN(t)) return 0
  return Math.max(0, (Date.parse('2026-07-15T23:59:00Z') - t) / 86_400_000)
}

function ageDisplay(s: Submission): string {
  if (AGE_DISPLAY[s.id]) return AGE_DISPLAY[s.id]
  const d = ageDays(s)
  if (d < 1) return `${Math.max(1, Math.round(d * 24))} h`
  return `${Math.round(d)} d`
}

/* ---------------------------------------------------- flag cell (§3) */

function FlagCell({ flag }: { flag: string | null }) {
  const severity = flagSeverity(flag)
  if (!flag) {
    return (
      <span className="inline-flex items-center gap-2">
        <span className="h-2 w-2 shrink-0 rotate-45 bg-petrol" aria-hidden="true" />
        <span className="data-s text-petrol">no flags</span>
      </span>
    )
  }
  return (
    <span
      className="inline-flex cursor-help items-center gap-2"
      title={flagRuleExplanation(flag)}
    >
      <motion.span
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.3, ease: EASE }}
        className={cn('h-2 w-2 shrink-0 rotate-45', severity === 'high' ? 'bg-alert' : 'bg-copper')}
        aria-hidden="true"
      />
      <span className={cn('data-s', severity === 'high' ? 'text-alert' : 'text-copper')}>
        {flag}
      </span>
    </span>
  )
}

/* --------------------------------------------------------- page */

export default function Queue() {
  const submissions = useSubmissions()
  const audit = useAuditTrail()
  const navigate = useNavigate()

  const [search, setSearch] = useState('')
  const [facilityFilter, setFacilityFilter] = useState<'all' | string>('all')
  const [flagFilter, setFlagFilter] = useState<'all' | 'flagged' | 'clean'>('all')
  const [statusFilter, setStatusFilter] = useState<StatusFilter>(null)
  const [sortKey, setSortKey] = useState<SortKey>('age')
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc') // oldest first
  const [queryView, setQueryView] = useState<Submission | null>(null)

  /* Section 2 — workload KPIs (seed baseline per design + live decisions) */
  const pending = submissions.filter((s) => s.status === 'Pending')
  const queried = submissions.filter((s) => s.status === 'Queried')
  const acceptedLive = submissions.filter((s) => s.status === 'Accepted').length
  const rejectedLive = submissions.filter((s) => s.status === 'Rejected').length

  const rows = useMemo(() => {
    const q = search.trim().toLowerCase()
    const filtered = submissions.filter((s) => {
      const facility = FACILITIES.find((f) => f.id === s.facilityId)
      if (facilityFilter !== 'all' && s.facilityId !== facilityFilter) return false
      if (flagFilter === 'flagged' && !s.flag) return false
      if (flagFilter === 'clean' && s.flag) return false
      if (statusFilter === 'Decided' && s.status !== 'Accepted' && s.status !== 'Rejected')
        return false
      if (statusFilter && statusFilter !== 'Decided' && s.status !== statusFilter) return false
      if (q) {
        const hay =
          `${s.id} ${facility?.name ?? ''} ${s.streamLabel} ${STREAM_LABEL[s.id] ?? ''} ${s.period}`.toLowerCase()
        if (!hay.includes(q)) return false
      }
      return true
    })
    const dir = sortDir === 'asc' ? 1 : -1
    return [...filtered].sort((a, b) =>
      sortKey === 'age'
        ? (ageDays(a) - ageDays(b)) * dir
        : (estimateValue(a) - estimateValue(b)) * dir,
    )
  }, [submissions, search, facilityFilter, flagFilter, statusFilter, sortKey, sortDir])

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'))
    else {
      setSortKey(key)
      setSortDir(key === 'age' ? 'desc' : 'asc')
    }
  }

  /* Section 5 — recently decided: live verifier decisions first, legacy fill */
  const decidedFeed = useMemo(() => {
    const live = [...audit]
      .reverse()
      .filter((e) => e.role === 'verifier' && e.action.startsWith('SUBMISSION_'))
      .map((e) => ({
        key: `live-${e.seq}`,
        tone:
          e.action === 'SUBMISSION_ACCEPTED'
            ? ('teal' as const)
            : e.action === 'SUBMISSION_REJECTED'
              ? ('alert' as const)
              : ('copper' as const),
        label: `${
          e.action === 'SUBMISSION_ACCEPTED'
            ? 'Accepted'
            : e.action === 'SUBMISSION_REJECTED'
              ? 'Rejected'
              : 'Queried'
        } — ${e.entity}`,
        ts: e.ts.replace('T', ' ').slice(0, 16),
        hash: e.hash,
      }))
    const legacy = [
      {
        key: 'legacy-1',
        tone: 'teal' as const,
        label: 'Accepted — SUB-2606-019 diesel, May 2026 · 48.3 tCO₂e',
        ts: '2026-07-10 09:14',
        hash: '0x3c8f7a21b9e04d56c812aa90f77d4e0d4e0d4e01',
      },
      {
        key: 'legacy-2',
        tone: 'teal' as const,
        label: 'Accepted — SUB-2605-101 fuel gas, Apr 2026 · 2,204 tCO₂e',
        ts: '2026-05-15 10:02',
        hash: '0x77aa10bc34d9e05f62c0a1b3d45e6f708192a3b4',
      },
      {
        key: 'legacy-3',
        tone: 'alert' as const,
        label: 'Rejected — SUB-2604-097 clinker, Apr 2026 · duplicate period',
        ts: '2026-04-16 12:40',
        hash: '0x1bd042cf9a88e7310f5c6d7e8091a2b3c4d5e6f7',
      },
    ]
    return [...live, ...legacy].slice(0, 4)
  }, [audit])

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: EASE }}
      className="pb-24"
    >
      {/* Section 1 — page header */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: EASE }}
        className="flex flex-wrap items-end justify-between gap-6"
      >
        <div>
          <LedgerRule className="mb-4 w-24" />
          <h1 className="font-display text-[40px] leading-[1.05] text-ink">Verification queue.</h1>
          <p className="mt-3 max-w-[520px] font-sans text-[15px] leading-[1.6] text-muted">
            The engine estimates. You decide. No figure enters the official record without your
            signature.
          </p>
        </div>
        <div className="flex items-center gap-3 rounded-[2px] border border-line/60 bg-ivory px-4 py-3">
          <span className="flex h-7 w-7 items-center justify-center bg-petrol font-sans text-[11px] font-semibold text-ivory">
            FO
          </span>
          <span className="flex flex-col">
            <span className="font-sans text-[13px] font-medium text-ink">Dr. F. Okafor</span>
            <span className="data-s text-muted">ISO 14065 · AV/2024/0142 (demo)</span>
          </span>
        </div>
      </motion.div>

      {/* Section 2 — workload KPI row */}
      <div className="mt-12 grid grid-cols-2 gap-8 border-t border-line/60 pt-8 lg:grid-cols-4">
        {[
          {
            label: 'Awaiting your decision',
            value: pending.length,
            sub: 'oldest is 2 days',
            tone: 'text-copper',
          },
          {
            label: 'Queried, awaiting operator',
            value: queried.length,
            sub: 'belt-scale logs requested',
            tone: 'text-copper',
          },
          {
            label: 'Accepted this cycle year',
            value: 47 + acceptedLive,
            sub: '0 rejections overturned',
            tone: 'text-petrol',
          },
          {
            label: 'Rejected this cycle year',
            value: 2 + rejectedLive,
            sub: 'both returned with evidence gaps',
            tone: 'text-ink',
          },
        ].map((k, i) => (
          <motion.div
            key={k.label}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: EASE, delay: 0.1 + i * 0.08 }}
          >
            <KpiStat label={k.label} value={k.value} sub={k.sub} />
          </motion.div>
        ))}
      </div>

      {/* Section 3 — filter bar */}
      <div className="mt-12 flex flex-wrap items-center gap-3">
        <label className="flex min-w-[260px] flex-1 items-center gap-2 rounded-[2px] border border-line/60 bg-ivory px-3 py-2 focus-within:border-copper">
          <Search className="h-4 w-4 shrink-0 text-muted" strokeWidth={1.75} />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="submission, facility, stream…"
            className="w-full bg-transparent font-mono text-[13px] text-ink outline-none placeholder:text-muted/70"
          />
        </label>
        <select
          value={facilityFilter}
          onChange={(e) => setFacilityFilter(e.target.value)}
          className="rounded-[2px] border border-line/60 bg-ivory px-3 py-2 font-sans text-[13px] text-ink outline-none focus:border-copper"
        >
          <option value="all">All facilities</option>
          <option value="FAC-RIV-004">NigerDelta FS-4</option>
          <option value="FAC-KOG-002">Sahel Cement L2</option>
        </select>
        <select
          value={flagFilter}
          onChange={(e) => setFlagFilter(e.target.value as typeof flagFilter)}
          className="rounded-[2px] border border-line/60 bg-ivory px-3 py-2 font-sans text-[13px] text-ink outline-none focus:border-copper"
        >
          <option value="all">All flags</option>
          <option value="flagged">With flags</option>
          <option value="clean">Clean</option>
        </select>
        <div className="flex items-center gap-1">
          {(['Pending', 'Queried', 'Decided'] as const).map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => setStatusFilter((cur) => (cur === s ? null : s))}
              className={cn(
                'rounded-[2px] border px-3 py-2 font-sans text-[11px] font-semibold uppercase tracking-[0.12em] transition-colors duration-200',
                statusFilter === s
                  ? 'border-copper bg-copper text-ivory'
                  : 'border-line/60 bg-transparent text-muted hover:border-copper hover:text-copper',
              )}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Section 3 — queue table */}
      <div className="mt-6">
        <DataTable>
          <thead>
            <tr className="border-b border-line">
              {[
                { label: 'Submission', sort: null },
                { label: 'Facility', sort: null },
                { label: 'Period', sort: null },
                { label: 'Stream', sort: null },
                { label: 'Activity value', sort: null },
                { label: 'AI estimate (tCO₂e)', sort: 'estimate' as SortKey },
                { label: 'Flags', sort: null },
                { label: 'Age', sort: 'age' as SortKey },
                { label: 'Action', sort: null },
              ].map((c) => (
                <th key={c.label} scope="col" className="kicker py-3 pr-4 font-semibold text-muted last:pr-0">
                  {c.sort ? (
                    <button
                      type="button"
                      onClick={() => toggleSort(c.sort as SortKey)}
                      className="inline-flex items-center gap-1 uppercase tracking-kicker hover:text-copper"
                    >
                      {c.label}
                      {sortKey === c.sort ? (
                        sortDir === 'asc' ? (
                          <ArrowUp className="h-3 w-3 text-copper" strokeWidth={2} />
                        ) : (
                          <ArrowDown className="h-3 w-3 text-copper" strokeWidth={2} />
                        )
                      ) : (
                        <ArrowUpDown className="h-3 w-3 opacity-50" strokeWidth={2} />
                      )}
                    </button>
                  ) : (
                    c.label
                  )}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((s, i) => {
              const facility = FACILITIES.find((f) => f.id === s.facilityId)
              const decided = s.status === 'Accepted' || s.status === 'Rejected'
              return (
                <DataTableRow
                  key={s.id}
                  onClick={() => navigate(`/verifier/review/${s.id}`)}
                  className="motion-safe:animate-none"
                >
                  <DataTableCell>
                    <motion.span
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.35, ease: EASE, delay: i * 0.03 }}
                      className="block"
                    >
                      {s.id}
                    </motion.span>
                  </DataTableCell>
                  <DataTableCell mono={false}>
                    <span className="block max-w-[180px] truncate">{facility?.name ?? s.facilityId}</span>
                    <span className="data-s text-muted">{s.facilityId}</span>
                  </DataTableCell>
                  <DataTableCell>{s.period}</DataTableCell>
                  <DataTableCell mono={false}>
                    {STREAM_LABEL[s.id] ?? s.streamLabel}
                  </DataTableCell>
                  <DataTableCell>{s.activityValue}</DataTableCell>
                  <DataTableCell>
                    <span className="block font-mono text-[13px] text-ink">
                      {s.aiEstimate.replace(/\s*tCO2e/i, '')}{' '}
                      <span className="text-muted">{s.uncertainty}</span>
                    </span>
                    <AILabel
                      verified={s.status === 'Accepted'}
                      verifierName={s.status === 'Accepted' ? (s.verifiedBy ?? undefined) : undefined}
                      className="mt-1"
                    />
                  </DataTableCell>
                  <DataTableCell>
                    <FlagCell flag={s.flag} />
                  </DataTableCell>
                  <DataTableCell>
                    <span className={cn(s.status === 'Queried' && 'text-copper')}>
                      {ageDisplay(s)}
                    </span>
                  </DataTableCell>
                  <DataTableCell>
                    {s.status === 'Queried' ? (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation()
                          setQueryView(s)
                        }}
                        className="link-sweep font-sans text-[13px] font-medium text-ink"
                      >
                        View query →
                      </button>
                    ) : decided ? (
                      <Link
                        to={`/verifier/review/${s.id}`}
                        onClick={(e) => e.stopPropagation()}
                        className="link-sweep font-sans text-[13px] font-medium text-ink"
                      >
                        View record →
                      </Link>
                    ) : (
                      <Link
                        to={`/verifier/review/${s.id}`}
                        onClick={(e) => e.stopPropagation()}
                        className="link-sweep font-sans text-[13px] font-semibold text-copper"
                      >
                        Review →
                      </Link>
                    )}
                  </DataTableCell>
                </DataTableRow>
              )
            })}
            {rows.length === 0 && (
              <DataTableEmpty
                colSpan={9}
                guidance="No submissions match the current filters. Clear the filters to see the full queue."
              />
            )}
          </tbody>
        </DataTable>
      </div>

      {/* Section 4 — queue discipline strip (dark band) */}
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true, amount: 0.25 }}
        transition={{ duration: 0.6, ease: EASE }}
        className="mt-16 grid gap-8 bg-petrol-deep px-8 py-10 md:grid-cols-3"
      >
        {[
          {
            k: 'Independence',
            b: 'You are not employed by the operator or by ECO ENGINE. Your accreditation is on every decision.',
          },
          {
            k: 'Evidence before arithmetic',
            b: 'The AI shows its reasoning; you check the source documents first.',
          },
          {
            k: 'Every decision is sealed',
            b: 'Accept, Query or Reject is hash-chained with your name and timestamp.',
          },
        ].map((p, i) => (
          <motion.div
            key={p.k}
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, ease: EASE, delay: i * 0.12 }}
          >
            <p className="kicker text-copper-light">{p.k}</p>
            <p className="mt-3 font-sans text-[13px] leading-[1.6] text-ivory/80">{p.b}</p>
          </motion.div>
        ))}
      </motion.div>

      {/* Section 5 — recently decided */}
      <div className="mt-16">
        <LedgerRule className="mb-4 w-24" />
        <p className="kicker text-muted">Recently decided</p>
        <div className="mt-4 border-t border-line/60">
          {decidedFeed.map((d, i) => (
            <motion.div
              key={d.key}
              initial={{ opacity: 0, x: -16 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.45, ease: EASE, delay: i * 0.08 }}
              className="flex flex-wrap items-center gap-4 border-b border-line/40 py-3"
            >
              <span
                className={cn(
                  'h-2 w-2 shrink-0',
                  d.tone === 'teal' && 'bg-petrol',
                  d.tone === 'copper' && 'bg-copper',
                  d.tone === 'alert' && 'bg-alert',
                )}
                aria-hidden="true"
              />
              <span className="min-w-0 flex-1 truncate font-sans text-[13px] text-ink">
                {d.label}
              </span>
              <span className="data-s text-muted">{d.ts}</span>
              <HashChip hash={d.hash} />
            </motion.div>
          ))}
        </div>
        <Link
          to="/audit?actor=verifier"
          className="link-sweep mt-4 inline-block font-sans text-[13px] font-medium text-petrol"
        >
          Full decisions log →
        </Link>
      </div>

      {/* Query thread drawer (read-only) */}
      <Sheet open={queryView !== null} onOpenChange={(o) => !o && setQueryView(null)}>
        <SheetContent side="right" className="w-[480px] overflow-y-auto bg-ivory sm:max-w-[480px]">
          <SheetHeader>
            <SheetTitle className="font-display text-[24px] text-ink">Query thread</SheetTitle>
          </SheetHeader>
          {queryView && (
            <div className="mt-6 flex flex-col gap-5">
              <div className="flex items-center gap-3">
                <StatusChip status="Queried" />
                <span className="font-mono text-[13px] text-ink">{queryView.id}</span>
              </div>
              <div className="border-l-4 border-copper bg-sand px-4 py-3">
                <p className="kicker text-muted">Dr. F. Okafor — verifier</p>
                <p className="mt-2 font-sans text-[14px] leading-[1.6] text-ink">
                  {queryView.verificationComment ?? 'Query returned to operator.'}
                </p>
                <p className="data-s mt-2 text-muted">
                  {queryView.verifiedAt?.replace('T', ' ').slice(0, 16) ?? ''}
                </p>
              </div>
              <p className="font-sans text-[13px] leading-[1.6] text-muted">
                Query returned to operator. The submission re-enters your queue when the operator
                responds with the requested evidence.
              </p>
            </div>
          )}
        </SheetContent>
      </Sheet>
    </motion.div>
  )
}
