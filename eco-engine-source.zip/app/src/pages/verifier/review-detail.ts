/**
 * Verifier pages — per-submission review detail (design/verifier-review.md).
 * Display-only detail layered on top of the store Submission; statuses and
 * decisions always come from the store. Hashes are demo-grade (store demoHash).
 */
import { demoHash, type Submission } from '@/lib/store'
import { FACILITIES, type Facility, type MonthPoint } from '@/lib/demo-data'

export interface EvidenceFile {
  name: string
  kind: string
  size: string
  hash: string
  uploadedBy: string
  uploadedAt: string
}

export interface CheckItem {
  label: string
  result: 'pass' | 'warn'
  detail: string
}

export interface FlagDetail {
  severity: 'high' | 'advisory'
  title: string
  body: string
  rule: string
  evidenceRef?: string
}

export interface ProvenanceRow {
  label: string
  value: string
  hash?: string
}

export interface ReviewDetail {
  submittedAtDisplay: string
  submitterLine: string
  periodDetail: string
  streamLine: string
  planRef: string
  planStreamId: string
  activityNumeric: string
  activityUnit: string
  activityMeanNote: string
  evidence: EvidenceFile[]
  operatorNote: string
  estimateNumeric: string
  estimateValue: number
  uncertainty: string
  rangeLine: string
  provenance: ProvenanceRow[]
  reasoning: string
  checks: CheckItem[]
  flag: FlagDetail | null
  history: MonthPoint[]
  anomalyMonth: string | null
  historyUnit: string
  meanValue: number | null
  peerLine: string
  ageDisplay: string
  ageDays: number
}

const h = (seed: string) => demoHash(seed)

const DETAILS: Record<string, ReviewDetail> = {
  /* ---------------------------------------------------- the demo centerpiece */
  'SUB-2606-114': {
    submittedAtDisplay: '14 Jul 2026 15:47',
    submitterLine: 'Engr. T. Wokoma — Facility Environmental Manager',
    periodDetail: 'March 2026 · 31 operating days',
    streamLine: 'S1 — Associated gas flared (MMscf/d)',
    planRef: 'v1.2, §3.1 — meter FL-201, Tier 2',
    planStreamId: 'S1',
    activityNumeric: '3.05',
    activityUnit: 'MMscf/d',
    activityMeanNote: '6-month mean 2.10 MMscf/d',
    evidence: [
      {
        name: 'flare-meter-export-mar2026.csv',
        kind: 'Meter export',
        size: '1.2 MB',
        hash: h('evidence:flare-meter-export-mar2026.csv'),
        uploadedBy: 'Engr. T. Wokoma',
        uploadedAt: '14 Jul 2026 15:41',
      },
      {
        name: 'turnaround-report-ge02-ge03.pdf',
        kind: 'Report',
        size: '8.4 MB',
        hash: h('evidence:turnaround-report-ge02-ge03.pdf'),
        uploadedBy: 'Engr. T. Wokoma',
        uploadedAt: '14 Jul 2026 15:44',
      },
      {
        name: 'flare-tip-inspection-photos.zip',
        kind: 'Photos',
        size: '22 MB',
        hash: h('evidence:flare-tip-inspection-photos.zip'),
        uploadedBy: 'Engr. T. Wokoma',
        uploadedAt: '14 Jul 2026 15:45',
      },
      {
        name: 'daily-log-march.xlsx',
        kind: 'Operator log',
        size: '412 KB',
        hash: h('evidence:daily-log-march.xlsx'),
        uploadedBy: 'Engr. T. Wokoma',
        uploadedAt: '14 Jul 2026 15:46',
      },
    ],
    operatorNote:
      'Turnaround: planned shutdown of GE-02/03; gas routed to flare 12–26 Mar. Turnaround report attached.',
    estimateNumeric: '5,614',
    estimateValue: 5614,
    uncertainty: '±8%',
    rangeLine: 'uncertainty ±8% → range 5,165 – 6,063 tCO₂e',
    provenance: [
      { label: 'Activity data', value: '3.05 MMscf/d × 31 d = 94.55 MMscf' },
      { label: 'Emission factor', value: '60.3 t CO₂e/MMscf (derived)' },
      {
        label: 'Factor source',
        value: 'GGFR guidance + IPCC 2006, Vol. 2, Ch. 4 — illustrative, demonstration build',
      },
      { label: 'GWP set', value: 'IPCC AR5 (CH₄ 28, N₂O 265)' },
      { label: 'Engine run', value: 'RUN-260714-1548', hash: h('engine:RUN-260714-1548') },
    ],
    reasoning:
      'Activity data within meter spec (Tier 2). Factor from approved library binding (plan v1.2 §3.1). Value exceeds trailing 6-month mean by 45% — outside ±30% plausibility band, flagged. No duplicate periods. Evidence hash set complete (4/4). Peer comparison: +1.9σ vs oil & gas flaring cohort — consistent with a turnaround event of the kind described in the operator note.',
    checks: [
      { label: 'Schema', result: 'pass', detail: 'All required fields present' },
      { label: 'Units', result: 'pass', detail: 'MMscf/d matches plan stream S1' },
      { label: 'Completeness', result: 'pass', detail: '31/31 days' },
      { label: 'Duplicates', result: 'pass', detail: 'No duplicate period' },
    ],
    flag: {
      severity: 'high',
      title: 'Implausible intensity shift',
      body: 'Reported flaring is +45% vs the trailing 6-month mean (threshold ±30%). Common legitimate cause: turnaround or commissioning events — verify against evidence.',
      rule: 'value deviates >±30% from trailing 6-month mean',
      evidenceRef: 'turnaround-report-ge02-ge03.pdf',
    },
    history: FACILITIES[0].history,
    anomalyMonth: 'Mar 2026',
    historyUnit: 'MMscf/d',
    meanValue: 2.1,
    peerLine: 'Cohort: 4 oil & gas facilities (demo) · this value +1.9σ.',
    ageDisplay: '2 d',
    ageDays: 2,
  },

  /* ---------------------------------------------------------- queried clinker */
  'SUB-2606-118': {
    submittedAtDisplay: '15 Mar 2026 11:30',
    submitterLine: 'Engr. T. Wokoma — Facility Environmental Manager',
    periodDetail: 'February 2026 · 28 operating days',
    streamLine: 'S1 — Clinker production (t/month)',
    planRef: 'v1.0, §2.1 — belt scale BS-22, Tier 3',
    planStreamId: 'S1',
    activityNumeric: '118,432.00',
    activityUnit: 't/month',
    activityMeanNote: '6-month mean ≈ 117,750 t',
    evidence: [
      {
        name: 'belt-scale-export-feb2026.csv',
        kind: 'Meter export',
        size: '1.8 MB',
        hash: h('evidence:belt-scale-export-feb2026.csv'),
        uploadedBy: 'Engr. T. Wokoma',
        uploadedAt: '15 Mar 2026 11:24',
      },
      {
        name: 'kiln-log-february.xlsx',
        kind: 'Operator log',
        size: '520 KB',
        hash: h('evidence:kiln-log-february.xlsx'),
        uploadedBy: 'Engr. T. Wokoma',
        uploadedAt: '15 Mar 2026 11:27',
      },
      {
        name: 'production-report-feb2026.pdf',
        kind: 'Report',
        size: '3.1 MB',
        hash: h('evidence:production-report-feb2026.pdf'),
        uploadedBy: 'Engr. T. Wokoma',
        uploadedAt: '15 Mar 2026 11:29',
      },
    ],
    operatorNote: 'No operational incidents reported for February. Production per plan.',
    estimateNumeric: '61,585',
    estimateValue: 61585,
    uncertainty: '±5%',
    rangeLine: 'uncertainty ±5% → range 58,506 – 64,664 tCO₂e',
    provenance: [
      { label: 'Activity data', value: '118,432.00 t clinker' },
      { label: 'Emission factor', value: '0.52 t CO₂/t clinker (+2% CKD correction)' },
      {
        label: 'Factor source',
        value: 'IPCC 2006, Vol. 3, Ch. 2, Eq. 2.4 — illustrative, demonstration build',
      },
      { label: 'GWP set', value: 'n/a — process CO₂ only' },
      { label: 'Engine run', value: 'RUN-260315-1131', hash: h('engine:RUN-260315-1131') },
    ],
    reasoning:
      'Activity data within belt-scale spec (Tier 3). Factor from approved library binding (plan v1.0 §2.1). February value identical to January to the decimal (118,432.00 t) — physically implausible for a weighed measurement, flagged. Evidence hash set complete (3/3). Peer comparison: within 1σ vs cement cohort.',
    checks: [
      { label: 'Schema', result: 'pass', detail: 'All required fields present' },
      { label: 'Units', result: 'pass', detail: 't/month matches plan stream S1' },
      { label: 'Completeness', result: 'pass', detail: '28/28 days' },
      { label: 'Duplicates', result: 'warn', detail: 'Identical to January 2026 to the decimal' },
    ],
    flag: {
      severity: 'high',
      title: 'Repeated identical values',
      body: 'February equals January to the decimal (118,432.00 t). A carried-forward value is likely — request the belt-scale raw logs before any acceptance.',
      rule: 'repeated identical values across consecutive periods',
      evidenceRef: 'belt-scale-export-feb2026.csv',
    },
    history: FACILITIES[1].history,
    anomalyMonth: 'Feb 2026',
    historyUnit: 't/month',
    meanValue: 117750,
    peerLine: 'Cohort: 2 cement lines (demo) · within 1σ.',
    ageDisplay: 'queried',
    ageDays: 122,
  },

  /* ----------------------------------------------------------- clean fuel gas */
  'SUB-2607-003': {
    submittedAtDisplay: '15 Jul 2026 07:45',
    submitterLine: 'Engr. T. Wokoma — Facility Environmental Manager',
    periodDetail: 'June 2026 · 30 operating days',
    streamLine: 'S2 — Fuel gas consumed (MMscf/d)',
    planRef: 'v1.2, §3.2 — meter FG-104, Tier 2',
    planStreamId: 'S2',
    activityNumeric: '1.42',
    activityUnit: 'MMscf/d',
    activityMeanNote: '6-month mean 1.38 MMscf/d',
    evidence: [
      {
        name: 'fuel-gas-meter-export-jun2026.csv',
        kind: 'Meter export',
        size: '1.1 MB',
        hash: h('evidence:fuel-gas-meter-export-jun2026.csv'),
        uploadedBy: 'Engr. T. Wokoma',
        uploadedAt: '15 Jul 2026 07:40',
      },
      {
        name: 'daily-log-june.xlsx',
        kind: 'Operator log',
        size: '398 KB',
        hash: h('evidence:daily-log-june.xlsx'),
        uploadedBy: 'Engr. T. Wokoma',
        uploadedAt: '15 Jul 2026 07:43',
      },
    ],
    operatorNote: 'Routine monthly submission. Genset fleet within normal dispatch.',
    estimateNumeric: '2,602',
    estimateValue: 2602,
    uncertainty: '±6%',
    rangeLine: 'uncertainty ±6% → range 2,446 – 2,758 tCO₂e',
    provenance: [
      { label: 'Activity data', value: '1.42 MMscf/d × 30 d = 42.6 MMscf' },
      { label: 'Emission factor', value: '56,100 kg CO₂/TJ' },
      {
        label: 'Factor source',
        value: 'IPCC 2006, Vol. 2, Ch. 2, Table 2.2 (default) — demonstration build',
      },
      { label: 'GWP set', value: 'IPCC AR5 (CH₄ 28, N₂O 265)' },
      { label: 'Engine run', value: 'RUN-260715-0746', hash: h('engine:RUN-260715-0746') },
    ],
    reasoning:
      'Activity data within meter spec (Tier 2). Factor from approved library binding (plan v1.2 §3.2). Value within ±30% of trailing 6-month mean. No duplicate periods. Evidence hash set complete (2/2). Peer comparison: within 1σ vs oil & gas combustion cohort.',
    checks: [
      { label: 'Schema', result: 'pass', detail: 'All required fields present' },
      { label: 'Units', result: 'pass', detail: 'MMscf/d matches plan stream S2' },
      { label: 'Completeness', result: 'pass', detail: '30/30 days' },
      { label: 'Duplicates', result: 'pass', detail: 'No duplicate period' },
    ],
    flag: null,
    history: [
      { month: 'Jan 2026', value: 1.39 },
      { month: 'Feb 2026', value: 1.36 },
      { month: 'Mar 2026', value: 1.44 },
      { month: 'Apr 2026', value: 1.37 },
      { month: 'May 2026', value: 1.4 },
      { month: 'Jun 2026', value: 1.42 },
    ],
    anomalyMonth: null,
    historyUnit: 'MMscf/d',
    meanValue: 1.38,
    peerLine: 'Cohort: 4 oil & gas facilities (demo) · within 1σ.',
    ageDisplay: '1 d',
    ageDays: 1,
  },

  /* ---------------------------------------------------------- borderline petcoke */
  'SUB-2607-007': {
    submittedAtDisplay: '15 Jul 2026 08:02',
    submitterLine: 'Engr. T. Wokoma — Facility Environmental Manager',
    periodDetail: 'June 2026 · 30 operating days',
    streamLine: 'S2 — Kiln fuel — petcoke (t/month)',
    planRef: 'v1.0, §2.2 — weighfeeder WF-07, Tier 2',
    planStreamId: 'S2',
    activityNumeric: '9,588',
    activityUnit: 't/month',
    activityMeanNote: '6-month mean 9,410 t',
    evidence: [
      {
        name: 'weighfeeder-export-jun2026.csv',
        kind: 'Meter export',
        size: '1.4 MB',
        hash: h('evidence:weighfeeder-export-jun2026.csv'),
        uploadedBy: 'Engr. T. Wokoma',
        uploadedAt: '15 Jul 2026 07:58',
      },
      {
        name: 'petcoke-delivery-notes-jun2026.pdf',
        kind: 'Delivery records',
        size: '2.2 MB',
        hash: h('evidence:petcoke-delivery-notes-jun2026.pdf'),
        uploadedBy: 'Engr. T. Wokoma',
        uploadedAt: '15 Jul 2026 08:00',
      },
    ],
    operatorNote: 'Petcoke blend adjusted mid-June; delivery notes attached.',
    estimateNumeric: '28,417',
    estimateValue: 28417,
    uncertainty: '±7%',
    rangeLine: 'uncertainty ±7% → range 26,428 – 30,406 tCO₂e',
    provenance: [
      { label: 'Activity data', value: '9,588 t petcoke (NCV 0.0302 TJ/t — demo)' },
      { label: 'Emission factor', value: '97,500 kg CO₂/TJ' },
      {
        label: 'Factor source',
        value: 'IPCC 2006, Vol. 2, Ch. 2, Table 2.2 (default) — demonstration build',
      },
      { label: 'GWP set', value: 'IPCC AR5 (CH₄ 28, N₂O 265)' },
      { label: 'Engine run', value: 'RUN-260715-0803', hash: h('engine:RUN-260715-0803') },
    ],
    reasoning:
      'Activity data within weighfeeder spec (Tier 2). Factor from approved library binding (plan v1.0 §2.2). Value +2.1σ vs peer cohort — marginal exceedance of the 2σ band, flagged as advisory. No duplicate periods. Evidence hash set complete (2/2).',
    checks: [
      { label: 'Schema', result: 'pass', detail: 'All required fields present' },
      { label: 'Units', result: 'pass', detail: 't/month matches plan stream S2' },
      { label: 'Completeness', result: 'pass', detail: '30/30 days' },
      { label: 'Duplicates', result: 'pass', detail: 'No duplicate period' },
    ],
    flag: {
      severity: 'advisory',
      title: 'Peer deviation (borderline)',
      body: 'Petcoke consumption is +2.1σ vs the peer cohort (threshold 2σ) — a marginal exceedance. Cross-check the delivery records; no further escalation if reconciled.',
      rule: 'peer deviation > 2σ (marginal)',
      evidenceRef: 'petcoke-delivery-notes-jun2026.pdf',
    },
    history: [
      { month: 'Jan 2026', value: 9380 },
      { month: 'Feb 2026', value: 9420 },
      { month: 'Mar 2026', value: 9510 },
      { month: 'Apr 2026', value: 9360 },
      { month: 'May 2026', value: 9390 },
      { month: 'Jun 2026', value: 9588 },
    ],
    anomalyMonth: 'Jun 2026',
    historyUnit: 't/month',
    meanValue: 9410,
    peerLine: 'Cohort: 2 cement lines (demo) · this value +2.1σ.',
    ageDisplay: '6 h',
    ageDays: 0.25,
  },
}

/** Queue display ages (design/verifier-queue.md rows). */
export const AGE_DISPLAY: Record<string, string> = Object.fromEntries(
  Object.entries(DETAILS).map(([id, d]) => [id, d.ageDisplay]),
)
export const AGE_DAYS: Record<string, number> = Object.fromEntries(
  Object.entries(DETAILS).map(([id, d]) => [id, d.ageDays]),
)

/** Full stream label for the queue table (design rows). */
export const STREAM_LABEL: Record<string, string> = {
  'SUB-2606-114': 'Associated gas flared',
  'SUB-2606-118': 'Clinker production',
  'SUB-2607-003': 'Fuel gas consumed',
  'SUB-2607-007': 'Kiln fuel — petcoke',
}

/** Human explanation of each anomaly rule (queue flag tooltip). */
export function flagRuleExplanation(flag: string | null): string {
  if (!flag) return ''
  const f = flag.toLowerCase()
  if (f.includes('intensity')) return 'value deviates >±30% from trailing 6-month mean'
  if (f.includes('identical')) return 'repeated identical values across consecutive periods'
  if (f.includes('peer')) return 'deviates > 2σ from peer cohort'
  if (f.includes('factor')) return 'factor out of accepted range'
  return flag
}

export function flagSeverity(flag: string | null): 'high' | 'advisory' | null {
  if (!flag) return null
  return flag.toLowerCase().includes('peer') ? 'advisory' : 'high'
}

/** Generic fallback for submissions created live via the uploads wizard. */
function genericDetail(sub: Submission, facility: Facility | undefined): ReviewDetail {
  const stream = facility?.streams.find((s) =>
    sub.streamLabel.toLowerCase().includes(s.label.split(' ')[0].toLowerCase()),
  )
  const numeric = sub.aiEstimate.replace(/[^\d.]/g, '')
  const value = Number(numeric) || 0
  return {
    submittedAtDisplay: sub.submittedAt.replace('T', ' ').slice(0, 16),
    submitterLine: `${sub.submittedBy} — Facility Environmental Manager`,
    periodDetail: sub.period,
    streamLine: stream ? `${stream.id} — ${stream.label} (${stream.unit})` : sub.streamLabel,
    planRef: facility
      ? `${facility.plan.version} — ${stream?.meter ?? 'per plan'}, ${stream?.tier ?? 'Tier 2'}`
      : 'per approved monitoring plan',
    planStreamId: stream?.id ?? 'S1',
    activityNumeric: sub.activityValue.replace(/[^\d.,]/g, ''),
    activityUnit: sub.activityValue.replace(/[\d.,\s]/g, '') || (stream?.unit ?? ''),
    activityMeanNote: 'Trailing mean within expected band',
    evidence: [
      {
        name: `${sub.id.toLowerCase()}-activity-export.csv`,
        kind: 'Meter export',
        size: '—',
        hash: h(`evidence:${sub.id}`),
        uploadedBy: sub.submittedBy,
        uploadedAt: sub.submittedAt.replace('T', ' ').slice(0, 16),
      },
    ],
    operatorNote: sub.note || 'No operator note attached.',
    estimateNumeric: sub.aiEstimate.replace(/\s*tCO2e/i, ''),
    estimateValue: value,
    uncertainty: sub.uncertainty,
    rangeLine: `uncertainty ${sub.uncertainty}`,
    provenance: [
      { label: 'Activity data', value: sub.activityValue },
      { label: 'Emission factor', value: 'Approved library binding (demo)' },
      { label: 'Factor source', value: 'IPCC 2006/2019-aligned — demonstration build' },
      { label: 'Engine run', value: `RUN-${sub.id.slice(4)}`, hash: h(`engine:${sub.id}`) },
    ],
    reasoning:
      'Automated validation passed. Estimate produced from the approved factor library binding; see provenance rows. Review the activity evidence before deciding.',
    checks: sub.validation.map((v) => ({
      label: v.check.charAt(0).toUpperCase() + v.check.slice(1),
      result: v.result === 'warn' ? 'warn' : 'pass',
      detail: v.detail,
    })),
    flag: sub.flag
      ? {
          severity: flagSeverity(sub.flag) ?? 'advisory',
          title: sub.flag.charAt(0).toUpperCase() + sub.flag.slice(1),
          body: `Automated plausibility check: ${sub.flag}. Rule: ${flagRuleExplanation(sub.flag)}.`,
          rule: flagRuleExplanation(sub.flag),
        }
      : null,
    history: facility?.history ?? [],
    anomalyMonth: null,
    historyUnit: stream?.unit ?? '',
    meanValue: null,
    peerLine: 'Peer comparison unavailable for this stream (demo).',
    ageDisplay: 'new',
    ageDays: 0,
  }
}

export function getReviewDetail(sub: Submission, facility: Facility | undefined): ReviewDetail {
  return DETAILS[sub.id] ?? genericDetail(sub, facility)
}
