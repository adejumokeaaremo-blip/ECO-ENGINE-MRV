/**
 * Page 09 — Verifier Review Workspace (`/verifier/review/:id`).
 * THE SIGNATURE SCREEN (design/verifier-review.md): dark header band ·
 * AI estimate banner · three-pane body (evidence | AI estimate | anomaly
 * flags) · sticky Accept / Query / Reject action bar · hash-sealed
 * confirmation modals. Decisions call verifySubmission() so status
 * propagates across the demonstrator and appends a hash-chained audit entry.
 */
import { useEffect, useMemo, useRef, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router'
import { motion } from 'framer-motion'
import {
  AlertTriangle,
  ArrowLeft,
  Check,
  FileText,
  Image as ImageIcon,
  ShieldCheck,
} from 'lucide-react'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'
import { FACILITIES } from '@/lib/demo-data'
import {
  truncateHash,
  useAuditTrail,
  useSubmissions,
  verifySubmission,
} from '@/lib/store'
import type { Submission } from '@/lib/store'
import HashChip from '@/components/app/HashChip'
import AILabel from '@/components/app/AILabel'
import StatusChip from '@/components/app/StatusChip'
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { getReviewDetail } from './review-detail'
import type { EvidenceFile, ReviewDetail } from './review-detail'

const EASE = [0.22, 1, 0.36, 1] as [number, number, number, number]

/* ------------------------------------------------------------ helpers */

function formatDecisionTs(iso: string | null): string {
  if (!iso) return ''
  const months = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
  ]
  const m = iso.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/)
  if (!m) return iso.replace('T', ' ').slice(0, 16)
  return `${Number(m[3])} ${months[Number(m[2]) - 1]} ${m[1]} ${m[4]}:${m[5]}`
}

function useCountUp(target: number, delay = 400, duration = 1400): number {
  const [v, setV] = useState(0)
  useEffect(() => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      setV(target)
      return
    }
    let raf = 0
    const t0 = performance.now() + delay
    const tick = (now: number) => {
      const p = Math.min(1, Math.max(0, (now - t0) / duration))
      setV(Math.round(target * (1 - Math.pow(1 - p, 3))))
      if (p < 1) raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [target, delay, duration])
  return v
}

/** Hero estimate numeral — counts up 0→value (static when already decided). */
function HeroNumeral({ value, decided }: { value: number; decided: boolean }) {
  const v = useCountUp(decided ? 0 : value, 400, 1400)
  return <>{(decided ? value : v).toLocaleString('en-US')}</>
}

/** Hex scramble that settles left-to-right onto the final hash (~1s). */
function useScramble(finalHash: string, active: boolean): string {
  const [text, setText] = useState(finalHash)
  useEffect(() => {
    if (!active) {
      setText(finalHash)
      return
    }
    const HEX = '0123456789abcdef'
    const t0 = performance.now()
    const id = window.setInterval(() => {
      const p = Math.min(1, (performance.now() - t0) / 1000)
      const locked = Math.floor(p * finalHash.length)
      let out = finalHash.slice(0, locked)
      for (let i = locked; i < finalHash.length; i++) {
        const ch = finalHash[i]
        out += ch === 'x' && i === 1 ? 'x' : HEX[Math.floor(Math.random() * 16)]
      }
      setText(out)
      if (p >= 1) window.clearInterval(id)
    }, 40)
    return () => window.clearInterval(id)
  }, [finalHash, active])
  return text
}

/* -------------------------------------------------- uncertainty band */

function UncertaintyBand() {
  /* band spans ±8% mapped across 30%–70% of the track; best estimate at 50% */
  return (
    <div className="relative mt-6 h-12" aria-hidden="true">
      <div className="absolute left-0 right-0 top-1/2 h-px bg-line" />
      <motion.div
        initial={{ scaleX: 0 }}
        animate={{ scaleX: 1 }}
        transition={{ duration: 0.8, ease: EASE, delay: 0.5 }}
        className="absolute top-1/2 h-[8px] origin-center -translate-y-1/2 border-x border-copper bg-copper/25"
        style={{ left: '30%', width: '40%' }}
      />
      <div className="absolute left-1/2 top-1/2 h-4 w-[2px] -translate-x-1/2 -translate-y-1/2 bg-copper" />
      {[
        { p: '30%', l: '−8%' },
        { p: '40%', l: '−4%' },
        { p: '50%', l: 'best' },
        { p: '60%', l: '+4%' },
        { p: '70%', l: '+8%' },
      ].map((t) => (
        <span
          key={t.l}
          className="data-s absolute top-full mt-1 -translate-x-1/2 text-muted"
          style={{ left: t.p }}
        >
          {t.l}
        </span>
      ))}
    </div>
  )
}

/* -------------------------------------------------------- sparkline */

function HistorySparkline({ detail }: { detail: ReviewDetail }) {
  const W = 260
  const H = 84
  const PAD = 8
  const pts = useMemo(() => {
    if (detail.history.length === 0) return []
    const values = detail.history.map((p) => p.value)
    const min = Math.min(...values)
    const max = Math.max(...values)
    const span = max - min || 1
    return detail.history.map((p, i) => ({
      x: PAD + (i / (detail.history.length - 1)) * (W - PAD * 2),
      y: H - PAD - ((p.value - min) / span) * (H - PAD * 2),
      month: p.month,
      value: p.value,
    }))
  }, [detail.history])

  if (pts.length === 0) return null
  const values = detail.history.map((p) => p.value)
  const min = Math.min(...values)
  const max = Math.max(...values)
  const span = max - min || 1
  const meanY =
    detail.meanValue !== null
      ? H - PAD - ((detail.meanValue - min) / span) * (H - PAD * 2)
      : null
  const anomaly = detail.anomalyMonth
    ? pts.find((p) => p.month === detail.anomalyMonth)
    : null
  const points = pts.map((p) => `${p.x},${p.y}`).join(' ')

  return (
    <div>
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img" aria-label="History sparkline">
        {meanY !== null && (
          <line
            x1={PAD}
            x2={W - PAD}
            y1={meanY}
            y2={meanY}
            stroke="#1C2B28"
            strokeOpacity="0.4"
            strokeDasharray="4 4"
            strokeWidth="1"
          />
        )}
        <motion.polyline
          points={points}
          fill="none"
          stroke="#1C2B28"
          strokeOpacity="0.65"
          strokeWidth="1.5"
          initial={{ pathLength: 0 }}
          whileInView={{ pathLength: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1.2, ease: EASE }}
        />
        {anomaly && (
          <motion.rect
            x={anomaly.x - 4}
            y={anomaly.y - 4}
            width={8}
            height={8}
            fill="#A63D2F"
            initial={{ scale: 0, rotate: 45 }}
            whileInView={{ scale: 1, rotate: 45 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, ease: EASE, delay: 1 }}
            style={{ transformOrigin: `${anomaly.x}px ${anomaly.y}px` }}
          />
        )}
      </svg>
      <div className="mt-1 flex justify-between">
        <span className="data-s text-muted">{detail.history[0].month}</span>
        <span className="data-s text-muted">{detail.historyUnit}</span>
        <span className="data-s text-muted">{detail.history[detail.history.length - 1].month}</span>
      </div>
    </div>
  )
}

/* --------------------------------------------------- decision modal */

type DecisionAction = 'Accepted' | 'Queried' | 'Rejected'

const REJECT_REASONS = [
  'Evidence insufficient',
  'Data implausible',
  'Wrong method',
  'Duplicate',
]

function DecisionModal({
  action,
  sub,
  detail,
  comment,
  onClose,
  onConfirm,
  sealedHash,
  nextPendingId,
}: {
  action: DecisionAction | null
  sub: Submission
  detail: ReviewDetail
  comment: string
  onClose: () => void
  onConfirm: (action: DecisionAction, comment: string, reason?: string) => void
  sealedHash: string | null
  nextPendingId: string | null
}) {
  const navigate = useNavigate()
  const [phase, setPhase] = useState<'confirm' | 'sealing' | 'done'>('confirm')
  const [reason, setReason] = useState(REJECT_REASONS[0])
  const [localComment, setLocalComment] = useState(comment)
  const scramble = useScramble(sealedHash ?? '0x………………………………………………', phase === 'sealing')

  useEffect(() => {
    if (action) {
      setPhase('confirm')
      setLocalComment(comment)
      setReason(REJECT_REASONS[0])
    }
  }, [action, comment])

  const needsComment = action === 'Queried' || action === 'Rejected'
  const commentMissing = needsComment && localComment.trim().length === 0

  const confirm = () => {
    if (commentMissing) return
    if (action === 'Accepted') {
      setPhase('sealing')
      onConfirm('Accepted', localComment.trim())
      window.setTimeout(() => setPhase('done'), 1400)
    } else if (action) {
      onConfirm(action, localComment.trim(), action === 'Rejected' ? reason : undefined)
      onClose()
    }
  }

  const titles: Record<DecisionAction, string> = {
    Accepted: 'Accept — enter the official record.',
    Queried: 'Return to operator with your question.',
    Rejected: 'Reject this submission.',
  }

  return (
    <Dialog open={action !== null} onOpenChange={(o) => !o && phase !== 'sealing' && onClose()}>
      <DialogContent className="max-w-[560px] rounded-[2px] border-line bg-ivory">
        {phase === 'done' && action === 'Accepted' ? (
          <div className="py-4 text-center">
            <motion.p
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, ease: EASE }}
              className="font-display text-[36px] leading-none text-petrol"
            >
              Accepted.
            </motion.p>
            <p className="mt-3 font-sans text-[14px] text-muted">
              The record has been sealed and the operator notified.
            </p>
            {sealedHash && (
              <div className="mt-4 flex justify-center">
                <HashChip hash={sealedHash} />
              </div>
            )}
            <div className="mt-8 flex justify-center gap-3">
              {nextPendingId && (
                <button
                  type="button"
                  onClick={() => {
                    onClose()
                    navigate(`/verifier/review/${nextPendingId}`)
                  }}
                  className="rounded-[2px] bg-petrol px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ivory transition-all duration-200 hover:-translate-y-px hover:bg-petrol-deep"
                >
                  Next in queue →
                </button>
              )}
              <button
                type="button"
                onClick={() => {
                  onClose()
                  navigate('/verifier')
                }}
                className="rounded-[2px] border border-ink/30 px-[18px] py-[10px] font-sans text-[13px] font-medium text-ink transition-all duration-200 hover:-translate-y-px hover:border-ink hover:bg-sand"
              >
                Back to queue
              </button>
            </div>
          </div>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle className="font-display text-[28px] leading-[1.1] text-ink">
                {action ? titles[action] : ''}
              </DialogTitle>
              <DialogDescription className="data-s text-muted">
                {sub.id} · {detail.estimateNumeric} tCO₂e · {sub.period} ·{' '}
                {detail.streamLine.split('—')[1]?.trim() ?? sub.streamLabel}
              </DialogDescription>
            </DialogHeader>

            {phase === 'sealing' ? (
              <div className="py-8 text-center">
                <p className="kicker text-muted">Sealing the record</p>
                <p className="mt-4 break-all font-mono text-[13px] tracking-[0.02em] text-ink">
                  {scramble}
                </p>
                <p className="data-s mt-4 text-muted">
                  hash-chained · Dr. F. Okafor · AV/2024/0142 (demo)
                </p>
              </div>
            ) : (
              <div className="flex flex-col gap-4">
                {action === 'Accepted' && (
                  <p className="font-sans text-[13px] leading-[1.6] text-muted">
                    This figure becomes part of the verified record of{' '}
                    {FACILITIES.find((f) => f.id === sub.facilityId)?.name}, feeds DQI, disclosure
                    packs and the national Inventory Export. Signed: Dr. F. Okafor — AV/2024/0142
                    (demo).
                  </p>
                )}
                {action === 'Rejected' && (
                  <div className="flex flex-col gap-1.5">
                    <label className="kicker text-muted" htmlFor="reject-reason">
                      Reason
                    </label>
                    <select
                      id="reject-reason"
                      value={reason}
                      onChange={(e) => setReason(e.target.value)}
                      className="rounded-[2px] border border-line/60 bg-ivory px-3 py-2 font-sans text-[13px] text-ink outline-none focus:border-copper"
                    >
                      {REJECT_REASONS.map((r) => (
                        <option key={r}>{r}</option>
                      ))}
                    </select>
                  </div>
                )}
                <div className="flex flex-col gap-1.5">
                  <label className="kicker text-muted" htmlFor="decision-comment">
                    {action === 'Accepted'
                      ? 'Basis of acceptance (optional note)'
                      : action === 'Queried'
                        ? 'Your question to the operator (required)'
                        : 'Grounds for rejection (required)'}
                  </label>
                  <textarea
                    id="decision-comment"
                    rows={3}
                    value={localComment}
                    onChange={(e) => setLocalComment(e.target.value)}
                    placeholder={
                      action === 'Accepted'
                        ? 'Basis of acceptance…'
                        : action === 'Queried'
                          ? 'Query returned to operator…'
                          : 'Rejection recorded with grounds…'
                    }
                    className="w-full resize-none rounded-[2px] border border-line/60 bg-ivory px-3 py-2 font-sans text-[14px] text-ink outline-none placeholder:text-muted/70 focus:border-copper"
                  />
                  {commentMissing && (
                    <p className="font-sans text-[12px] text-alert">
                      A comment is required for {action === 'Queried' ? 'Query' : 'Reject'}.
                    </p>
                  )}
                </div>
                <div className="mt-2 flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={onClose}
                    className="rounded-[2px] border border-ink/30 px-[18px] py-[10px] font-sans text-[13px] font-medium text-ink transition-all duration-200 hover:-translate-y-px hover:border-ink hover:bg-sand"
                  >
                    Back
                  </button>
                  <button
                    type="button"
                    onClick={confirm}
                    disabled={commentMissing}
                    className={cn(
                      'rounded-[2px] px-[18px] py-[10px] font-sans text-[13px] font-semibold transition-all duration-200 hover:-translate-y-px',
                      action === 'Accepted' && 'bg-petrol text-ivory hover:bg-petrol-deep',
                      action === 'Queried' && 'bg-copper text-ivory hover:bg-copper-light hover:text-ink',
                      action === 'Rejected' && 'bg-alert text-ivory hover:opacity-90',
                      commentMissing && 'cursor-not-allowed opacity-40 hover:translate-y-0',
                    )}
                  >
                    {action === 'Accepted'
                      ? 'Sign & accept'
                      : action === 'Queried'
                        ? 'Send query'
                        : 'Confirm rejection'}
                  </button>
                </div>
              </div>
            )}
          </>
        )}
      </DialogContent>
    </Dialog>
  )
}

/* --------------------------------------------------------- workspace */

export default function Review() {
  const { id } = useParams()
  const submissions = useSubmissions()
  const audit = useAuditTrail()

  const sub = submissions.find((s) => s.id === id)
  const facility = sub ? FACILITIES.find((f) => f.id === sub.facilityId) : undefined
  const detail = useMemo(
    () => (sub ? getReviewDetail(sub, facility) : null),
    [sub, facility],
  )

  const [comment, setComment] = useState('')
  const [modalAction, setModalAction] = useState<DecisionAction | null>(null)
  const [preview, setPreview] = useState<EvidenceFile | null>(null)
  const [planOpen, setPlanOpen] = useState(false)
  const commentRef = useRef<HTMLInputElement | null>(null)

  const decided = sub ? sub.status !== 'Pending' : false
  const decidedEntry = useMemo(() => {
    if (!sub) return null
    return (
      [...audit]
        .reverse()
        .find((e) => e.entity === sub.id && e.role === 'verifier' && e.action.startsWith('SUBMISSION_')) ??
      null
    )
  }, [audit, sub])

  /* toast when a NEW decision entry lands on the chain for this submission */
  const decisionCount = useMemo(
    () =>
      sub
        ? audit.filter(
            (e) => e.entity === sub.id && e.role === 'verifier' && e.action.startsWith('SUBMISSION_'),
          ).length
        : 0,
    [audit, sub],
  )
  const prevDecisionCount = useRef(decisionCount)
  useEffect(() => {
    if (sub && decisionCount > prevDecisionCount.current) {
      const entry = [...audit]
        .reverse()
        .find((e) => e.entity === sub.id && e.role === 'verifier' && e.action.startsWith('SUBMISSION_'))
      if (entry) {
        const label =
          entry.action === 'SUBMISSION_ACCEPTED'
            ? 'Accepted — sealed'
            : entry.action === 'SUBMISSION_QUERIED'
              ? 'Query sent — logged'
              : 'Rejected — logged'
        toast(`${label} ${truncateHash(entry.hash)}`)
      }
    }
    prevDecisionCount.current = decisionCount
  }, [decisionCount, audit, sub])

  const nextPendingId =
    submissions.find((s) => s.status === 'Pending' && s.id !== sub?.id)?.id ?? null

  /* keyboard: `A` opens the accept confirmation (never a one-key decision) */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key.toLowerCase() !== 'a' || e.metaKey || e.ctrlKey || e.altKey) return
      const t = e.target as HTMLElement
      if (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable) return
      if (!decided && modalAction === null) setModalAction('Accepted')
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [decided, modalAction])

  if (!sub || !detail) {
    return (
      <div className="flex min-h-[50vh] flex-col items-center justify-center gap-4 text-center">
        <p className="font-display text-[24px] text-ink">Nothing on the record yet.</p>
        <p className="max-w-[420px] font-sans text-[13px] text-muted">
          Submission {id} is not in the verification queue. It may have been reset with the demo
          data.
        </p>
        <Link
          to="/verifier"
          className="rounded-[2px] bg-petrol px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ivory transition-colors hover:bg-petrol-deep"
        >
          Back to queue
        </Link>
      </div>
    )
  }

  const confirmDecision = (action: DecisionAction, text: string, reason?: string) => {
    const finalComment = reason ? `${reason} — ${text}` : text
    verifySubmission(sub.id, action, finalComment)
  }

  /** "S1 — Associated gas flared (MMscf/d)" → "Associated gas flared" */
  const streamTitle = (detail.streamLine.split('—')[1]?.trim() ?? sub.streamLabel).replace(
    /\s*\([^)]*\)\s*$/,
    '',
  )

  const statusChip =
    sub.status === 'Accepted' ? (
      <span className="inline-flex items-center rounded-[2px] bg-petrol px-[10px] py-[6px] font-sans text-[10px] font-semibold uppercase tracking-chip text-ivory">
        Verified — accepted {formatDecisionTs(sub.verifiedAt).toUpperCase()} ·{' '}
        {(sub.verifiedBy ?? 'Dr. F. Okafor').toUpperCase()}
      </span>
    ) : sub.status === 'Queried' ? (
      <span className="inline-flex items-center rounded-[2px] border border-copper px-[10px] py-[6px] font-sans text-[10px] font-semibold uppercase tracking-chip text-copper-light">
        Queried — returned to operator
      </span>
    ) : sub.status === 'Rejected' ? (
      <span className="inline-flex items-center rounded-[2px] bg-alert px-[10px] py-[6px] font-sans text-[10px] font-semibold uppercase tracking-chip text-ivory">
        Rejected
      </span>
    ) : (
      <span className="inline-flex items-center rounded-[2px] border border-copper px-[10px] py-[6px] font-sans text-[10px] font-semibold uppercase tracking-chip text-ivory">
        Pending verification
      </span>
    )

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.35, ease: EASE }}
      className="-mx-8 -mt-8"
    >
      {/* Section 1 — workspace header (dark band, signature dark moment) */}
      <motion.div
        initial={{ y: -24, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.4, ease: EASE }}
        className="bg-petrol-deep px-8 pb-8 pt-6"
      >
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <Link
              to="/verifier"
              className="inline-flex items-center gap-1.5 font-sans text-[13px] font-medium text-copper-light transition-colors hover:text-ivory"
            >
              <ArrowLeft className="h-3.5 w-3.5" strokeWidth={1.75} /> Queue
            </Link>
            <p className="kicker mt-3 text-ivory/50">{sub.id} · Verification review</p>
          </div>
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4, ease: EASE, delay: 0.2 }}
            className="flex flex-wrap items-center gap-3"
          >
            {statusChip}
            {!decided && <span className="data-s text-ivory/60">In queue {detail.ageDisplay}</span>}
            <span className="rounded-[2px] border border-ivory/15 px-2 py-1 font-mono text-[11px] text-ivory/60">
              {sub.facilityId}
            </span>
          </motion.div>
        </div>
        <motion.h1
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, ease: EASE, delay: 0.15 }}
          className="mt-4 max-w-[900px] font-display text-[32px] leading-[1.1] text-ivory"
        >
          {facility?.name} — {streamTitle} — {sub.period}
        </motion.h1>
      </motion.div>

      {/* Section 2 — AI estimate banner (the non-negotiable) */}
      <motion.div
        initial={{ y: -12, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.4, ease: EASE, delay: 0.2 }}
        className={cn(
          'border-y px-8 py-4',
          sub.status === 'Accepted'
            ? 'border-petrol/40 bg-petrol/10'
            : sub.status === 'Rejected'
              ? 'border-alert/40 bg-alert/10'
              : 'border-copper/40 bg-copper/10',
        )}
      >
        {sub.status === 'Accepted' ? (
          <div className="flex flex-wrap items-center gap-3">
            <span className="h-2 w-2 shrink-0 bg-petrol" aria-hidden="true" />
            <span className="font-sans text-[11px] font-semibold uppercase tracking-ai-label text-petrol">
              Verified — part of the official record
            </span>
            <span className="font-sans text-[13px] text-ink">
              Accepted by {sub.verifiedBy ?? 'Dr. F. Okafor'}
              {sub.verifiedAt ? `, ${formatDecisionTs(sub.verifiedAt)}` : ''}.
            </span>
          </div>
        ) : sub.status === 'Rejected' ? (
          <div className="flex flex-wrap items-center gap-3">
            <span className="h-2 w-2 shrink-0 bg-alert" aria-hidden="true" />
            <span className="font-sans text-[11px] font-semibold uppercase tracking-ai-label text-alert">
              Rejected — not part of the record
            </span>
            <span className="font-sans text-[13px] text-ink">
              Returned to the operator with grounds. The figure never entered the official record.
            </span>
          </div>
        ) : sub.status === 'Queried' ? (
          <div className="flex flex-wrap items-center gap-3">
            <span className="h-2 w-2 shrink-0 bg-copper" aria-hidden="true" />
            <span className="font-sans text-[11px] font-semibold uppercase tracking-ai-label text-copper">
              Queried — returned to operator
            </span>
            <span className="font-sans text-[13px] text-ink">
              Awaiting the operator's response before a decision can be sealed.
            </span>
          </div>
        ) : (
          <div className="flex flex-wrap items-center gap-3">
            <motion.span
              initial={{ scale: 1 }}
              animate={{ scale: [1, 1.3, 1] }}
              transition={{ duration: 0.5, ease: EASE, delay: 0.3 }}
              className="h-2 w-2 shrink-0 bg-copper"
              aria-hidden="true"
            />
            <span className="font-sans text-[11px] font-semibold uppercase tracking-ai-label text-copper">
              AI Estimate — Pending Human Verification
            </span>
            <span className="font-sans text-[13px] text-ink">
              The figure below was computed by the emissions engine. It becomes official only if you
              accept it.
            </span>
          </div>
        )}
      </motion.div>

      {/* Section 3 — three-pane body */}
      <div className="grid min-h-[60vh] gap-8 px-8 py-8 lg:grid-cols-[28fr_40fr_32fr]">
        {/* Pane A — submission & evidence trail */}
        <motion.section
          initial={{ opacity: 0, x: -24 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, ease: EASE, delay: 0.25 }}
        >
          <p className="kicker text-muted">Submission</p>
          <dl className="mt-4 flex flex-col gap-3 border-t border-line/60 pt-4">
            {[
              { k: 'Submitted by', v: detail.submitterLine, mono: false },
              { k: 'Submitted at', v: detail.submittedAtDisplay, mono: true },
              { k: 'Period', v: detail.periodDetail, mono: false },
              { k: 'Stream', v: detail.streamLine, mono: false },
            ].map((r) => (
              <div key={r.k}>
                <dt className="data-s text-muted">{r.k}</dt>
                <dd
                  className={cn(
                    'mt-0.5 text-[13px] leading-[1.5] text-ink',
                    r.mono ? 'font-mono' : 'font-sans',
                  )}
                >
                  {r.v}
                </dd>
              </div>
            ))}
            <div>
              <dt className="data-s text-muted">Monitoring plan ref</dt>
              <dd className="mt-0.5">
                <button
                  type="button"
                  onClick={() => setPlanOpen(true)}
                  className="link-sweep font-sans text-[13px] font-medium text-petrol"
                >
                  {detail.planRef}
                </button>
              </dd>
            </div>
          </dl>

          <div className="mt-6 border-t border-line/60 pt-4">
            <div className="flex items-baseline gap-2">
              <span className="font-display text-[44px] leading-none text-ink">
                {detail.activityNumeric}
              </span>
              <span className="font-mono text-[13px] text-muted">{detail.activityUnit}</span>
            </div>
            <p className="mt-1 font-sans text-[12px] text-muted">{detail.activityMeanNote}</p>
          </div>

          <p className="kicker mt-8 text-muted">Evidence — {detail.evidence.length} files</p>
          <div className="mt-3 border-t border-line/60">
            {detail.evidence.map((f, i) => (
              <motion.div
                key={f.name}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, ease: EASE, delay: 0.35 + i * 0.06 }}
                className="flex items-center gap-3 border-b border-line/40 py-3"
              >
                {f.name.endsWith('.zip') ? (
                  <ImageIcon className="h-4 w-4 shrink-0 text-muted" strokeWidth={1.75} />
                ) : (
                  <FileText className="h-4 w-4 shrink-0 text-muted" strokeWidth={1.75} />
                )}
                <div className="min-w-0 flex-1">
                  <p className="truncate font-sans text-[13px] font-semibold text-ink">{f.name}</p>
                  <p className="data-s text-muted">
                    {f.kind} · {f.size} · {f.uploadedAt}
                  </p>
                  <HashChip hash={f.hash} className="mt-1" />
                </div>
                <button
                  type="button"
                  onClick={() => setPreview(f)}
                  className="link-sweep shrink-0 font-sans text-[12px] font-medium text-petrol"
                >
                  Preview
                </button>
              </motion.div>
            ))}
          </div>

          <div className="mt-6 border-l-4 border-copper bg-ivory px-4 py-3">
            <p className="kicker text-muted">Operator note</p>
            <p className="mt-2 font-sans text-[13px] leading-[1.6] text-ink">
              {detail.operatorNote}
            </p>
          </div>
        </motion.section>

        {/* Pane B — the AI estimate */}
        <motion.section
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: EASE, delay: 0.3 }}
          className="border-line/60 lg:border-x lg:px-8"
        >
          <p className="kicker text-copper">AI Estimate — Emissions Engine v0.9 (demo)</p>
          <div className="mt-4 flex items-end gap-3">
            <span
              className={cn(
                'font-display text-[96px] leading-none',
                sub.status === 'Accepted' ? 'text-petrol' : 'text-copper',
              )}
            >
              <HeroNumeral value={detail.estimateValue} decided={decided} />
            </span>
            <span className="pb-3 font-sans text-[15px] text-ink">tCO₂e</span>
          </div>
          <p className="font-mono text-[13px] text-muted">{detail.rangeLine}</p>

          <UncertaintyBand />

          <div className="mt-8 border-t border-line/60">
            {detail.provenance.map((r, i) => (
              <motion.div
                key={r.label}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.35, ease: EASE, delay: 0.5 + i * 0.05 }}
                className="grid grid-cols-[130px_1fr] gap-4 border-b border-line/40 py-2.5"
              >
                <span className="data-s pt-0.5 text-muted">{r.label}</span>
                <span className="font-sans text-[13px] leading-[1.5] text-ink">
                  {r.value}
                  {r.hash && (
                    <span className="ml-2 inline-block align-middle">
                      <HashChip hash={r.hash} />
                    </span>
                  )}
                </span>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.7, ease: EASE, delay: 0.6 }}
            className="mt-6 border border-line/60 bg-sand px-5 py-4"
          >
            <p className="kicker text-muted">Engine reasoning — summary</p>
            <p className="mt-3 font-sans text-[13.5px] leading-[1.6] text-ink">{detail.reasoning}</p>
            <div className="mt-4 border-t border-line/40 pt-3">
              <AILabel
                size="lg"
                verified={sub.status === 'Accepted'}
                verifierName={sub.status === 'Accepted' ? (sub.verifiedBy ?? 'Dr. F. Okafor') : undefined}
                timestamp={
                  sub.status === 'Accepted' ? formatDecisionTs(sub.verifiedAt) : undefined
                }
              />
            </div>
          </motion.div>
        </motion.section>

        {/* Pane C — anomaly flags & checks */}
        <motion.section
          initial={{ opacity: 0, x: 24 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, ease: EASE, delay: 0.35 }}
        >
          <p className="kicker text-muted">Automated checks</p>
          <div className="mt-3 border-t border-line/60">
            {detail.checks.map((c) => (
              <div key={c.label} className="flex items-center gap-3 border-b border-line/40 py-2.5">
                {c.result === 'pass' ? (
                  <Check className="h-4 w-4 shrink-0 text-petrol" strokeWidth={2} />
                ) : (
                  <AlertTriangle className="h-4 w-4 shrink-0 text-copper" strokeWidth={1.75} />
                )}
                <span className="font-sans text-[13px] font-medium text-ink">{c.label}</span>
                <span className="data-s ml-auto text-right text-muted">{c.detail}</span>
              </div>
            ))}
          </div>

          {detail.flag ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.4, ease: EASE, delay: 0.5 }}
              className={cn(
                'relative mt-6 border bg-ivory px-5 py-4 pl-6',
                detail.flag.severity === 'high' ? 'border-alert' : 'border-copper',
              )}
            >
              <motion.span
                initial={{ scaleY: 0 }}
                animate={{ scaleY: 1 }}
                transition={{ duration: 0.4, ease: EASE, delay: 0.45 }}
                className={cn(
                  'absolute left-0 top-0 h-full w-[4px] origin-top',
                  detail.flag.severity === 'high' ? 'bg-alert' : 'bg-copper',
                )}
                aria-hidden="true"
              />
              <p
                className={cn(
                  'kicker',
                  detail.flag.severity === 'high' ? 'text-alert' : 'text-copper',
                )}
              >
                Flag — {detail.flag.severity === 'high' ? 'High' : 'Advisory'}
              </p>
              <p className="mt-2 font-sans text-[14px] font-semibold text-ink">{detail.flag.title}</p>
              <p className="mt-2 font-sans text-[13px] leading-[1.6] text-muted">{detail.flag.body}</p>
              <p className="data-s mt-2 text-muted">Rule: {detail.flag.rule}</p>
              {detail.flag.evidenceRef && (
                <button
                  type="button"
                  onClick={() => {
                    const f = detail.evidence.find((e) => e.name === detail.flag?.evidenceRef)
                    if (f) setPreview(f)
                  }}
                  className="mt-3 inline-flex items-center gap-1.5 rounded-[2px] border border-line/60 px-2 py-1 font-mono text-[11px] text-petrol transition-colors hover:border-petrol"
                >
                  <FileText className="h-3 w-3" strokeWidth={1.75} />
                  {detail.flag.evidenceRef}
                </button>
              )}
            </motion.div>
          ) : (
            <div className="mt-6 flex items-center gap-2 border border-petrol/40 bg-petrol/5 px-4 py-3">
              <ShieldCheck className="h-4 w-4 shrink-0 text-petrol" strokeWidth={1.75} />
              <p className="font-sans text-[13px] text-petrol">
                No anomaly flags — within all plausibility bands.
              </p>
            </div>
          )}

          <p className="kicker mt-8 text-muted">History — 12 months</p>
          <div className="mt-3 border border-line/60 bg-ivory px-4 py-3">
            <HistorySparkline detail={detail} />
          </div>
          <p className="data-s mt-3 text-muted">{detail.peerLine}</p>
        </motion.section>
      </div>

      {/* Section 4 — sticky action bar / decision record */}
      <motion.div
        initial={{ y: 24, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.4, ease: EASE, delay: 0.5 }}
        className="sticky bottom-0 z-30 border-t border-line bg-ivory px-8 py-4"
      >
        {decided ? (
          <div className="flex flex-wrap items-center gap-4">
            <StatusChip status={sub.status} />
            <div className="min-w-0 flex-1">
              <p className="font-sans text-[13px] font-medium text-ink">
                {sub.status === 'Accepted'
                  ? 'Basis of acceptance'
                  : sub.status === 'Queried'
                    ? 'Query returned to operator'
                    : 'Rejection recorded'}
                {sub.verifiedBy ? ` — ${sub.verifiedBy}` : ''}
                {sub.verifiedAt ? ` · ${formatDecisionTs(sub.verifiedAt)}` : ''}
              </p>
              {sub.verificationComment && (
                <p className="mt-0.5 truncate font-sans text-[13px] text-muted">
                  “{sub.verificationComment}”
                </p>
              )}
            </div>
            {decidedEntry && <HashChip hash={decidedEntry.hash} />}
            <Link
              to="/verifier"
              className="link-sweep font-sans text-[13px] font-medium text-petrol"
            >
              ← Back to queue
            </Link>
          </div>
        ) : (
          <div className="flex flex-wrap items-center gap-4">
            <input
              ref={commentRef}
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Comment (required for Query and Reject; optional note for Accept)…"
              className="min-w-[320px] flex-1 rounded-[2px] border border-line/60 bg-ivory px-3 py-2.5 font-sans text-[14px] text-ink outline-none placeholder:text-muted/70 focus:border-copper"
            />
            <div className="flex flex-col items-end gap-1">
              <div className="flex items-center gap-4">
                <button
                  type="button"
                  title="Operator must resubmit with corrections"
                  onClick={() => setModalAction('Rejected')}
                  className="rounded-[2px] border border-alert px-[18px] py-[10px] font-sans text-[13px] font-semibold text-alert transition-all duration-200 hover:-translate-y-px hover:bg-alert hover:text-ivory"
                >
                  Reject
                </button>
                <button
                  type="button"
                  title="Returns to operator with your question"
                  onClick={() => setModalAction('Queried')}
                  className="rounded-[2px] border border-copper px-[18px] py-[10px] font-sans text-[13px] font-semibold text-copper transition-all duration-200 hover:-translate-y-px hover:bg-copper hover:text-ivory"
                >
                  Query
                </button>
                <button
                  type="button"
                  title="Figure enters the official record; DQI recalculates"
                  onClick={() => setModalAction('Accepted')}
                  className="rounded-[2px] bg-petrol px-[22px] py-[12px] font-sans text-[13px] font-semibold text-ivory transition-all duration-200 hover:-translate-y-px hover:bg-petrol-deep"
                >
                  Accept — enter the official record
                </button>
              </div>
              <p className="data-s text-muted">
                Your decision is hash-chained with your name, accreditation and timestamp. It cannot
                be edited — only superseded by a new decision.
              </p>
            </div>
          </div>
        )}
      </motion.div>

      {/* Section 5 — decision confirmation modal */}
      <DecisionModal
        action={modalAction}
        sub={sub}
        detail={detail}
        comment={comment}
        onClose={() => setModalAction(null)}
        onConfirm={confirmDecision}
        sealedHash={decidedEntry?.hash ?? null}
        nextPendingId={nextPendingId}
      />

      {/* Evidence preview drawer (global 6.13) */}
      <Sheet open={preview !== null} onOpenChange={(o) => !o && setPreview(null)}>
        <SheetContent side="right" className="w-[520px] overflow-y-auto bg-ivory sm:max-w-[520px]">
          <SheetHeader>
            <SheetTitle className="font-display text-[24px] text-ink">Evidence preview</SheetTitle>
          </SheetHeader>
          {preview && (
            <div className="mt-6 flex flex-col gap-5">
              <div className="flex items-center gap-3">
                <FileText className="h-5 w-5 text-muted" strokeWidth={1.75} />
                <div>
                  <p className="font-sans text-[14px] font-semibold text-ink">{preview.name}</p>
                  <p className="data-s text-muted">
                    {preview.kind} · {preview.size}
                  </p>
                </div>
              </div>
              <div className="border-t border-line/60">
                {[
                  { k: 'SHA-256', v: <HashChip hash={preview.hash} expanded /> },
                  { k: 'Uploaded by', v: preview.uploadedBy },
                  { k: 'Uploaded at', v: preview.uploadedAt },
                  { k: 'Submission', v: sub.id },
                ].map((r) => (
                  <div
                    key={r.k}
                    className="grid grid-cols-[110px_1fr] gap-4 border-b border-line/40 py-2.5"
                  >
                    <span className="data-s pt-0.5 text-muted">{r.k}</span>
                    <span className="font-sans text-[13px] text-ink">{r.v}</span>
                  </div>
                ))}
              </div>
              <div className="flex items-center gap-2 border border-petrol/40 bg-petrol/5 px-4 py-3">
                <ShieldCheck className="h-4 w-4 shrink-0 text-petrol" strokeWidth={1.75} />
                <p className="font-sans text-[13px] text-petrol">
                  Hash verified against ledger ✓
                </p>
              </div>
              <p className="font-sans text-[13px] leading-[1.6] text-muted">
                Demonstrator preview — the file body is not stored in this demonstration build. The
                hash above is the integrity anchor: any change to the source file breaks the chain.
              </p>
            </div>
          )}
        </SheetContent>
      </Sheet>

      {/* Monitoring plan reference modal (read-only) */}
      <Dialog open={planOpen} onOpenChange={setPlanOpen}>
        <DialogContent className="max-w-[560px] rounded-[2px] border-line bg-ivory">
          <DialogHeader>
            <DialogTitle className="font-display text-[24px] text-ink">
              Monitoring plan reference
            </DialogTitle>
            <DialogDescription className="data-s text-muted">
              {facility?.name} · plan {facility?.plan.version} · approved {facility?.plan.approvedOn}
            </DialogDescription>
          </DialogHeader>
          {facility && (
            <div className="flex flex-col gap-4">
              {facility.streams
                .filter((s) => s.id === detail.planStreamId)
                .map((s) => (
                  <div key={s.id} className="border-t border-line/60">
                    {[
                      { k: 'Stream', v: `${s.id} — ${s.label}` },
                      { k: 'Unit', v: s.unit },
                      { k: 'Method', v: s.method },
                      { k: 'Meter', v: s.meter },
                      { k: 'Tier', v: s.tier },
                      { k: 'Frequency', v: s.frequency },
                      {
                        k: 'Calibration due',
                        v: s.calibrationDue ?? 'n/a — estimated stream',
                      },
                      { k: 'IPCC category', v: s.ipccCategory },
                    ].map((r) => (
                      <div
                        key={r.k}
                        className="grid grid-cols-[130px_1fr] gap-4 border-b border-line/40 py-2"
                      >
                        <span className="data-s pt-0.5 text-muted">{r.k}</span>
                        <span className="font-sans text-[13px] text-ink">{r.v}</span>
                      </div>
                    ))}
                  </div>
                ))}
              <p className="font-sans text-[13px] text-muted">
                Read-only reference. Plan versions are approved by the regulator before data binds
                to them.
              </p>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </motion.div>
  )
}
