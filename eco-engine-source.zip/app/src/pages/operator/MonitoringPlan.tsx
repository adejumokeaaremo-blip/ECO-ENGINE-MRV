import { useMemo, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { ChevronDown, Clock, Lock, Plus, X } from 'lucide-react'
import { toast } from 'sonner'
import StatusChip from '@/components/app/StatusChip'
import HashChip from '@/components/app/HashChip'
import LedgerRule from '@/components/app/LedgerRule'
import { useFacilities, appendAudit } from '@/lib/store'
import { EF_LIBRARY } from '@/lib/demo-data'
import { cn } from '@/lib/utils'
import FacilitySwitcher from './components/FacilitySwitcher'
import { PLAN_DETAILS, PLAN_DIFFS, daysUntil } from './components/data'

const EASE = [0.22, 1, 0.36, 1] as [number, number, number, number]

interface DraftStream {
  name: string
  unit: string
  method: string
  meter: string
  calibrationDue: string
  tier: string
  qaqc: string
  frequency: string
  ef: string
}

interface HistoryRow {
  version: string
  status: string
  note: string
  when: string
  hash: string
}

const inputCls =
  'w-full rounded-[2px] border border-line bg-ivory px-3 py-2 font-sans text-[13px] text-ink placeholder:text-muted/60 focus:border-petrol focus:outline-none focus:ring-2 focus:ring-copper focus:ring-offset-2'

function nextDraftVersion(current: string): string {
  const m = current.match(/v(\d+)\.(\d+)/)
  if (!m) return `${current}-DRAFT`
  return `v${m[1]}.${Number(m[2]) + 1}-DRAFT`
}

/* -------------------------------------------------------------- the page */

export default function MonitoringPlan() {
  const facilities = useFacilities()
  const [facilityId, setFacilityId] = useState(facilities[0].id)
  const facility = facilities.find((f) => f.id === facilityId) ?? facilities[0]
  const plan = PLAN_DETAILS[facility.id]
  const diffs = PLAN_DIFFS[facility.id]

  const [history, setHistory] = useState<Record<string, HistoryRow[]>>({})
  const rows = history[facility.id] ?? plan.history

  const [drawerOpen, setDrawerOpen] = useState(false)
  const [draftStreams, setDraftStreams] = useState<DraftStream[]>([])
  const [openStream, setOpenStream] = useState(0)
  const [confirmSubmit, setConfirmSubmit] = useState(false)
  const [compareOpen, setCompareOpen] = useState(false)
  const historyRef = useRef<HTMLDivElement | null>(null)

  const draftVersion = useMemo(() => nextDraftVersion(plan.current), [plan.current])

  const openEditor = () => {
    setDraftStreams(
      plan.streams.map((s) => ({
        name: s.name,
        unit: s.unit,
        method: s.methodChip.toLowerCase(),
        meter: s.meter === '—' ? '' : s.meter,
        calibrationDue: s.calibrationDue ?? '',
        tier: s.tier,
        qaqc: s.qaqc,
        frequency: s.frequencyNote,
        ef: s.ef,
      })),
    )
    setOpenStream(0)
    setDrawerOpen(true)
  }

  const setStream = (i: number, patch: Partial<DraftStream>) =>
    setDraftStreams((list) => list.map((s, j) => (j === i ? { ...s, ...patch } : s)))

  const submitDraft = () => {
    const entry = appendAudit({
      actor: 'Engr. T. Wokoma',
      role: 'operator',
      action: 'PLAN_VERSION_SUBMITTED',
      entity: facility.id,
      detail: `Monitoring plan ${draftVersion} submitted for approval — ${draftStreams.length} streams · ${plan.current} remains in force (demo)`,
    })
    setHistory((h) => ({
      ...h,
      [facility.id]: [
        {
          version: draftVersion,
          status: 'Draft',
          note: `${draftStreams.length} streams — submitted for approval; ${plan.current} remains in force until approved.`,
          when: '15 Jul 2026 · Engr. T. Wokoma',
          hash: entry.hash,
        },
        ...rows,
      ],
    }))
    setConfirmSubmit(false)
    setDrawerOpen(false)
    toast(`${draftVersion} submitted — the regulator has been notified.`)
  }

  const approved = true // both seeded facilities hold an approved plan (design §2 gate open)

  return (
    <div className="flex flex-col gap-10">
      {/* ------------------------------------------------ Section 1 — header */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: EASE }}
        className="flex flex-wrap items-end justify-between gap-4"
      >
        <div>
          <h1 className="font-display text-[40px] leading-[1.05] text-ink">Monitoring plan.</h1>
          <p className="mt-3 font-sans text-[13px] text-muted">
            {facility.name} · versioned record · every change enters the audit chain.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <FacilitySwitcher value={facilityId} onChange={setFacilityId} />
          <button
            type="button"
            onClick={() => historyRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })}
            className="rounded-[2px] border border-ink/30 px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ink transition-all duration-200 hover:-translate-y-px hover:border-ink hover:bg-sand"
          >
            Version history
          </button>
          <button
            type="button"
            onClick={openEditor}
            disabled={!approved}
            title={
              approved
                ? `Create a new draft based on ${plan.current}`
                : 'Available once the current version is approved'
            }
            className="rounded-[2px] bg-petrol px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ivory transition-all duration-200 hover:-translate-y-px hover:bg-petrol-deep disabled:cursor-not-allowed disabled:opacity-40"
          >
            Draft new version
          </button>
        </div>
      </motion.div>

      {/* ------------------------------------------------ Section 2 — gate */}
      <div className="relative overflow-hidden rounded-[2px] border border-line bg-ivory">
        <motion.span
          initial={{ scaleY: 0 }}
          animate={{ scaleY: 1 }}
          transition={{ duration: 0.4, ease: EASE }}
          style={{ transformOrigin: 'top' }}
          className={cn('absolute left-0 top-0 h-full w-[4px]', approved ? 'bg-petrol' : 'bg-alert')}
          aria-hidden="true"
        />
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.4, delay: 0.3, ease: EASE }}
          className="flex flex-wrap items-center gap-x-6 gap-y-2 px-6 py-4 pl-8"
        >
          {approved ? (
            <>
              <p className="kicker text-petrol">Reporting gate — open</p>
              <p className="font-sans text-[15px] text-ink">
                Plan <span className="font-semibold">{plan.current}</span> is{' '}
                <span className="font-semibold">approved</span>. All {plan.streams.length} data streams are
                eligible for monthly reporting.
              </p>
            </>
          ) : (
            <>
              <p className="kicker flex items-center gap-2 text-alert">
                <Lock className="h-3.5 w-3.5" strokeWidth={1.75} />
                Reporting gate — locked
              </p>
              <p className="font-sans text-[15px] text-ink">
                No approved plan — reporting is locked. Submit this plan for approval to enable uploads.
              </p>
            </>
          )}
        </motion.div>
      </div>

      {/* ------------------------------ Section 3 — version header + streams */}
      <div key={facility.id} className="flex flex-col gap-6">
        <div className="flex flex-wrap items-baseline gap-x-4 gap-y-2">
          <span className="font-display text-[28px] leading-none text-ink">{plan.current}</span>
          <StatusChip status="Approved" />
          <span className="data-s text-muted">
            Approved {plan.approvedOn} by {plan.approvedBy}
            {plan.supersedes ? ` · supersedes ${plan.supersedes}` : ''}
          </span>
          <HashChip hash={plan.hash} />
          {diffs.length > 0 && (
            <button
              type="button"
              onClick={() => setCompareOpen(true)}
              className="link-sweep ml-auto font-sans text-[13px] font-medium text-petrol"
            >
              Compare with {plan.supersedes} →
            </button>
          )}
        </div>

        {plan.streams.map((s, si) => {
          const days = s.calibrationDue ? daysUntil(s.calibrationDue) : null
          return (
            <motion.section
              key={s.id}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-10%' }}
              transition={{ duration: 0.6, delay: si * 0.1, ease: EASE }}
              className="rounded-[2px] border border-line/70 bg-ivory"
            >
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line/40 px-6 py-4">
                <div className="flex flex-wrap items-baseline gap-3">
                  <h3 className="font-display text-[22px] leading-none text-ink">
                    {s.id} · {s.name}
                  </h3>
                  <span className="rounded-[2px] bg-ink/10 px-2 py-0.5 font-mono text-[10px] uppercase tracking-[0.12em] text-ink">
                    {s.unit}
                  </span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {[s.methodChip, s.tier, s.freq].map((chip, ci) => (
                    <motion.span
                      key={chip}
                      initial={{ opacity: 0, scale: 0.9 }}
                      whileInView={{ opacity: 1, scale: 1 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.25, delay: si * 0.1 + ci * 0.06, ease: EASE }}
                    >
                      <StatusChip
                        status={chip}
                        kind={ci === 0 ? (s.methodChip === 'Metered' ? 'verified' : 'pending') : 'neutral'}
                      />
                    </motion.span>
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-1 gap-x-8 gap-y-5 px-6 py-6 md:grid-cols-2 xl:grid-cols-3">
                <div>
                  <p className="kicker text-muted">Measurement method</p>
                  <p className="mt-1.5 font-sans text-[14px] text-ink">{s.method}</p>
                </div>
                <div>
                  <p className="kicker text-muted">Meter ID</p>
                  <p className="mt-1.5 font-mono text-[13px] text-ink">{s.meter}</p>
                </div>
                <div>
                  <p className="kicker text-muted">Calibration due</p>
                  <p className="mt-1.5 flex items-center gap-1.5 font-mono text-[13px] text-ink">
                    {s.calibrationDue ?? '—'}
                    {days !== null && days < 90 && (
                      <>
                        <Clock className="h-3.5 w-3.5 text-copper" strokeWidth={1.75} />
                        <span className="font-mono text-[10px] text-copper">{days} days</span>
                      </>
                    )}
                  </p>
                </div>
                <div>
                  <p className="kicker text-muted">Uncertainty tier</p>
                  <p className="mt-1.5 font-sans text-[14px] text-ink">{s.tierNote}</p>
                </div>
                <div>
                  <p className="kicker text-muted">QA/QC procedure</p>
                  <p className="mt-1.5 font-sans text-[13px] leading-[1.6] text-ink">{s.qaqc}</p>
                </div>
                <div>
                  <p className="kicker text-muted">Reporting frequency</p>
                  <p className="mt-1.5 font-sans text-[14px] text-ink">{s.frequencyNote}</p>
                </div>
                <div className="md:col-span-2 xl:col-span-3">
                  <p className="kicker text-muted">Emission factor binding</p>
                  <p className="mt-1.5 font-sans text-[13px] text-ink">{s.ef}</p>
                  <p className="mt-1 data-s text-muted">provenance: {s.efSource}</p>
                </div>
              </div>
            </motion.section>
          )
        })}
      </div>

      {/* -------------------------------------- Section 4 — version history */}
      <div ref={historyRef} className="scroll-mt-24">
        <p className="kicker text-muted">Version history — immutable</p>
        <LedgerRule className="mt-3" />
        <div className="mt-6 flex flex-col">
          <AnimatePresence initial={false}>
            {rows.map((v, i) => (
              <motion.div
                key={v.version + v.hash}
                initial={{ opacity: 0, x: -16 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4, delay: i * 0.08, ease: EASE }}
                className="relative flex gap-4 border-b border-line/40 pb-5 pl-6 pt-5 first:pt-0 last:border-b-0"
              >
                <span
                  className={cn(
                    'absolute left-0 top-6 h-2 w-2 first:top-1.5',
                    v.status === 'Approved' ? 'bg-petrol' : v.status === 'Draft' ? 'bg-copper' : 'bg-ink/40',
                  )}
                  aria-hidden="true"
                />
                <div className="flex min-w-0 flex-1 flex-wrap items-baseline gap-x-4 gap-y-1.5">
                  <span className="font-display text-[20px] leading-none text-ink">{v.version}</span>
                  <StatusChip status={v.status} />
                  <span className="font-sans text-[13px] text-ink">{v.note}</span>
                  <span className="data-s text-muted">{v.when}</span>
                  <HashChip hash={v.hash} />
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>

      {/* ------------------------------------------ Section 5 — editor drawer */}
      <AnimatePresence>
        {drawerOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="fixed inset-0 z-[60] bg-petrol-deep/60 backdrop-blur-[4px]"
              onClick={() => setDrawerOpen(false)}
            />
            <motion.aside
              initial={{ x: 640 }}
              animate={{ x: 0 }}
              exit={{ x: 640 }}
              transition={{ duration: 0.35, ease: EASE }}
              className="fixed bottom-0 right-0 top-0 z-[61] flex w-full max-w-[640px] flex-col border-l border-line bg-ivory"
              role="dialog"
              aria-label={`New draft — based on ${plan.current}`}
            >
              <div className="flex items-center justify-between border-b border-line/60 px-6 py-4">
                <div className="flex items-center gap-3">
                  <h3 className="font-display text-[22px] text-ink">New draft — based on {plan.current}</h3>
                  <StatusChip status="Draft" />
                </div>
                <button
                  type="button"
                  onClick={() => setDrawerOpen(false)}
                  aria-label="Close editor"
                  className="rounded-[2px] p-2 text-muted transition-colors hover:text-ink"
                >
                  <X className="h-4 w-4" strokeWidth={1.75} />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto px-6 py-5">
                <div className="flex flex-col gap-3">
                  {draftStreams.map((s, i) => {
                    const days = s.calibrationDue ? daysUntil(s.calibrationDue) : null
                    const calWarn = days !== null && Number.isFinite(days) && days < 90
                    const expanded = openStream === i
                    return (
                      <div key={i} className="rounded-[2px] border border-line/70 bg-ivory">
                        <button
                          type="button"
                          onClick={() => setOpenStream(expanded ? -1 : i)}
                          className="flex w-full items-center justify-between gap-3 px-4 py-3 text-left"
                        >
                          <span className="font-sans text-[14px] font-semibold text-ink">
                            {s.name || `Stream ${i + 1}`}
                            <span className="ml-2 font-mono text-[11px] text-muted">{s.unit}</span>
                          </span>
                          <ChevronDown
                            className={cn('h-4 w-4 text-muted transition-transform duration-300', expanded && 'rotate-180')}
                            strokeWidth={1.75}
                          />
                        </button>
                        <AnimatePresence initial={false}>
                          {expanded && (
                            <motion.div
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: 'auto', opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              transition={{ duration: 0.3, ease: EASE }}
                              className="overflow-hidden"
                            >
                              <div className="grid grid-cols-2 gap-4 border-t border-line/40 px-4 py-4">
                                <label className="col-span-2 flex flex-col gap-1.5">
                                  <span className="kicker text-muted">Stream name</span>
                                  <input className={inputCls} value={s.name} onChange={(e) => setStream(i, { name: e.target.value })} />
                                </label>
                                <label className="flex flex-col gap-1.5">
                                  <span className="kicker text-muted">Unit</span>
                                  <input className={inputCls} value={s.unit} onChange={(e) => setStream(i, { unit: e.target.value })} />
                                </label>
                                <label className="flex flex-col gap-1.5">
                                  <span className="kicker text-muted">Method</span>
                                  <select className={inputCls} value={s.method} onChange={(e) => setStream(i, { method: e.target.value })}>
                                    <option value="metered">Metered</option>
                                    <option value="estimated">Estimated</option>
                                  </select>
                                </label>
                                <label className="flex flex-col gap-1.5">
                                  <span className="kicker text-muted">Meter ID</span>
                                  <input className={inputCls} value={s.meter} onChange={(e) => setStream(i, { meter: e.target.value })} placeholder="—" />
                                </label>
                                <label className="flex flex-col gap-1.5">
                                  <span className="kicker text-muted">Calibration due</span>
                                  <input className={inputCls} value={s.calibrationDue} onChange={(e) => setStream(i, { calibrationDue: e.target.value })} placeholder="15 Sep 2026" />
                                  {calWarn && (
                                    <span className="flex items-center gap-1 font-sans text-[12px] text-copper">
                                      <Clock className="h-3 w-3" strokeWidth={1.75} />
                                      {days} days out — schedule recalibration
                                    </span>
                                  )}
                                </label>
                                <label className="flex flex-col gap-1.5">
                                  <span className="kicker text-muted">Uncertainty tier</span>
                                  <select className={inputCls} value={s.tier} onChange={(e) => setStream(i, { tier: e.target.value })}>
                                    <option>Tier 1</option>
                                    <option>Tier 2</option>
                                    <option>Tier 3</option>
                                  </select>
                                </label>
                                <label className="flex flex-col gap-1.5">
                                  <span className="kicker text-muted">Reporting frequency</span>
                                  <select className={inputCls} value={s.frequency} onChange={(e) => setStream(i, { frequency: e.target.value })}>
                                    <option>Monthly, by the 15th</option>
                                    <option>Quarterly</option>
                                    <option>Annually</option>
                                  </select>
                                </label>
                                <label className="col-span-2 flex flex-col gap-1.5">
                                  <span className="kicker text-muted">QA/QC procedure</span>
                                  <textarea
                                    className={cn(inputCls, 'min-h-[72px] resize-y')}
                                    value={s.qaqc}
                                    onChange={(e) => setStream(i, { qaqc: e.target.value })}
                                  />
                                </label>
                                <label className="col-span-2 flex flex-col gap-1.5">
                                  <span className="kicker text-muted">Emission factor binding</span>
                                  <select className={inputCls} value={s.ef} onChange={(e) => setStream(i, { ef: e.target.value })}>
                                    {!EF_LIBRARY.some((f) => `${f.factor} — ${f.value}` === s.ef) && <option value={s.ef}>{s.ef}</option>}
                                    {EF_LIBRARY.map((f) => (
                                      <option key={f.factor} value={`${f.factor} — ${f.value}`}>
                                        {f.factor} — {f.value}
                                      </option>
                                    ))}
                                  </select>
                                  <span className="data-s text-muted">
                                    provenance:{' '}
                                    {EF_LIBRARY.find((f) => `${f.factor} — ${f.value}` === s.ef)?.source ?? 'bound in current plan'}
                                  </span>
                                </label>
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    )
                  })}
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setDraftStreams((list) => [
                      ...list,
                      {
                        name: '',
                        unit: '',
                        method: 'metered',
                        meter: '',
                        calibrationDue: '',
                        tier: 'Tier 1',
                        qaqc: '',
                        frequency: 'Monthly, by the 15th',
                        ef: `${EF_LIBRARY[0].factor} — ${EF_LIBRARY[0].value}`,
                      },
                    ])
                    setOpenStream(draftStreams.length)
                  }}
                  className="link-sweep mt-4 inline-block font-sans text-[13px] font-medium text-copper"
                >
                  <Plus className="mr-1 inline h-3.5 w-3.5" strokeWidth={1.75} />
                  Add data stream
                </button>
              </div>

              <div className="flex items-center justify-between border-t border-line/60 px-6 py-4">
                <button
                  type="button"
                  onClick={() => setDrawerOpen(false)}
                  className="rounded-[2px] border border-alert px-[18px] py-[10px] font-sans text-[13px] font-semibold text-alert transition-colors hover:bg-alert hover:text-ivory"
                >
                  Discard draft
                </button>
                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      setDrawerOpen(false)
                      toast('Draft saved — not yet submitted.')
                    }}
                    className="rounded-[2px] border border-ink/30 px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ink transition-colors hover:border-ink hover:bg-sand"
                  >
                    Save draft
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmSubmit(true)}
                    className="rounded-[2px] bg-petrol px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ivory transition-all duration-200 hover:-translate-y-px hover:bg-petrol-deep"
                  >
                    Submit for approval
                  </button>
                </div>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* submit confirmation modal */}
      <AnimatePresence>
        {confirmSubmit && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-0 z-[70] flex items-center justify-center bg-petrol-deep/60 backdrop-blur-[4px]"
            onClick={() => setConfirmSubmit(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.97 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.97 }}
              transition={{ duration: 0.25, ease: EASE }}
              className="w-full max-w-[560px] rounded-[2px] border border-line bg-ivory p-8"
              onClick={(e) => e.stopPropagation()}
              role="alertdialog"
              aria-label="Submit plan for approval"
            >
              <h3 className="font-display text-[28px] text-ink">Submit {draftVersion} for approval?</h3>
              <LedgerRule className="mt-4" />
              <p className="mt-4 font-sans text-[13px] leading-[1.6] text-muted">
                This creates {draftVersion} and notifies the regulator. The current approved{' '}
                {plan.current} remains in force until {draftVersion.replace('-DRAFT', '')} is approved.
              </p>
              <div className="mt-6 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setConfirmSubmit(false)}
                  className="rounded-[2px] border border-ink/30 px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ink transition-colors hover:border-ink hover:bg-sand"
                >
                  Keep editing
                </button>
                <button
                  type="button"
                  onClick={submitDraft}
                  className="rounded-[2px] bg-petrol px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ivory transition-all duration-200 hover:-translate-y-px hover:bg-petrol-deep"
                >
                  Submit for approval
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* compare-with-previous-version modal */}
      <AnimatePresence>
        {compareOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-0 z-[70] flex items-center justify-center bg-petrol-deep/60 backdrop-blur-[4px]"
            onClick={() => setCompareOpen(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.97 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.97 }}
              transition={{ duration: 0.25, ease: EASE }}
              className="w-full max-w-[720px] rounded-[2px] border border-line bg-ivory p-8"
              onClick={(e) => e.stopPropagation()}
              role="dialog"
              aria-label={`Compare ${plan.current} with ${plan.supersedes}`}
            >
              <h3 className="font-display text-[28px] text-ink">
                {plan.supersedes} → {plan.current} — changed fields.
              </h3>
              <LedgerRule className="mt-4" />
              <div className="mt-5 overflow-hidden rounded-[2px] border border-line/70">
                <div className="grid grid-cols-[1fr_1fr_1fr] border-b border-line bg-sand/60">
                  <span className="kicker px-4 py-2.5 text-muted">Field</span>
                  <span className="kicker px-4 py-2.5 text-muted">{plan.supersedes}</span>
                  <span className="kicker px-4 py-2.5 text-muted">{plan.current}</span>
                </div>
                {diffs.map((d) => (
                  <div key={d.field} className="grid grid-cols-[1fr_1fr_1fr] border-b border-line/40 bg-copper/[0.08] last:border-b-0">
                    <span className="px-4 py-3 font-sans text-[13px] font-medium text-ink">{d.field}</span>
                    <span className="px-4 py-3 font-mono text-[12px] text-muted line-through decoration-alert/60">{d.before}</span>
                    <span className="px-4 py-3 font-mono text-[12px] text-ink">{d.after}</span>
                  </div>
                ))}
              </div>
              <p className="mt-4 data-s text-muted">
                Changed rows are tinted copper. The full text of every version is immutable in the audit chain.
              </p>
              <div className="mt-6 flex justify-end">
                <button
                  type="button"
                  onClick={() => setCompareOpen(false)}
                  className="rounded-[2px] border border-ink/30 px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ink transition-colors hover:border-ink hover:bg-sand"
                >
                  Close
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
