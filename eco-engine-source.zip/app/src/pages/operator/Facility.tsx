import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Check, FileText, MapPin } from 'lucide-react'
import { toast } from 'sonner'
import StatusChip from '@/components/app/StatusChip'
import HashChip from '@/components/app/HashChip'
import LedgerRule from '@/components/app/LedgerRule'
import DataTable, { DataTableCell, DataTableHead, DataTableRow } from '@/components/app/DataTable'
import { useFacilities, appendAudit, demoHash } from '@/lib/store'
import { cn } from '@/lib/utils'
import FacilitySwitcher from './components/FacilitySwitcher'
import OnboardingWizard from './components/OnboardingWizard'
import { PROFILE_EXTRA, daysUntil } from './components/data'

const EASE = [0.22, 1, 0.36, 1] as [number, number, number, number]

const TABS = ['Organisation', 'Boundaries & units', 'Permits', 'Location & contacts', 'Status history'] as const

/** Animated checklist tick (§3 right rail — check draws stroke 0.3s). */
function TickItem({ label, delay }: { label: string; delay: number }) {
  return (
    <li className="flex items-center gap-3">
      <span className="flex h-5 w-5 items-center justify-center bg-petrol">
        <motion.svg
          viewBox="0 0 12 12"
          className="h-3 w-3"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay }}
        >
          <motion.path
            d="M2 6.5 L5 9.5 L10 2.5"
            fill="none"
            stroke="#F5F0E6"
            strokeWidth="1.8"
            strokeLinecap="square"
            initial={{ pathLength: 0 }}
            whileInView={{ pathLength: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.3, delay, ease: EASE }}
          />
        </motion.svg>
      </span>
      <span className="font-sans text-[13px] text-ink">{label}</span>
    </li>
  )
}

export default function Facility() {
  const facilities = useFacilities()
  const [facilityId, setFacilityId] = useState(facilities[0].id)
  const [tab, setTab] = useState<(typeof TABS)[number]>('Organisation')
  const [wizardOpen, setWizardOpen] = useState(false)
  const [editing, setEditing] = useState(false)
  const [confirmSave, setConfirmSave] = useState(false)
  const [draft, setDraft] = useState({ legalName: '', rc: '', tin: '', contact: '' })

  const facility = facilities.find((f) => f.id === facilityId) ?? facilities[0]
  const extra = PROFILE_EXTRA[facility.id]

  const startEdit = () => {
    setDraft({
      legalName: extra.legalName,
      rc: extra.rc,
      tin: extra.tin,
      contact: extra.reportingContact,
    })
    setEditing(true)
  }

  const saveEdit = () => {
    appendAudit({
      actor: 'Engr. T. Wokoma',
      role: 'operator',
      action: 'FACILITY_UPDATED',
      entity: facility.id,
      detail: `Facility profile updated — organisation record edited (demo); change audit-logged`,
    })
    setConfirmSave(false)
    setEditing(false)
    toast('Facility record updated — change written to the audit chain.')
  }

  const orgRows: Array<[string, keyof typeof draft | null, string]> = [
    ['Legal name', 'legalName', extra.legalName],
    ['RC number', 'rc', extra.rc],
    ['Sector', null, extra.sectorDetail],
    ['TIN', 'tin', extra.tin],
    ['Reporting contact', 'contact', extra.reportingContact],
  ]

  return (
    <div className="flex flex-col gap-10">
      {/* ------------------------------------------------ Section 1 — header */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: EASE }}
        className="flex flex-wrap items-end justify-between gap-4"
      >
        <h1 className="font-display text-[40px] leading-[1.05] text-ink">Facility profile.</h1>
        <div className="flex flex-wrap items-center gap-3">
          <FacilitySwitcher value={facilityId} onChange={setFacilityId} />
          <button
            type="button"
            onClick={() => setWizardOpen(true)}
            className="rounded-[2px] border border-ink/30 px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ink transition-all duration-200 hover:-translate-y-px hover:border-ink hover:bg-sand"
          >
            Register a new facility
          </button>
          <StatusChip status={`Approved — ${facility.approvedOn}`} />
        </div>
      </motion.div>

      {/* ------------------------------------------- Section 2 — header band */}
      <motion.div
        key={facility.id}
        initial={{ clipPath: 'inset(0 100% 0 0)' }}
        animate={{ clipPath: 'inset(0 0% 0 0)' }}
        transition={{ duration: 0.9, ease: EASE }}
        className="relative overflow-hidden rounded-[2px] border border-petrol-deep bg-petrol-deep"
      >
        <img
          src={extra.headerImage}
          alt=""
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 h-full w-full object-cover opacity-[0.18]"
        />
        <div className="relative flex flex-wrap items-end justify-between gap-6 px-8 py-8">
          <div>
            <motion.p
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.2, ease: EASE }}
              className="kicker text-ivory/50"
            >
              {facility.id}
            </motion.p>
            <motion.h2
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.28, ease: EASE }}
              className="mt-2 font-display text-[36px] leading-none text-ivory"
            >
              {facility.name}
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.36, ease: EASE }}
              className="mt-3 font-sans text-[13px] text-ivory/70"
            >
              {facility.operatorOrg} · {extra.sectorDetail} · {facility.lga}, {facility.state}
            </motion.p>
          </div>
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.44, ease: EASE }}
            className="flex flex-col items-start gap-1.5"
          >
            <span className="data-s text-ivory/60">
              {facility.coords.lat.toFixed(4)}° N, {facility.coords.lon.toFixed(4)}° E (demo)
            </span>
            <span className="data-s text-ivory/60">Approved {facility.approvedOn}</span>
            <span className="data-s text-ivory/60">
              Monitoring plan {facility.plan.version} — approved
            </span>
          </motion.div>
        </div>
      </motion.div>

      {/* -------------------------------------- Section 3 — profile + right rail */}
      <div className="grid grid-cols-1 gap-8 lg:grid-cols-[1fr_300px]">
        <div>
          {/* tabs */}
          <div className="flex flex-wrap gap-6 border-b border-line/60">
            {TABS.map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setTab(t)}
                className={cn(
                  'kicker relative pb-3 transition-colors',
                  tab === t ? 'text-ink' : 'text-muted hover:text-ink',
                )}
              >
                {t}
                {tab === t && (
                  <motion.span
                    layoutId="facility-tab-underline"
                    className="absolute bottom-0 left-0 h-[2px] w-full bg-petrol"
                    transition={{ duration: 0.25, ease: EASE }}
                  />
                )}
              </button>
            ))}
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={facility.id + tab}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25, ease: EASE }}
              className="pt-6"
            >
              {/* ------------------------------------------- Organisation */}
              {tab === 'Organisation' && (
                <div>
                  <div className="mb-2 flex justify-end">
                    {editing ? (
                      <div className="flex gap-3">
                        <button
                          type="button"
                          onClick={() => setEditing(false)}
                          className="font-sans text-[13px] font-medium text-muted transition-colors hover:text-ink"
                        >
                          Cancel
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmSave(true)}
                          className="rounded-[2px] bg-petrol px-4 py-2 font-sans text-[13px] font-semibold text-ivory transition-colors hover:bg-petrol-deep"
                        >
                          Save changes
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={startEdit}
                        className="link-sweep font-sans text-[13px] font-medium text-petrol"
                      >
                        Edit record
                      </button>
                    )}
                  </div>
                  <div className="rounded-[2px] border border-line/70 bg-ivory">
                    {orgRows.map(([label, key, value], i) => (
                      <motion.div
                        key={label}
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3, delay: i * 0.05, ease: EASE }}
                        className="flex items-center gap-6 border-b border-line/40 px-5 py-3.5 last:border-b-0"
                      >
                        <span className="kicker w-[130px] shrink-0 text-muted">{label}</span>
                        {editing && key ? (
                          <input
                            value={draft[key]}
                            onChange={(e) => setDraft((d) => ({ ...d, [key]: e.target.value }))}
                            className="w-full max-w-[420px] rounded-[2px] border border-line bg-ivory px-3 py-1.5 font-sans text-[14px] text-ink focus:border-petrol focus:outline-none focus:ring-2 focus:ring-copper focus:ring-offset-2"
                          />
                        ) : (
                          <span className="font-sans text-[14px] text-ink">{value}</span>
                        )}
                      </motion.div>
                    ))}
                  </div>
                </div>
              )}

              {/* --------------------------------------- Boundaries & units */}
              {tab === 'Boundaries & units' && (
                <div className="flex flex-col gap-5">
                  <p className="rounded-[2px] border border-line border-l-4 border-l-petrol bg-ivory px-5 py-4 font-sans text-[13px] leading-[1.6] text-ink">
                    {extra.boundaryNote}
                  </p>
                  <DataTable>
                    <DataTableHead columns={['Unit', 'Type', 'Streams']} />
                    <tbody>
                      {extra.unitRows.map((u) => (
                        <DataTableRow key={u.unit}>
                          <DataTableCell>{u.unit}</DataTableCell>
                          <DataTableCell mono={false}>{u.type}</DataTableCell>
                          <DataTableCell mono={false}>{u.stream}</DataTableCell>
                        </DataTableRow>
                      ))}
                    </tbody>
                  </DataTable>
                </div>
              )}

              {/* ------------------------------------------------- Permits */}
              {tab === 'Permits' && (
                <DataTable>
                  <DataTableHead columns={['Permit', 'Issuer', 'Number', 'Expiry', 'Evidence', 'Status']} />
                  <tbody>
                    {extra.permitRows.map((p) => {
                      const days = p.expiry !== '—' ? daysUntil(p.expiry) : null
                      const renewalDue = days !== null && days < 90
                      const permitHash = demoHash(`permit|${facility.id}|${p.number}`)
                      return (
                        <DataTableRow key={p.number}>
                          <DataTableCell mono={false} className="font-medium">
                            {p.permit}
                          </DataTableCell>
                          <DataTableCell mono={false}>{p.issuer}</DataTableCell>
                          <DataTableCell>{p.number}</DataTableCell>
                          <DataTableCell>{p.expiry}</DataTableCell>
                          <DataTableCell mono={false}>
                            <span className="flex items-center gap-2">
                              <FileText className="h-3.5 w-3.5 text-muted" strokeWidth={1.75} />
                              <span className="font-sans text-[12px] text-muted">permit.pdf —</span>
                              <HashChip hash={permitHash} />
                            </span>
                          </DataTableCell>
                          <DataTableCell mono={false}>
                            <span className="flex items-center gap-2">
                              <StatusChip status="Valid" />
                              {renewalDue && <StatusChip status="Renewal due" />}
                            </span>
                          </DataTableCell>
                        </DataTableRow>
                      )
                    })}
                  </tbody>
                </DataTable>
              )}

              {/* --------------------------------------- Location & contacts */}
              {tab === 'Location & contacts' && (
                <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                  <div className="relative overflow-hidden rounded-[2px] border border-line/70 bg-ivory">
                    <img src="/nigeria-map.svg" alt={`Map of Nigeria — ${extra.pinLabel} highlighted`} className="h-full w-full object-cover" />
                    <motion.span
                      className="absolute bottom-4 left-4 flex items-center gap-2 rounded-[2px] bg-petrol-deep px-3 py-2"
                      animate={{ opacity: [1, 0.75, 1] }}
                      transition={{ duration: 2.4, repeat: Infinity, ease: 'easeInOut' }}
                    >
                      <MapPin className="h-3.5 w-3.5 text-copper-light" strokeWidth={1.75} />
                      <span className="data-s text-ivory">
                        {extra.pinLabel} · {facility.coords.lat.toFixed(4)}° N, {facility.coords.lon.toFixed(4)}° E (demo)
                      </span>
                    </motion.span>
                  </div>
                  <div className="flex flex-col gap-4">
                    {extra.contacts.map((c) => (
                      <div key={c.label} className="rounded-[2px] border border-line/70 bg-ivory p-5">
                        <p className="kicker text-muted">{c.label}</p>
                        <p className="mt-2 font-sans text-[14px] font-medium text-ink">{c.name}</p>
                        <p className="mt-1 data-s text-muted">{c.phone}</p>
                        <p className="data-s text-muted">{c.email}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* -------------------------------------------- Status history */}
              {tab === 'Status history' && (
                <div className="flex flex-col">
                  {extra.statusHistory.map((s, i) => (
                    <motion.div
                      key={s.label}
                      initial={{ opacity: 0, x: -16 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.4, delay: i * 0.08, ease: EASE }}
                      className="relative flex gap-4 pb-6 pl-6 last:pb-0"
                    >
                      {i < extra.statusHistory.length - 1 && (
                        <span className="absolute left-[3.5px] top-3 h-full w-px bg-line/60" aria-hidden="true" />
                      )}
                      <span
                        className={cn(
                          'absolute left-0 top-1.5 h-2 w-2',
                          s.tone === 'petrol' && 'bg-petrol',
                          s.tone === 'copper' && 'bg-copper',
                          s.tone === 'alert' && 'bg-alert',
                          s.tone === 'ink' && 'bg-ink',
                        )}
                        aria-hidden="true"
                      />
                      <div className="flex min-w-0 flex-1 flex-wrap items-baseline gap-x-4 gap-y-1">
                        <p className="font-sans text-[13px] font-medium text-ink">{s.label}</p>
                        <span className="data-s text-muted">{s.ts}</span>
                        <HashChip hash={s.hash} />
                      </div>
                    </motion.div>
                  ))}
                  <p className="mt-2 font-sans text-[12px] text-muted">
                    Lifecycle: draft → submitted → approved. Every transition is hash-chained.
                  </p>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* right rail — "What this unlocks" (persistent across tabs) */}
        <aside className="h-fit rounded-[2px] border border-line/70 bg-ivory p-6 lg:sticky lg:top-32">
          <p className="kicker text-muted">What this unlocks</p>
          <LedgerRule className="mt-3" />
          <ul className="mt-5 flex flex-col gap-4">
            <TickItem label={`Facility approved — ${facility.approvedOn}`} delay={0.1} />
            <TickItem label={`Monitoring plan ${facility.plan.version} approved`} delay={0.25} />
            <TickItem label="Reporting enabled" delay={0.4} />
          </ul>
          <p className="mt-5 font-sans text-[13px] leading-[1.6] text-muted">
            An approved facility with an approved monitoring plan may submit activity data. Anything
            less, and reporting stays locked.
          </p>
        </aside>
      </div>

      {/* onboarding wizard (fullscreen overlay — replaces route /operator/facility/new) */}
      <OnboardingWizard open={wizardOpen} onClose={() => setWizardOpen(false)} />

      {/* save confirmation modal (§6.13) */}
      <AnimatePresence>
        {confirmSave && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-0 z-[60] flex items-center justify-center bg-petrol-deep/60 backdrop-blur-[4px]"
            onClick={() => setConfirmSave(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.97 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.97 }}
              transition={{ duration: 0.25, ease: EASE }}
              className="w-full max-w-[560px] rounded-[2px] border border-line bg-ivory p-8"
              onClick={(e) => e.stopPropagation()}
              role="alertdialog"
              aria-label="Confirm profile change"
            >
              <h3 className="font-display text-[28px] text-ink">Save changes to the record?</h3>
              <LedgerRule className="mt-4" />
              <p className="mt-4 flex items-start gap-2 font-sans text-[13px] leading-[1.6] text-muted">
                <Check className="mt-0.5 h-4 w-4 shrink-0 text-petrol" strokeWidth={1.75} />
                This edit is written to the audit chain with a hash and your name, alongside the
                previous value. The facility status stays APPROVED.
              </p>
              <div className="mt-6 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setConfirmSave(false)}
                  className="rounded-[2px] border border-ink/30 px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ink transition-colors hover:border-ink hover:bg-sand"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={saveEdit}
                  className="rounded-[2px] bg-petrol px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ivory transition-all duration-200 hover:-translate-y-px hover:bg-petrol-deep"
                >
                  Save changes
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
