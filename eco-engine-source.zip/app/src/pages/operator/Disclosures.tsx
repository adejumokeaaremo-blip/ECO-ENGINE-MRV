/**
 * Page 07 — Disclosure Packs (/operator/disclosures), disclosure-packs.md.
 * IFRS S2 metrics pack + GRI 305 tables, generated from regulator-verified data
 * only — the verified-only rule is stated on the face of every pack. Preview,
 * download (audit-logged), generation log, and the live "excluded" strip.
 */
import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router'
import { AnimatePresence, motion } from 'framer-motion'
import { toast } from 'sonner'
import { ChevronLeft, ChevronRight, Download, Eye } from 'lucide-react'
import { cn } from '@/lib/utils'
import { FACILITIES, type Facility } from '@/lib/demo-data'
import { appendAudit, demoHash, truncateHash, useAuditTrail, useRole, useSubmissions } from '@/lib/store'
import AILabel from '@/components/app/AILabel'
import HashChip from '@/components/app/HashChip'
import LedgerRule from '@/components/app/LedgerRule'
import {
  AccentButton,
  EASE_PRIMARY,
  Modal,
  PageHeader,
  SecondaryButton,
} from './components/reporting/shared'

/* ------------------------------------------------------------- pack data */

interface PackMetric {
  metric: string
  value: string
  note?: string
  bold?: boolean
}

interface PackDef {
  key: string
  title: string
  subtitle: string
  metrics: PackMetric[]
  gasBreakdown?: PackMetric[]
  hash: string
}

function packsFor(facility: Facility): PackDef[] {
  if (facility.id === 'FAC-KOG-002') {
    return [
      {
        key: 'ifrs',
        title: 'IFRS S2 — Metrics & Targets pack',
        subtitle: 'Generated 14 Jul 2026 · covers Scope 1 · demo data',
        metrics: [
          { metric: 'Scope 1 GHG emissions (gross)', value: '1,131,000 tCO₂e', note: '12 verified months' },
          { metric: '— of which clinker process CO₂', value: '736,320 tCO₂e', note: 'IPCC 2006 Vol. 3 Eq. 2.4' },
          { metric: '— of which stationary combustion (petcoke)', value: '341,200 tCO₂e' },
          { metric: '— of which stationary combustion (gas)', value: '53,480 tCO₂e' },
          { metric: 'GHG intensity (tCO₂e per t clinker)', value: '0.80', note: 'facility-defined denominator (demo)' },
          { metric: 'Data quality (DQI, period-end)', value: '71', note: 'published 02 Jul 2026' },
        ],
        hash: demoHash('pack|ifrs|FAC-KOG-002|FY25-26'),
      },
      {
        key: 'gri',
        title: 'GRI 305 — Emissions tables',
        subtitle: 'Generated 14 Jul 2026 · covers Scope 1 · demo data',
        metrics: [
          { metric: 'Clinker process CO₂', value: '736,320 tCO₂e' },
          { metric: 'Stationary combustion — petcoke', value: '341,200 tCO₂e' },
          { metric: 'Stationary combustion — gaseous fuels', value: '53,480 tCO₂e' },
          { metric: 'Total direct (Scope 1) GHG emissions', value: '1,131,000 tCO₂e', bold: true },
        ],
        gasBreakdown: [
          { metric: 'CO₂', value: '1,118,400 tCO₂e' },
          { metric: 'CH₄', value: '9,300 tCO₂e' },
          { metric: 'N₂O', value: '3,300 tCO₂e' },
        ],
        hash: demoHash('pack|gri|FAC-KOG-002|FY25-26'),
      },
    ]
  }
  return [
    {
      key: 'ifrs',
      title: 'IFRS S2 — Metrics & Targets pack',
      subtitle: 'Generated 14 Jul 2026 · covers Scope 1 · demo data',
      metrics: [
        { metric: 'Scope 1 GHG emissions (gross)', value: '384,812 tCO₂e', note: '12 verified months' },
        { metric: '— of which flaring', value: '247,960 tCO₂e', note: 'GGFR-aligned factor' },
        { metric: '— of which stationary combustion (gas)', value: '135,270 tCO₂e' },
        { metric: '— of which stationary combustion (diesel)', value: '1,582 tCO₂e' },
        { metric: 'GHG intensity (tCO₂e per MMscf throughput)', value: '2.94', note: 'facility-defined denominator (demo)' },
        { metric: 'Data quality (DQI, period-end)', value: '86', note: 'published 02 Jul 2026' },
      ],
      hash: demoHash('pack|ifrs|FAC-RIV-004|FY25-26'),
    },
    {
      key: 'gri',
      title: 'GRI 305 — Emissions tables',
      subtitle: 'Generated 14 Jul 2026 · covers Scope 1 · demo data',
      metrics: [
        { metric: 'Flaring', value: '247,960 tCO₂e' },
        { metric: 'Stationary combustion — gaseous fuels', value: '135,270 tCO₂e' },
        { metric: 'Stationary combustion — liquid fuels', value: '1,582 tCO₂e' },
        { metric: 'Total direct (Scope 1) GHG emissions', value: '384,812 tCO₂e', bold: true },
      ],
      gasBreakdown: [
        { metric: 'CO₂', value: '381,900 tCO₂e' },
        { metric: 'CH₄', value: '2,140 tCO₂e' },
        { metric: 'N₂O', value: '772 tCO₂e' },
      ],
      hash: demoHash('pack|gri|FAC-RIV-004|FY25-26'),
    },
  ]
}

interface LogRow {
  ts: string
  pack: string
  period: string
  cutoff: string
  actor: string
  hash: string
}

const SEED_LOG: LogRow[] = [
  {
    ts: '14 Jul 2026 16:05',
    pack: 'IFRS S2 pack',
    period: 'FY25–26',
    cutoff: demoHash('cutoff|FY25-26|verified'),
    actor: 'Engr. T. Wokoma',
    hash: demoHash('packlog|ifrs|14-jul-1605'),
  },
  {
    ts: '14 Jul 2026 16:04',
    pack: 'GRI 305 tables',
    period: 'FY25–26',
    cutoff: demoHash('cutoff|FY25-26|verified'),
    actor: 'Engr. T. Wokoma',
    hash: demoHash('packlog|gri|14-jul-1604'),
  },
  {
    ts: '01 Jul 2026 10:12',
    pack: 'GRI 305 tables',
    period: 'Q4 FY25',
    cutoff: demoHash('cutoff|Q4-FY25|verified'),
    actor: 'Engr. T. Wokoma',
    hash: demoHash('packlog|gri|01-jul-1012'),
  },
]

/* ---------------------------------------------------------- pack document */

function packText(facility: Facility, pack: PackDef, cutoff: string): string {
  const lines = [
    'ECO ENGINE — DISCLOSURE PACK (DEMONSTRATOR — demonstration data)',
    '='.repeat(64),
    `Pack:      ${pack.title}`,
    `Facility:  ${facility.name} (${facility.id})`,
    `Operator:  ${facility.operatorOrg}`,
    `Period:    FY Jul 2025 – Jun 2026`,
    `Cut-off:   14 Jul 2026 16:02 WAT — source hash ${truncateHash(cutoff)}`,
    '',
    'VERIFIED-ONLY RULE: every figure below traces to a submission accepted',
    'by an accredited verifier. Pending AI estimates are excluded.',
    '',
    ...pack.metrics.map((m) => `${m.metric.padEnd(52)} ${m.value}${m.note ? `   (${m.note})` : ''}`),
    ...(pack.gasBreakdown
      ? ['', 'By gas:', ...pack.gasBreakdown.map((m) => `${m.metric.padEnd(52)} ${m.value}`)]
      : []),
    '',
    `Pack hash: ${pack.hash}`,
    'Generated from regulator-verified data. Not an official record.',
  ]
  return lines.join('\n')
}

/* ================================================================== page */

export default function Disclosures() {
  const { persona } = useRole()
  const submissions = useSubmissions()
  const audit = useAuditTrail()

  const [facilityId, setFacilityId] = useState(FACILITIES[0].id)
  const facility = FACILITIES.find((f) => f.id === facilityId) ?? FACILITIES[0]
  const packs = useMemo(() => packsFor(facility), [facility])

  const [preview, setPreview] = useState<PackDef | null>(null)
  const [downloading, setDownloading] = useState<string | null>(null)
  const [logRows, setLogRows] = useState<LogRow[]>(SEED_LOG)

  const cutoffHash = audit.length > 0 ? audit[audit.length - 1].hash : demoHash('genesis')

  /** Live verified-only exclusion: pending/queried AI estimates never enter a pack. */
  const excluded = submissions.filter(
    (s) => s.facilityId === facility.id && (s.status === 'Pending' || s.status === 'Queried'),
  )

  const download = (pack: PackDef) => {
    if (downloading) return
    setDownloading(pack.key)
    window.setTimeout(() => {
      const blob = new Blob([packText(facility, pack, cutoffHash)], { type: 'text/plain' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `ECO-ENGINE_${pack.key === 'ifrs' ? 'IFRS-S2' : 'GRI-305'}_${facility.id}_FY25-26_demo.txt`
      a.click()
      URL.revokeObjectURL(url)
      const entry = appendAudit({
        actor: persona.name,
        role: 'operator',
        action: 'DISCLOSURE_PACK_GENERATED',
        entity: `${pack.key.toUpperCase()}-${facility.id}`,
        detail: `${pack.title} · FY Jul 2025 – Jun 2026 · verified-only cut-off ${truncateHash(cutoffHash)}`,
      })
      const now = new Date()
      setLogRows((prev) => [
        {
          ts: `15 Jul 2026 ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`,
          pack: pack.key === 'ifrs' ? 'IFRS S2 pack' : 'GRI 305 tables',
          period: 'FY25–26',
          cutoff: cutoffHash,
          actor: persona.name,
          hash: entry.hash,
        },
        ...prev,
      ])
      setDownloading(null)
      toast(`Logged to audit chain — ${truncateHash(entry.hash)}`)
    }, 1200)
  }

  return (
    <div>
      <PageHeader
        crumb="Operator / Disclosure Packs"
        title="Disclosure packs."
        sub="Reporting-grade outputs. Generated from regulator-verified data only — pending AI estimates never enter a pack."
        actions={
          <div className="flex items-center rounded-[2px] border border-line/60">
            {FACILITIES.map((f) => (
              <button
                key={f.id}
                type="button"
                onClick={() => setFacilityId(f.id)}
                className={cn(
                  'px-3 py-2 font-mono text-[11px] tracking-[0.02em] transition-colors',
                  facilityId === f.id ? 'bg-petrol text-ivory' : 'text-muted hover:text-ink',
                )}
              >
                {f.id}
              </button>
            ))}
          </div>
        }
      />

      {/* -------------------------------------- §2 verified-only banner */}
      <motion.section
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.15 }}
        className="relative flex flex-wrap items-center justify-between gap-4 overflow-hidden rounded-[2px] border border-line bg-ivory px-6 py-5 pl-8"
      >
        <motion.span
          initial={{ scaleY: 0 }}
          animate={{ scaleY: 1 }}
          transition={{ duration: 0.4, ease: EASE_PRIMARY }}
          style={{ transformOrigin: 'top' }}
          className="absolute left-0 top-0 h-full w-[4px] bg-petrol"
          aria-hidden="true"
        />
        <div className="max-w-[720px]">
          <p className="kicker text-petrol">Verified-only rule</p>
          <p className="mt-2 font-sans text-[15px] leading-[1.6] text-ink">
            Every figure in every pack below traces to a submission{' '}
            <span className="font-semibold">accepted by an accredited verifier</span>. The current
            packs exclude {excluded.length} pending AI estimate{excluded.length === 1 ? '' : 's'} —
            {excluded.length === 1 ? ' it' : ' they'} will be included after verification.
          </p>
        </div>
        <p className="font-mono text-[11px] tracking-[0.02em] text-muted">
          Cut-off: 14 Jul 2026 16:02 WAT
        </p>
      </motion.section>

      {/* -------------------------------------- §3 pack library */}
      <div className="mt-8 flex flex-col gap-8">
        {packs.map((pack, pi) => (
          <motion.section
            key={pack.key + facility.id}
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 + pi * 0.12, ease: EASE_PRIMARY }}
            className="rounded-[2px] border border-line bg-ivory"
          >
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line/60 px-8 py-6">
              <div>
                <h2 className="font-display text-[24px] leading-[1.1] text-ink">{pack.title}</h2>
                <p className="mt-1 font-mono text-[11px] tracking-[0.02em] text-muted">
                  {pack.subtitle} · FY Jul 2025 – Jun 2026 · {facility.name}
                </p>
              </div>
              <span className="inline-flex items-center rounded-[2px] bg-petrol px-[10px] py-[6px] font-sans text-[10px] font-semibold uppercase tracking-chip text-ivory">
                Generated from regulator-verified data
              </span>
            </div>

            <div className="px-8 py-4">
              <table className="w-full">
                <tbody>
                  {pack.metrics.map((m, i) => (
                    <motion.tr
                      key={m.metric}
                      initial={{ opacity: 0, y: 6 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: 0.3 + i * 0.03, ease: EASE_PRIMARY }}
                      className={cn('border-b border-line/40 last:border-0', m.bold && 'bg-sand/50')}
                    >
                      <td
                        className={cn(
                          'py-2.5 pr-4 font-sans text-[13px]',
                          m.bold ? 'font-semibold text-petrol' : 'text-ink',
                        )}
                      >
                        {m.metric}
                      </td>
                      <td
                        className={cn(
                          'w-[220px] py-2.5 pr-4 text-right font-mono text-[13px]',
                          m.bold ? 'font-semibold text-petrol' : 'text-ink',
                        )}
                      >
                        {m.value}
                      </td>
                      <td className="w-[260px] py-2.5 font-mono text-[11px] tracking-[0.02em] text-muted">
                        {m.note ?? ''}
                      </td>
                    </motion.tr>
                  ))}
                  {pack.gasBreakdown && (
                    <tr>
                      <td colSpan={3} className="pt-3">
                        <p className="kicker mb-2 text-muted">By gas (demo)</p>
                        <div className="flex flex-wrap gap-6 pb-2">
                          {pack.gasBreakdown.map((g) => (
                            <span key={g.metric} className="font-mono text-[12px] text-ink">
                              {g.metric} <span className="text-muted">{g.value}</span>
                            </span>
                          ))}
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-4 border-t border-line/60 px-8 py-5">
              <div className="flex items-center gap-3">
                <SecondaryButton onClick={() => setPreview(pack)}>
                  <Eye className="h-4 w-4" strokeWidth={1.75} /> Preview PDF
                </SecondaryButton>
                <AccentButton onClick={() => download(pack)} disabled={downloading !== null}>
                  <Download className="h-4 w-4" strokeWidth={1.75} />
                  {downloading === pack.key ? 'Generating…' : 'Download pack'}
                </AccentButton>
              </div>
              <div className="flex items-center gap-3">
                <AnimatePresence>
                  {downloading === pack.key && (
                    <motion.span
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="h-[2px] w-[120px] bg-line/50"
                    >
                      <motion.span
                        initial={{ scaleX: 0 }}
                        animate={{ scaleX: 1 }}
                        transition={{ duration: 1.2, ease: EASE_PRIMARY }}
                        style={{ transformOrigin: 'left' }}
                        className="block h-full bg-petrol"
                      />
                    </motion.span>
                  )}
                </AnimatePresence>
                <HashChip hash={pack.hash} />
              </div>
            </div>
          </motion.section>
        ))}
      </div>

      {/* -------------------------------------- §4 generation log */}
      <section className="mt-12">
        <p className="kicker mb-4 text-muted">Generation log — every pack is an audit event</p>
        <div className="rounded-[2px] border border-line bg-ivory">
          <ul className="divide-y divide-line/40">
            {logRows.map((r, i) => (
              <motion.li
                key={r.hash + r.ts}
                initial={{ opacity: 0, x: -16 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: Math.min(i * 0.08, 0.5), ease: EASE_PRIMARY }}
                className="flex flex-wrap items-center gap-x-6 gap-y-1 px-6 py-4"
              >
                <span className="w-[150px] font-mono text-[12px] text-ink">{r.ts}</span>
                <span className="w-[140px] font-sans text-[13px] font-semibold text-ink">{r.pack}</span>
                <span className="w-[80px] font-mono text-[12px] text-muted">{r.period}</span>
                <span className="font-mono text-[11px] tracking-[0.02em] text-muted">
                  cut-off {truncateHash(r.cutoff)}
                </span>
                <span className="flex-1 font-sans text-[12px] text-muted">{r.actor}</span>
                <HashChip hash={r.hash} />
                <Link to="/audit" className="link-sweep font-sans text-[12px] font-semibold text-petrol">
                  Audit →
                </Link>
              </motion.li>
            ))}
          </ul>
        </div>
      </section>

      {/* -------------------------------------- §5 excluded strip */}
      <section className="mt-12 border-t border-line/60 pt-8">
        <p className="kicker mb-4 text-muted">Excluded from current packs</p>
        {excluded.length === 0 ? (
          <p className="font-sans text-[13px] text-muted">
            Nothing pending — every AI estimate for this facility has been verified and will flow
            into the next generated pack.
          </p>
        ) : (
          <ul className="space-y-3">
            {excluded.map((s, i) => (
              <motion.li
                key={s.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.4, delay: i * 0.1 }}
                className="flex flex-wrap items-center gap-x-6 gap-y-2 rounded-[2px] border border-line/60 bg-ivory px-5 py-4"
              >
                <span className="font-mono text-[13px] text-petrol">{s.id}</span>
                <span className="font-sans text-[13px] text-ink">
                  {s.streamLabel} · {s.period}
                </span>
                <span className="font-mono text-[13px] text-ink">
                  {s.aiEstimate.replace(' tCO2e', '')}{' '}
                  <span className="text-muted">tCO₂e {s.uncertainty}</span>
                </span>
                <span className="font-sans text-[12px] text-muted">
                  {s.status === 'Queried' ? 'queried by verifier — awaiting operator response' : 'pending human verification'}
                </span>
                <motion.span
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ duration: 0.3, delay: 0.2 + i * 0.1 }}
                  className="ml-auto"
                >
                  <AILabel />
                </motion.span>
              </motion.li>
            ))}
          </ul>
        )}
        <p className="mt-4 font-sans text-[13px] leading-[1.6] text-muted">
          The moment a verifier accepts these, regenerated packs will include them — and the log
          above gains an entry.
        </p>
      </section>

      {/* -------------------------------------- preview modal */}
      <PackPreview
        pack={preview}
        facility={facility}
        cutoffHash={cutoffHash}
        onClose={() => setPreview(null)}
      />
    </div>
  )
}

/* ------------------------------------------------------- preview modal */

function PackPreview({
  pack,
  facility,
  cutoffHash,
  onClose,
}: {
  pack: PackDef | null
  facility: Facility
  cutoffHash: string
  onClose: () => void
}) {
  const [page, setPage] = useState(0)
  const [lastPack, setLastPack] = useState(pack)
  if (pack !== lastPack) {
    setLastPack(pack)
    setPage(0)
  }
  useEffect(() => {
    if (!pack) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') setPage((p) => Math.max(0, p - 1))
      if (e.key === 'ArrowRight') setPage((p) => Math.min(2, p + 1))
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [pack])

  if (!pack) return null
  const pages = 3

  return (
    <Modal open={!!pack} onClose={onClose} label={`Preview — ${pack.title}`} wide>
      <div className="px-8 py-8">
        <div className="flex items-center justify-between">
          <p className="kicker text-muted">
            Preview — page {page + 1} / {pages}
          </p>
          <div className="flex items-center gap-2 pr-8">
            <button
              type="button"
              onClick={() => setPage((p) => Math.max(0, p - 1))}
              disabled={page === 0}
              aria-label="Previous page"
              className="text-muted transition-colors hover:text-ink disabled:opacity-30"
            >
              <ChevronLeft className="h-4 w-4" strokeWidth={1.75} />
            </button>
            <button
              type="button"
              onClick={() => setPage((p) => Math.min(pages - 1, p + 1))}
              disabled={page === pages - 1}
              aria-label="Next page"
              className="text-muted transition-colors hover:text-ink disabled:opacity-30"
            >
              <ChevronRight className="h-4 w-4" strokeWidth={1.75} />
            </button>
          </div>
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={page}
            initial={{ opacity: 0, x: 16 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -16 }}
            transition={{ duration: 0.25, ease: EASE_PRIMARY }}
            className="mt-6 min-h-[380px] rounded-[2px] border border-line bg-sand/60 p-8"
          >
            {page === 0 && (
              <div className="flex h-full flex-col items-center justify-center text-center">
                <img src="/logo-mark.svg" alt="" className="h-10 w-10" />
                <p className="kicker mt-4 text-muted">ECO ENGINE — disclosure pack</p>
                <h3 className="mt-3 font-display text-[32px] leading-[1.1] text-ink">{pack.title}</h3>
                <p className="mt-2 font-sans text-[14px] text-muted">
                  {facility.name} · {facility.operatorOrg}
                </p>
                <p className="mt-1 font-mono text-[11px] tracking-[0.02em] text-muted">
                  FY Jul 2025 – Jun 2026 · {facility.state} · {facility.id}
                </p>
                <LedgerRule className="mx-auto mt-6 w-[200px]" />
                <p className="mt-6 font-mono text-[11px] tracking-[0.02em] text-muted">
                  Source data cut-off: 14 Jul 2026 16:02 WAT · {truncateHash(cutoffHash)}
                </p>
                <p className="mt-2 font-mono text-[11px] tracking-[0.02em] text-copper">
                  DEMONSTRATOR — demonstration data
                </p>
              </div>
            )}
            {page === 1 && (
              <div>
                <p className="kicker mb-4 text-muted">Metrics — verified data only</p>
                <table className="w-full">
                  <tbody>
                    {pack.metrics.map((m) => (
                      <tr key={m.metric} className="border-b border-line/40 last:border-0">
                        <td className={cn('py-2 pr-4 font-sans text-[13px]', m.bold ? 'font-semibold text-petrol' : 'text-ink')}>
                          {m.metric}
                        </td>
                        <td className={cn('py-2 text-right font-mono text-[13px]', m.bold ? 'font-semibold text-petrol' : 'text-ink')}>
                          {m.value}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {pack.gasBreakdown && (
                  <div className="mt-4 flex flex-wrap gap-6">
                    {pack.gasBreakdown.map((g) => (
                      <span key={g.metric} className="font-mono text-[12px] text-ink">
                        {g.metric} <span className="text-muted">{g.value}</span>
                      </span>
                    ))}
                  </div>
                )}
              </div>
            )}
            {page === 2 && (
              <div>
                <p className="kicker mb-4 text-muted">Provenance & disclaimer</p>
                <ul className="space-y-3 font-sans text-[13px] leading-[1.6] text-ink">
                  <li>
                    Every figure traces to a submission accepted by an accredited verifier (ISO
                    14065). Pending AI estimates are excluded by rule.
                  </li>
                  <li>
                    Emission factors: IPCC 2006/2019-aligned defaults; flaring factor derived per
                    GGFR guidance (illustrative, demonstration data).
                  </li>
                  <li>
                    Source cut-off hash <span className="font-mono text-[12px]">{truncateHash(cutoffHash)}</span> —
                    verifiable against the audit chain.
                  </li>
                  <li className="font-mono text-[11px] tracking-[0.02em] text-copper">
                    DEMONSTRATOR — demonstration data · not an official record
                  </li>
                </ul>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </Modal>
  )
}
