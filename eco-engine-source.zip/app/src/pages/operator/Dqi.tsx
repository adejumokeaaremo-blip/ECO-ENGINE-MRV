/**
 * Page 06 — Data Quality Index (/operator/dqi), dqi.md.
 * Facility gauge + 12-month trend, per-stream gauges, §8 component weights
 * (metered 30 · calibration 20 · completeness 20 · timeliness 15 · verification 15),
 * and the immutable publication history.
 */
import { useState } from 'react'
import { Link } from 'react-router'
import { AnimatePresence, motion } from 'framer-motion'
import { ChevronDown } from 'lucide-react'
import { cn } from '@/lib/utils'
import { DQI_WEIGHTS, FACILITIES } from '@/lib/demo-data'
import { demoHash } from '@/lib/store'
import DqiGauge from '@/components/app/DqiGauge'
import HashChip from '@/components/app/HashChip'
import LedgerRule from '@/components/app/LedgerRule'
import DataTable, { DataTableHead } from '@/components/app/DataTable'
import { DqiTrendChart, Sparkline, type TrendAnnotation } from './components/reporting/DqiCharts'
import { EASE_PRIMARY, Modal, PageHeader } from './components/reporting/shared'

/* ------------------------------------------------------- per-facility data */

interface ComponentScore {
  label: string
  weight: number
  score: number
  detail: string
}

interface StreamDqi {
  id: string
  label: string
  score: number
  note: string | null
  components: ComponentScore[]
  spark: number[]
}

interface FacilityDqi {
  facilityId: string
  published: string
  components: ComponentScore[]
  trend: number[]
  annotations: TrendAnnotation[]
  streams: StreamDqi[]
  history: { ts: string; period: string; score: number; trigger: string; hash: string }[]
}

const DQI_DATA: Record<string, FacilityDqi> = {
  'FAC-RIV-004': {
    facilityId: 'FAC-RIV-004',
    published: '02 Jul 2026',
    components: [
      { label: 'Metered vs estimated share', weight: 30, score: 27, detail: '2 of 3 streams metered' },
      { label: 'Calibration status', weight: 20, score: 18, detail: 'FL-201 due in 62 days' },
      { label: 'Completeness', weight: 20, score: 20, detail: 'no missing periods in 12 months' },
      { label: 'Timeliness', weight: 15, score: 12, detail: '2 late submissions in Q1' },
      { label: 'Verification history', weight: 15, score: 9, detail: '1 query unresolved on peer facility note' },
    ],
    trend: [82, 82, 83, 83, 84, 84, 82, 83, 83, 86, 86, 86],
    annotations: [
      { index: 6, text: 'Jan 2026 — late submission −2' },
      { index: 9, text: 'Apr 2026 — calibration renewed +3' },
    ],
    streams: [
      {
        id: 'S1',
        label: 'Associated gas flared',
        score: 88,
        note: null,
        components: [
          { label: 'Metered share', weight: 30, score: 30, detail: 'ultrasonic meter FL-201' },
          { label: 'Calibration', weight: 20, score: 18, detail: 'due 15 Sep 2026' },
          { label: 'Completeness', weight: 20, score: 20, detail: '12/12 periods' },
          { label: 'Timeliness', weight: 15, score: 12, detail: '1 late submission' },
          { label: 'Verification', weight: 15, score: 8, detail: 'March accepted with note' },
        ],
        spark: [83, 83, 84, 84, 85, 85, 84, 85, 86, 88, 88, 88],
      },
      {
        id: 'S2',
        label: 'Fuel gas consumed',
        score: 87,
        note: null,
        components: [
          { label: 'Metered share', weight: 30, score: 30, detail: 'meter FG-104' },
          { label: 'Calibration', weight: 20, score: 18, detail: 'due 02 Nov 2026' },
          { label: 'Completeness', weight: 20, score: 20, detail: '12/12 periods' },
          { label: 'Timeliness', weight: 15, score: 12, detail: '1 late submission' },
          { label: 'Verification', weight: 15, score: 7, detail: 'June pending verification' },
        ],
        spark: [82, 82, 83, 83, 84, 84, 83, 84, 85, 87, 87, 87],
      },
      {
        id: 'S3',
        label: 'Diesel consumed (gensets)',
        score: 74,
        note: 'estimated method caps metered-share component',
        components: [
          { label: 'Metered share', weight: 30, score: 14, detail: 'estimated from delivery records — capped' },
          { label: 'Calibration', weight: 20, score: 20, detail: 'n/a — no meter' },
          { label: 'Completeness', weight: 20, score: 20, detail: '12/12 periods' },
          { label: 'Timeliness', weight: 15, score: 12, detail: '1 late submission' },
          { label: 'Verification', weight: 15, score: 8, detail: 'May verified' },
        ],
        spark: [68, 68, 69, 70, 71, 71, 70, 71, 72, 74, 74, 74],
      },
    ],
    history: [
      { ts: '02 Jul 2026 09:00', period: 'Jun 2026', score: 86, trigger: 'June verification cycle closed', hash: demoHash('dqi-pub|FAC-RIV-004|2026-07-02|86') },
      { ts: '02 Jun 2026 09:00', period: 'May 2026', score: 85, trigger: 'May verification cycle closed', hash: demoHash('dqi-pub|FAC-RIV-004|2026-06-02|85') },
      { ts: '02 May 2026 09:00', period: 'Apr 2026', score: 84, trigger: 'Plan v1.2 approval', hash: demoHash('dqi-pub|FAC-RIV-004|2026-05-02|84') },
    ],
  },
  'FAC-KOG-002': {
    facilityId: 'FAC-KOG-002',
    published: '02 Jul 2026',
    components: [
      { label: 'Metered vs estimated share', weight: 30, score: 28, detail: '3 of 3 streams metered' },
      { label: 'Calibration status', weight: 20, score: 18, detail: 'BS-22 & WF-07 due 30 Aug 2026' },
      { label: 'Completeness', weight: 20, score: 14, detail: 'February 2026 identical values under query' },
      { label: 'Timeliness', weight: 15, score: 6, detail: 'late submissions in Q1 and Q2' },
      { label: 'Verification history', weight: 15, score: 5, detail: 'open query on February clinker' },
    ],
    trend: [66, 67, 69, 71, 73, 76, 78, 71, 71, 71, 71, 71],
    annotations: [{ index: 7, text: 'Feb 2026 — identical values under query −7' }],
    streams: [
      {
        id: 'S1',
        label: 'Clinker production',
        score: 66,
        note: 'February values identical to January — under query',
        components: [
          { label: 'Metered share', weight: 30, score: 30, detail: 'belt scale BS-22' },
          { label: 'Calibration', weight: 20, score: 18, detail: 'due 30 Aug 2026' },
          { label: 'Completeness', weight: 20, score: 8, detail: 'February under query' },
          { label: 'Timeliness', weight: 15, score: 6, detail: '2 late submissions' },
          { label: 'Verification', weight: 15, score: 4, detail: 'open verifier query' },
        ],
        spark: [64, 65, 67, 69, 71, 74, 76, 66, 66, 66, 66, 66],
      },
      {
        id: 'S2',
        label: 'Kiln fuel — petcoke',
        score: 74,
        note: null,
        components: [
          { label: 'Metered share', weight: 30, score: 28, detail: 'weighfeeder WF-07' },
          { label: 'Calibration', weight: 20, score: 18, detail: 'due 30 Aug 2026' },
          { label: 'Completeness', weight: 20, score: 16, detail: '11/12 periods clean' },
          { label: 'Timeliness', weight: 15, score: 7, detail: '1 late submission' },
          { label: 'Verification', weight: 15, score: 5, detail: 'June pending — peer deviation flag' },
        ],
        spark: [68, 69, 70, 72, 73, 74, 75, 73, 74, 74, 74, 74],
      },
      {
        id: 'S3',
        label: 'Kiln fuel — natural gas',
        score: 78,
        note: null,
        components: [
          { label: 'Metered share', weight: 30, score: 30, detail: 'metered KG-03' },
          { label: 'Calibration', weight: 20, score: 18, detail: 'annual — current' },
          { label: 'Completeness', weight: 20, score: 18, detail: '11/12 periods' },
          { label: 'Timeliness', weight: 15, score: 7, detail: '1 late submission' },
          { label: 'Verification', weight: 15, score: 5, detail: 'no open queries' },
        ],
        spark: [72, 73, 74, 75, 76, 77, 78, 77, 78, 78, 78, 78],
      },
    ],
    history: [
      { ts: '02 Jul 2026 09:00', period: 'Jun 2026', score: 71, trigger: 'June verification cycle closed', hash: demoHash('dqi-pub|FAC-KOG-002|2026-07-02|71') },
      { ts: '02 Jun 2026 09:00', period: 'May 2026', score: 71, trigger: 'May verification cycle closed', hash: demoHash('dqi-pub|FAC-KOG-002|2026-06-02|71') },
      { ts: '02 May 2026 09:00', period: 'Apr 2026', score: 72, trigger: 'April verification cycle closed', hash: demoHash('dqi-pub|FAC-KOG-002|2026-05-02|72') },
    ],
  },
}

/* --------------------------------------------------------- component bar */

function ComponentBar({ c, index, small = false }: { c: ComponentScore; index: number; small?: boolean }) {
  const ratio = c.score / c.weight
  return (
    <div>
      <div className="flex items-baseline justify-between gap-4">
        <p className="kicker text-muted">
          {c.label} <span className="text-line">· weight {c.weight}%</span>
        </p>
        <p className={cn('font-mono', small ? 'text-[12px]' : 'text-[13px]', 'text-ink')}>
          {c.score}/{c.weight}
        </p>
      </div>
      <div className={cn('mt-1.5 w-full bg-line/40', small ? 'h-[3px]' : 'h-[4px]')}>
        <motion.div
          initial={{ scaleX: 0 }}
          whileInView={{ scaleX: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.9, delay: index * 0.1, ease: EASE_PRIMARY }}
          style={{ transformOrigin: 'left' }}
          className={cn('h-full', ratio >= 0.8 ? 'bg-petrol' : ratio >= 0.6 ? 'bg-copper' : 'bg-alert')}
        />
      </div>
      <p className="mt-1 font-mono text-[11px] tracking-[0.02em] text-muted">{c.detail}</p>
    </div>
  )
}

/* ================================================================= page */

export default function Dqi() {
  const [facilityId, setFacilityId] = useState(FACILITIES[0].id)
  const facility = FACILITIES.find((f) => f.id === facilityId) ?? FACILITIES[0]
  const data = DQI_DATA[facility.id]
  const [methodOpen, setMethodOpen] = useState(false)
  const [expandedStream, setExpandedStream] = useState<string | null>(null)

  const total = data.components.reduce((a, c) => a + c.score, 0)

  return (
    <div>
      <PageHeader
        crumb="Operator / DQI"
        title="Data Quality Index."
        sub="Published within the system. History is immutable — every publication is a hash-chained event."
        actions={
          <>
            <div className="flex items-center rounded-[2px] border border-line/60">
              {FACILITIES.map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => setFacilityId(f.id)}
                  className={cn(
                    'px-3 py-2 font-mono text-[11px] tracking-[0.02em] transition-colors',
                    facilityId === f.id ? 'bg-petrol text-ivory' : 'text-muted hover:text-ink',
                  )}
                >
                  {f.id}
                </button>
              ))}
            </div>
            <button type="button" onClick={() => setMethodOpen(true)}>
              <span className="inline-flex items-center rounded-[2px] bg-ink/10 px-[10px] py-[6px] font-sans text-[10px] font-semibold uppercase tracking-chip text-ink transition-colors hover:bg-ink/15">
                Methodology v1.0 — published
              </span>
            </button>
          </>
        }
      />

      {/* ------------------------------ §2 facility gauge hero */}
      <motion.section
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.1, ease: EASE_PRIMARY }}
        className="rounded-[2px] border border-line bg-ivory px-8 py-10"
      >
        <div className="grid gap-10 md:grid-cols-[2fr_3fr]">
          <div className="flex flex-col items-center justify-start text-center">
            <DqiGauge value={facility.dqi} size={220} />
            <p className="kicker mt-4 text-muted">Facility DQI — June 2026</p>
            <p className="mt-2 font-sans text-[13px] text-muted">
              {facility.name} · published {data.published}
            </p>
          </div>
          <div className="flex flex-col justify-center gap-5">
            {data.components.map((c, i) => (
              <ComponentBar key={c.label} c={c} index={i} />
            ))}
            <p className="mt-2 border-t border-line/40 pt-4 font-mono text-[11px] tracking-[0.02em] text-muted">
              Total {total}/100 — DQI is computed from system records only; it cannot be edited by hand.
            </p>
          </div>
        </div>
      </motion.section>

      {/* ------------------------------ §3 12-month trend */}
      <section className="mt-10">
        <p className="kicker mb-4 text-muted">DQI — 12-month trend</p>
        <div className="grid gap-8 rounded-[2px] border border-line bg-ivory px-8 py-8 lg:grid-cols-[3fr_1fr]">
          <DqiTrendChart values={data.trend} annotations={data.annotations} />
          <div className="flex items-center border-l border-line/40 pl-8">
            <p className="font-sans text-[13px] leading-[1.6] text-muted">
              DQI moves only when underlying records change: a meter recalibrated, a period
              completed, a query resolved.
            </p>
          </div>
        </div>
      </section>

      {/* ------------------------------ §4 per-stream table */}
      <section className="mt-10">
        <p className="kicker mb-4 text-muted">By data stream</p>
        <DataTable>
          <DataTableHead
            columns={['Stream', 'Gauge', 'Score', 'Metered', 'Calibration', 'Completeness', 'Timeliness', 'Verification', 'Trend', '']}
          />
          <tbody>
            {data.streams.map((s, i) => {
              const isOpen = expandedStream === s.id
              return (
                <StreamRow
                  key={s.id}
                  s={s}
                  i={i}
                  isOpen={isOpen}
                  onToggle={() => setExpandedStream(isOpen ? null : s.id)}
                />
              )
            })}
          </tbody>
        </DataTable>
      </section>

      {/* ------------------------------ §5 publication history */}
      <section className="mt-10">
        <p className="kicker mb-4 text-muted">Publication history — immutable</p>
        <DataTable>
          <DataTableHead columns={['Published', 'Period', 'Facility score', 'Trigger', 'Hash', '']} />
          <tbody>
            {data.history.map((h, i) => (
              <motion.tr
                key={h.hash}
                initial={{ opacity: 0, x: -16 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.05, ease: EASE_PRIMARY }}
                className="border-b border-line/40 transition-colors duration-150 hover:bg-ivory"
              >
                <td className="min-h-[44px] py-3 pr-4 align-middle font-mono text-[13px] text-ink">{h.ts}</td>
                <td className="py-3 pr-4 align-middle font-mono text-[13px] text-ink">{h.period}</td>
                <td className="py-3 pr-4 align-middle font-mono text-[13px] font-medium text-petrol">{h.score}</td>
                <td className="py-3 pr-4 align-middle font-sans text-[13px] text-ink">{h.trigger}</td>
                <td className="py-3 pr-4 align-middle">
                  <HashChip hash={h.hash} />
                </td>
                <td className="py-3 align-middle">
                  <Link to="/audit" className="link-sweep font-sans text-[12px] font-semibold text-petrol">
                    View event in audit trail →
                  </Link>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </DataTable>
      </section>

      {/* ------------------------------ §6 methodology dark band */}
      <section className="mt-12 rounded-[2px] bg-petrol-deep px-8 py-12">
        <p className="kicker text-copper-light">How the score is built</p>
        <p className="mt-4 max-w-[820px] font-display text-[24px] leading-[1.3] text-ivory">
          {'A regulator, a buyer, or a jury should never have to ask whether the data is good. The score is on the face of the record.'
            .split(' ')
            .map((w, i) => (
              <motion.span
                key={i}
                initial={{ opacity: 0, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.03, ease: EASE_PRIMARY }}
                className="inline-block"
              >
                {w}
                {'\u00A0'}
              </motion.span>
            ))}
        </p>
        <div className="mt-8 flex flex-wrap gap-3">
          {DQI_WEIGHTS.map((w, i) => (
            <motion.span
              key={w.component}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.3, delay: 0.3 + i * 0.08, ease: EASE_PRIMARY }}
              className="flex items-center gap-2 rounded-[2px] border border-ivory/15 px-3 py-2"
            >
              <span className="font-mono text-[13px] text-copper-light">{w.weight}</span>
              <span className="font-sans text-[11px] uppercase tracking-[0.12em] text-ivory/70">
                {w.component}
              </span>
            </motion.span>
          ))}
        </div>
      </section>

      {/* ------------------------------ methodology modal */}
      <Modal open={methodOpen} onClose={() => setMethodOpen(false)} label="DQI methodology v1.0" wide>
        <div className="px-8 py-8">
          <p className="kicker text-muted">Methodology v1.0 — published</p>
          <h2 className="mt-2 font-display text-[28px] leading-[1.1] text-ink">
            How the DQI is computed.
          </h2>
          <p className="mt-3 font-sans text-[13px] leading-[1.6] text-muted">
            Five components, weighted per the published methodology. The score is computed from
            system records only — it cannot be edited by hand, and every publication is a
            hash-chained event.
          </p>
          <LedgerRule className="my-6" />
          <table className="w-full">
            <thead>
              <tr className="border-b border-line">
                <th className="kicker py-2 pr-4 text-left font-semibold text-muted">Component</th>
                <th className="kicker py-2 pr-4 text-left font-semibold text-muted">Weight</th>
                <th className="kicker py-2 text-left font-semibold text-muted">
                  {facility.name} — Jun 2026
                </th>
              </tr>
            </thead>
            <tbody>
              {data.components.map((c) => (
                <tr key={c.label} className="border-b border-line/40">
                  <td className="py-2.5 pr-4 font-sans text-[13px] text-ink">{c.label}</td>
                  <td className="py-2.5 pr-4 font-mono text-[13px] text-ink">{c.weight}%</td>
                  <td className="py-2.5 font-mono text-[13px] text-ink">
                    {c.score}/{c.weight}{' '}
                    <span className="text-[11px] text-muted">— {c.detail}</span>
                  </td>
                </tr>
              ))}
              <tr>
                <td className="py-2.5 pr-4 font-sans text-[13px] font-semibold text-ink">Total</td>
                <td className="py-2.5 pr-4 font-mono text-[13px] text-ink">100%</td>
                <td className="py-2.5 font-mono text-[13px] font-semibold text-petrol">
                  {total}/100 → DQI {facility.dqi}
                </td>
              </tr>
            </tbody>
          </table>
          <p className="mt-4 font-mono text-[11px] leading-[1.5] tracking-[0.02em] text-muted">
            Worked example: {data.components.map((c) => c.score).join(' + ')} = {total}. Components
            recompute when a meter is recalibrated, a period completes, a deadline is missed, or a
            verifier closes a query.
          </p>
        </div>
      </Modal>
    </div>
  )
}

/* ------------------------------------------------------------- stream row */

function StreamRow({
  s,
  i,
  isOpen,
  onToggle,
}: {
  s: StreamDqi
  i: number
  isOpen: boolean
  onToggle: () => void
}) {
  const get = (label: string) => s.components.find((c) => c.label.startsWith(label))
  const cells = [get('Metered'), get('Calibration'), get('Completeness'), get('Timeliness'), get('Verification')]
  return (
    <>
      <motion.tr
        initial={{ opacity: 0, y: 8 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.35, delay: i * 0.04, ease: EASE_PRIMARY }}
        onClick={onToggle}
        className={cn(
          'group relative cursor-pointer border-b border-line/40 transition-colors duration-150 hover:bg-ivory',
          'before:absolute before:left-0 before:top-0 before:h-full before:w-[2px] before:bg-copper before:opacity-0 before:transition-opacity before:duration-150 hover:before:opacity-100',
        )}
      >
        <td className="min-h-[44px] py-3 pr-4 align-middle">
          <span className="font-sans text-[13px] font-semibold text-ink">
            {s.id} · {s.label}
          </span>
          {s.note && (
            <span className="block font-mono text-[11px] tracking-[0.02em] text-copper">{s.note}</span>
          )}
        </td>
        <td className="py-3 pr-4 align-middle">
          <DqiGauge value={s.score} size={60} />
        </td>
        <td className="py-3 pr-4 align-middle">
          <span
            className={cn(
              'font-display text-[24px] leading-none',
              s.score >= 80 ? 'text-petrol' : s.score >= 60 ? 'text-copper' : 'text-alert',
            )}
          >
            {s.score}
          </span>
        </td>
        {cells.map((c, j) => (
          <td key={j} className="py-3 pr-4 align-middle font-mono text-[12px] text-ink">
            {c ? `${c.score}/${c.weight}` : '—'}
          </td>
        ))}
        <td className="py-3 pr-4 align-middle">
          <Sparkline values={s.spark} tone={s.score >= 80 ? 'petrol' : 'copper'} />
        </td>
        <td className="py-3 align-middle">
          <ChevronDown
            className={cn('h-4 w-4 text-muted transition-transform duration-200', isOpen && 'rotate-180')}
            strokeWidth={1.75}
          />
        </td>
      </motion.tr>
      <AnimatePresence>
        {isOpen && (
          <tr>
            <td colSpan={10} className="border-b border-line/40 p-0">
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3, ease: EASE_PRIMARY }}
                className="overflow-hidden bg-ivory/60"
              >
                <div className="grid gap-5 px-6 py-6 md:grid-cols-2 xl:grid-cols-3">
                  {s.components.map((c, j) => (
                    <ComponentBar key={c.label} c={c} index={j} small />
                  ))}
                </div>
              </motion.div>
            </td>
          </tr>
        )}
      </AnimatePresence>
    </>
  )
}
