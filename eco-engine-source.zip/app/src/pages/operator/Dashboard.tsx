import { useMemo, useState } from 'react'
import { Link, useNavigate } from 'react-router'
import { motion } from 'framer-motion'
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { Clock, Plus } from 'lucide-react'
import StatusChip from '@/components/app/StatusChip'
import AILabel from '@/components/app/AILabel'
import KpiStat from '@/components/app/KpiStat'
import DqiGauge from '@/components/app/DqiGauge'
import HashChip from '@/components/app/HashChip'
import LedgerRule from '@/components/app/LedgerRule'
import DataTable, { DataTableCell, DataTableHead, DataTableRow } from '@/components/app/DataTable'
import { useAuditTrail, useDqi, useFacilities, useSubmissions } from '@/lib/store'
import FacilitySwitcher from './components/FacilitySwitcher'
import { CHART_META, DEADLINE_BANDS, STREAM_STATUS, daysUntil, formatTs } from './components/data'

const EASE = [0.22, 1, 0.36, 1] as [number, number, number, number]

/* --------------------------------------------------- chart tooltip (§6.17) */

function ChartTooltip({
  active,
  payload,
  meta,
}: {
  active?: boolean
  payload?: Array<{ payload: { month: string; tco2e: number; pending: boolean; anomaly: boolean } }>
  meta: (typeof CHART_META)[string]
}) {
  if (!active || !payload || payload.length === 0) return null
  const d = payload[0].payload
  return (
    <div className="rounded-[2px] border border-ivory/15 bg-ink px-3 py-2 shadow-panel">
      <p className="font-mono text-[11px] tracking-[0.02em] text-ivory">
        {d.month} · {d.tco2e.toLocaleString('en-US')} tCO₂e
      </p>
      <p className="mt-0.5 font-mono text-[10px] tracking-[0.02em] text-ivory/60">
        {d.pending ? 'AI estimate — pending human verification' : d.anomaly ? meta.anomalyTooltip : 'verified'}
      </p>
    </div>
  )
}

/* ------------------------------------------ bar shape with anomaly diamond */

function StreamBar(props: {
  x?: number
  y?: number
  width?: number
  height?: number
  fill?: string
  payload?: { anomaly?: boolean }
}) {
  const { x = 0, y = 0, width = 0, height = 0, fill = '#0F4C5C', payload } = props
  const cx = x + width / 2
  return (
    <g>
      <rect x={x} y={y} width={width} height={height} fill={fill} />
      {payload?.anomaly && (
        <rect
          x={cx - 4}
          y={y - 15}
          width={8}
          height={8}
          fill="#A63D2F"
          transform={`rotate(45 ${cx} ${y - 11})`}
        />
      )}
    </g>
  )
}

/* ------------------------------------------------------------------- page */

export default function Dashboard() {
  const facilities = useFacilities()
  const submissions = useSubmissions()
  const dqiScores = useDqi()
  const audit = useAuditTrail()
  const navigate = useNavigate()
  const [facilityId, setFacilityId] = useState(facilities[0].id)

  const facility = facilities.find((f) => f.id === facilityId) ?? facilities[0]
  const meta = CHART_META[facility.id]
  const band = DEADLINE_BANDS[facility.id]
  const streamStatus = STREAM_STATUS[facility.id]
  const dqi = dqiScores.find((d) => d.facilityId === facility.id) ?? dqiScores[0]

  /* KPI 2 — AI-estimated, pending human verification (this facility's queue) */
  const queue = useMemo(
    () =>
      submissions.filter(
        (s) => s.facilityId === facility.id && (s.status === 'Pending' || s.status === 'Queried'),
      ),
    [submissions, facility.id],
  )
  const pendingTco2e = useMemo(
    () =>
      queue.reduce((sum, s) => {
        const n = Number(s.aiEstimate.replace(/[^0-9.]/g, ''))
        return sum + (Number.isFinite(n) ? n : 0)
      }, 0),
    [queue],
  )

  /* chart series (§4): petrol verified, copper pending, alert anomaly marker */
  const chartData = useMemo(
    () =>
      facility.history.map((p) => ({
        month: p.month.replace(' 20', ' ’'),
        fullMonth: p.month,
        tco2e: meta.overrides[p.month] ?? Math.round(p.value * meta.perUnit),
        pending: p.month === meta.pendingMonth,
        anomaly: p.month === meta.anomalyMonth,
      })),
    [facility, meta],
  )

  /* verification queue preview: own most-recent pending + queried items */
  const queuePreview = useMemo(() => {
    const open = submissions.filter((s) => s.status === 'Pending' || s.status === 'Queried')
    const ownPending = open
      .filter((s) => s.facilityId === facility.id && s.status === 'Pending')
      .sort((a, b) => b.submittedAt.localeCompare(a.submittedAt))
    const queried = open.filter((s) => s.status === 'Queried')
    return [...ownPending, ...queried].slice(0, 2)
  }, [submissions, facility.id])

  /* recent activity — audit chain, newest first (§6) */
  const feed = useMemo(() => [...audit].reverse().slice(0, 6), [audit])

  const nodeTone = (action: string): string => {
    if (/ACCEPTED|APPROVED/.test(action)) return '#0F4C5C'
    if (/AI_ESTIMATE|UPLOAD|QUERIED|SUBMITTED/.test(action)) return '#B5651D'
    return '#1C2B28'
  }

  /* DQI sparkline: deterministic 12-point interpolation of the trend */
  const spark = useMemo(() => {
    const pts: string[] = []
    for (let i = 0; i < 12; i++) {
      const t = i / 11
      const wobble = Math.sin(i * 1.7) * 0.9
      const v = dqi.trend.from + (dqi.trend.to - dqi.trend.from) * t + wobble
      pts.push(`${(i / 11) * 100},${34 - ((v - 60) / 40) * 30}`)
    }
    return pts.join(' ')
  }, [dqi])

  return (
    <div className="flex flex-col gap-10">
      {/* ------------------------------------------------ Section 1 — header */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: EASE }}
        className="flex flex-wrap items-end justify-between gap-4"
      >
        <div>
          <h1 className="font-display text-[40px] leading-[1.05] text-ink">
            Good morning, Engr. Wokoma.
          </h1>
          <p className="mt-3 flex flex-wrap items-center gap-2 font-sans text-[13px] text-muted">
            <span>
              Wednesday, 15 July 2026 · {facility.name} · {facility.lga.replace(' LGA', '')},{' '}
              {facility.state} · Facility status:
            </span>
            <motion.span
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.4, ease: EASE }}
            >
              <StatusChip status="Approved" />
            </motion.span>
          </p>
        </div>
        <div className="flex items-center gap-3">
          <FacilitySwitcher value={facilityId} onChange={setFacilityId} />
          <button
            type="button"
            onClick={() => navigate('/operator/uploads?new=1')}
            className="flex items-center gap-2 rounded-[2px] bg-petrol px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ivory transition-all duration-200 hover:-translate-y-px hover:bg-petrol-deep"
          >
            <Plus className="h-3.5 w-3.5" strokeWidth={2} />
            New upload
          </button>
        </div>
      </motion.div>

      {/* ------------------------------------------ Section 2 — deadline band */}
      <motion.div
        initial={{ opacity: 0, y: -24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.15, ease: EASE }}
        className="flex flex-wrap items-center gap-x-8 gap-y-3 rounded-[2px] border border-line border-l-4 border-l-copper bg-ivory px-6 py-4"
      >
        <div>
          <p className="kicker text-copper">Reporting deadline</p>
          <p className="mt-1 font-sans text-[15px] text-ink">
            June 2026 activity data is <span className="font-semibold">due today</span>, 23:59 WAT.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-x-6 gap-y-2">
          {band.dots.map((d) => (
            <span key={d.stream} className="flex items-center gap-2 font-sans text-[13px] text-ink">
              {d.tone === 'alert' ? (
                <motion.span
                  className="h-2 w-2 rounded-full bg-alert"
                  animate={{ opacity: [1, 0.4, 1] }}
                  transition={{ duration: 1.6, repeat: Infinity, ease: 'easeInOut' }}
                />
              ) : (
                <span className={d.tone === 'copper' ? 'h-2 w-2 rounded-full bg-copper' : 'h-2 w-2 rounded-full bg-petrol'} />
              )}
              <span className="font-medium">{d.stream}</span>
              <span className={d.tone === 'alert' ? 'font-sans text-[12px] text-alert' : 'font-sans text-[12px] text-muted'}>
                — {d.text}
              </span>
            </span>
          ))}
        </div>
        <button
          type="button"
          onClick={() => navigate('/operator/uploads?new=1')}
          className="ml-auto rounded-[2px] border border-ink/30 px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ink transition-all duration-200 hover:-translate-y-px hover:border-ink hover:bg-sand"
        >
          {band.cta}
        </button>
      </motion.div>

      {/* ------------------------------------------------- Section 3 — KPIs */}
      <div key={facility.id} className="grid grid-cols-2 gap-x-8 gap-y-8 lg:grid-cols-4">
        <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0, ease: EASE }}>
          <KpiStat
            label="Verified YTD (Jul 2025–Jun 2026)"
            value={facility.verifiedYtd}
            suffix=" tCO₂e"
            delta="2.1% vs prior 12 months"
            deltaDirection="up"
          />
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.08, ease: EASE }}>
          <KpiStat
            label="Pending human verification"
            value={pendingTco2e}
            suffix=" tCO₂e"
            sub={`${queue.length} submissions in the queue`}
          />
          <div className="mt-2">
            <AILabel />
          </div>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.16, ease: EASE }} className="flex items-end gap-4">
          <KpiStat label="Facility DQI" value={dqi.dqi} delta="4 points since January" deltaDirection="up" />
          <DqiGauge value={dqi.dqi} size={60} className="mb-1 shrink-0" />
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.24, ease: EASE }}>
          <KpiStat
            label={`Data streams — plan ${facility.plan.version}`}
            value={facility.streams.length}
            sub="All meters in calibration"
          />
        </motion.div>
      </div>

      {/* ----------------------------- Section 4 — emissions chart + right rail */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-15%' }}
          transition={{ duration: 0.6, ease: EASE }}
          className="rounded-[2px] border border-line/70 bg-ivory p-6 lg:col-span-2"
        >
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="kicker text-muted">Verified emissions — 12 months</p>
            <div className="flex flex-wrap items-center gap-4">
              <span className="flex items-center gap-1.5 font-sans text-[11px] text-muted">
                <span className="h-[6px] w-[6px] bg-petrol" /> Verified
              </span>
              <span className="flex items-center gap-1.5 font-sans text-[11px] text-muted">
                <span className="h-[6px] w-[6px] bg-copper" /> AI estimate — pending
              </span>
              <span className="flex items-center gap-1.5 font-sans text-[11px] text-muted">
                <span className="inline-block h-[6px] w-[6px] rotate-45 bg-alert" /> Anomaly flagged
              </span>
            </div>
          </div>
          <LedgerRule className="mt-3" />
          <div className="mt-6 h-[280px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 20, right: 4, bottom: 0, left: -12 }} barCategoryGap="28%">
                <CartesianGrid vertical={false} stroke="#C9BBA2" strokeOpacity={0.3} />
                <XAxis
                  dataKey="month"
                  tickLine={false}
                  axisLine={{ stroke: '#C9BBA2', strokeOpacity: 0.6 }}
                  tick={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, fill: '#5F7168' }}
                  interval={0}
                />
                <YAxis
                  tickLine={false}
                  axisLine={false}
                  tick={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, fill: '#5F7168' }}
                  tickFormatter={(v: number) => (v >= 1000 ? `${Math.round(v / 1000)}k` : String(v))}
                />
                <Tooltip cursor={{ fill: 'rgba(15,76,92,0.06)' }} content={<ChartTooltip meta={meta} />} />
                <Bar dataKey="tco2e" shape={<StreamBar />} isAnimationActive animationDuration={800} animationEasing="ease-out">
                  {chartData.map((d) => (
                    <Cell key={d.month} fill={d.pending ? '#B5651D' : '#0F4C5C'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <p className="mt-4 data-s text-muted">
            Pending figures are AI estimates and do not enter the official record until accepted by an
            accredited verifier.
          </p>
        </motion.div>

        {/* right rail */}
        <motion.div
          initial={{ opacity: 0, x: 24 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: '-15%' }}
          transition={{ duration: 0.6, ease: EASE }}
          className="flex flex-col gap-6"
        >
          <div className="rounded-[2px] border border-line/70 bg-ivory p-6">
            <p className="kicker text-muted">Data quality index</p>
            <LedgerRule className="mt-3" />
            <div className="mt-4 flex items-center justify-between gap-4">
              <DqiGauge value={dqi.dqi} size={120} />
              <div className="flex-1">
                <p className="font-display text-[28px] leading-none text-ink">{dqi.dqi} — DQI</p>
                <svg viewBox="0 0 100 36" className="mt-3 h-9 w-full" preserveAspectRatio="none" aria-hidden="true">
                  <polyline points={spark} fill="none" stroke="#0F4C5C" strokeWidth="1.5" />
                </svg>
                <Link
                  to="/operator/dqi"
                  className="link-sweep mt-2 inline-block font-sans text-[13px] font-medium text-petrol"
                >
                  Open DQI detail →
                </Link>
              </div>
            </div>
          </div>

          <div className="rounded-[2px] border border-line/70 bg-ivory p-6">
            <p className="kicker text-muted">Awaiting verifier</p>
            <LedgerRule className="mt-3" />
            <div className="mt-4 flex flex-col gap-4">
              {queuePreview.map((s) => (
                <div key={s.id} className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-mono text-[12px] text-ink">{s.id}</p>
                    <p className="mt-0.5 font-sans text-[13px] text-muted">
                      {s.streamLabel} · {s.aiEstimate}
                      {s.flag ? ` — ${s.flag}` : ' — no flags'}
                      {s.status === 'Queried' ? ' — belt-scale logs requested' : ''}
                    </p>
                  </div>
                  <StatusChip status={s.status} className="shrink-0" />
                </div>
              ))}
              <Link
                to="/operator/uploads"
                className="link-sweep inline-block font-sans text-[13px] font-medium text-petrol"
              >
                View uploads →
              </Link>
            </div>
          </div>
        </motion.div>
      </div>

      {/* ----------------------------------- Section 5 — stream status table */}
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-10%' }}
        transition={{ duration: 0.6, ease: EASE }}
      >
        <p className="kicker text-muted">
          Data streams — monitoring plan {facility.plan.version} (approved {facility.plan.approvedOn})
        </p>
        <LedgerRule className="mt-3" />
        <DataTable className="mt-2">
          <DataTableHead
            columns={['Stream', 'Method', 'Meter / source', 'Calibration due', 'Tier', 'Last report', 'Status']}
          />
          <tbody>
            {facility.streams.map((s, i) => {
              const st = streamStatus[i]
              const days = s.calibrationDue ? daysUntil(s.calibrationDue) : null
              return (
                <DataTableRow
                  key={s.id}
                  onClick={() => navigate(`/operator/uploads?stream=${s.id}`)}
                >
                  <DataTableCell mono={false} className="font-medium">
                    {s.label} <span className="font-mono text-[11px] text-muted">({s.unit})</span>
                  </DataTableCell>
                  <DataTableCell mono={false} className="capitalize">
                    {s.method.startsWith('estimated') ? 'Estimated' : 'Metered'}
                  </DataTableCell>
                  <DataTableCell>{s.meter}</DataTableCell>
                  <DataTableCell>
                    {s.calibrationDue ? (
                      <span className="flex items-center gap-1.5">
                        {days !== null && days < 90 && (
                          <Clock className="h-3.5 w-3.5 text-copper" strokeWidth={1.75} />
                        )}
                        {s.calibrationDue}
                        {days !== null && days < 90 && (
                          <span className="font-mono text-[10px] text-copper">{days}d</span>
                        )}
                      </span>
                    ) : (
                      '—'
                    )}
                  </DataTableCell>
                  <DataTableCell>{s.tier}</DataTableCell>
                  <DataTableCell>{st?.lastReport ?? '—'}</DataTableCell>
                  <DataTableCell mono={false}>
                    <StatusChip status={st?.status ?? 'Record'} />
                  </DataTableCell>
                </DataTableRow>
              )
            })}
          </tbody>
        </DataTable>
      </motion.div>

      {/* --------------------------------------- Section 6 — recent activity */}
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true, margin: '-10%' }}
        transition={{ duration: 0.6, ease: EASE }}
        className="pb-4"
      >
        <p className="kicker text-muted">Recent activity — from the audit chain</p>
        <LedgerRule className="mt-3" />
        <div className="mt-6 flex flex-col">
          {feed.map((e, i) => (
            <motion.div
              key={e.seq}
              initial={{ opacity: 0, x: -16 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.08, ease: EASE }}
              className="relative flex gap-4 pb-6 pl-6 last:pb-0"
            >
              {/* vertical hairline + node */}
              <span className="absolute left-[3.5px] top-3 h-full w-px bg-line/60 last:hidden" aria-hidden="true" />
              <motion.span
                initial={{ scale: 0 }}
                whileInView={{ scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.3, delay: i * 0.08 + 0.1, ease: EASE }}
                className="absolute left-0 top-1.5 h-2 w-2"
                style={{ backgroundColor: nodeTone(e.action) }}
                aria-hidden="true"
              />
              <div className="flex min-w-0 flex-1 flex-wrap items-baseline gap-x-4 gap-y-1">
                <p className="font-sans text-[13px] text-ink">
                  <span className="font-medium">{e.detail}</span>
                  <span className="ml-2 font-sans text-[12px] text-muted">— {e.actor}</span>
                </p>
                <span className="data-s text-muted">{formatTs(e.ts)}</span>
                <HashChip hash={e.hash} />
              </div>
            </motion.div>
          ))}
        </div>
        <Link to="/audit" className="link-sweep mt-4 inline-block font-sans text-[13px] font-medium text-petrol">
          Open full audit trail →
        </Link>
      </motion.div>
    </div>
  )
}
