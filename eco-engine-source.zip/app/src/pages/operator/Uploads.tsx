/**
 * Page 05 — One Upload Reporting (/operator/uploads), uploads.md.
 * Submissions ledger with automated-validation + verification status, the 4-step
 * new-upload wizard, and the queried-submission response flow.
 */
import { useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { toast } from 'sonner'
import { ChevronDown, FileText, MessageSquareReply, Plus } from 'lucide-react'
import { cn } from '@/lib/utils'
import { FACILITIES, type Facility } from '@/lib/demo-data'
import {
  appendAudit,
  truncateHash,
  useAuditTrail,
  useRole,
  useSubmissions,
  type Submission,
} from '@/lib/store'
import AILabel from '@/components/app/AILabel'
import StatusChip from '@/components/app/StatusChip'
import DataTable, { DataTableEmpty, DataTableHead } from '@/components/app/DataTable'
import UploadWizard from './components/reporting/UploadWizard'
import {
  AnomalyDiamond,
  Drawer,
  EASE_PRIMARY,
  PageHeader,
  PrimaryButton,
  SecondaryButton,
  streamLabelFor,
} from './components/reporting/shared'

/* --------------------------------------------- static historical rows */

/** Verified historical submissions shown for ledger depth (display-only records). */
interface HistoricalRow {
  id: string
  facilityId: string
  streamLabel: string
  streamDisplay: string
  period: string // full month name, e.g. 'May 2026'
  periodShort: string
  activityValue: string
  aiEstimate: string
  uncertainty: string
  evidenceCount: number
  verifiedBy: string
  verifiedAtLabel: string
}

const HISTORICAL: HistoricalRow[] = [
  {
    id: 'SUB-2606-019',
    facilityId: 'FAC-RIV-004',
    streamLabel: 'diesel',
    streamDisplay: 'Diesel — gensets',
    period: 'May 2026',
    periodShort: 'May 2026',
    activityValue: '17,940 L',
    aiEstimate: '48.3',
    uncertainty: '±12%',
    evidenceCount: 3,
    verifiedBy: 'Dr. F. Okafor',
    verifiedAtLabel: '09 Jun 2026',
  },
  {
    id: 'SUB-2603-112',
    facilityId: 'FAC-RIV-004',
    streamLabel: 'flaring',
    streamDisplay: 'Associated gas flared',
    period: 'February 2026',
    periodShort: 'Feb 2026',
    activityValue: '2.09 MMscf/d',
    aiEstimate: '3,843',
    uncertainty: '±8%',
    evidenceCount: 2,
    verifiedBy: 'Dr. F. Okafor',
    verifiedAtLabel: '11 Mar 2026',
  },
  {
    id: 'SUB-2606-101',
    facilityId: 'FAC-KOG-002',
    streamLabel: 'clinker',
    streamDisplay: 'Clinker production',
    period: 'January 2026',
    periodShort: 'Jan 2026',
    activityValue: '118,432.00 t',
    aiEstimate: '61,585',
    uncertainty: '±5%',
    evidenceCount: 2,
    verifiedBy: 'Dr. F. Okafor',
    verifiedAtLabel: '12 Feb 2026',
  },
  {
    id: 'SUB-2605-088',
    facilityId: 'FAC-KOG-002',
    streamLabel: 'petcoke',
    streamDisplay: 'Kiln fuel — petcoke',
    period: 'April 2026',
    periodShort: 'Apr 2026',
    activityValue: '9,412 t',
    aiEstimate: '27,860',
    uncertainty: '±7%',
    evidenceCount: 2,
    verifiedBy: 'Dr. F. Okafor',
    verifiedAtLabel: '14 May 2026',
  },
]

/** Display copy attached to known seed submissions (operator / verifier notes). */
const ENRICHMENT: Record<string, { operatorNote?: string; verifierNote?: string; evidenceCount: number }> = {
  'SUB-2606-114': {
    operatorNote:
      'Turnaround: planned shutdown of GE-02/03; gas routed to flare 12–26 Mar. Turnaround report attached.',
    verifierNote: 'Evidence reviewed — accepted with note.',
    evidenceCount: 4,
  },
  'SUB-2607-003': { evidenceCount: 2 },
  'SUB-2606-118': { evidenceCount: 2 },
  'SUB-2607-007': { evidenceCount: 2 },
}

const MONTH_SHORT: Record<string, string> = {
  January: 'Jan', February: 'Feb', March: 'Mar', April: 'Apr', May: 'May', June: 'Jun',
  July: 'Jul', August: 'Aug', September: 'Sep', October: 'Oct', November: 'Nov', December: 'Dec',
}

function periodToShort(period: string): string {
  const [m, y] = period.split(' ')
  return `${MONTH_SHORT[m] ?? m} ${y}`
}

function isoToLabel(iso: string | null): string {
  if (!iso) return ''
  const [d, t] = iso.split('T')
  const [y, m, day] = d.split('-').map(Number)
  void t
  const names = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
  return `${String(day).padStart(2, '0')} ${names[m - 1]} ${y}`
}

/** Synthesised evidence file names per stream (demonstrator). */
function evidenceFiles(streamLabel: string, periodShort: string, count: number): string[] {
  const p = periodShort.replace(' ', '_')
  const byStream: Record<string, string[]> = {
    flaring: [`FL-201_meter_export_${p}.csv`, `flare_log_${p}.pdf`, `turnaround_report_GE-02-03.pdf`, `scada_daily_totals_${p}.csv`],
    'fuel gas': [`FG-104_meter_export_${p}.csv`, `scada_daily_totals_${p}.pdf`],
    diesel: [`delivery_notes_${p}.pdf`, `genset_run_log_${p}.xlsx`, `DG-01-02_fuel_cards_${p}.csv`],
    clinker: [`BS-22_belt_scale_export_${p}.csv`, `production_log_${p}.pdf`],
    petcoke: [`WF-07_weighfeeder_export_${p}.csv`, `delivery_notes_${p}.pdf`],
    'natural gas': [`KG-03_meter_export_${p}.csv`, `scada_daily_totals_${p}.pdf`],
  }
  return (byStream[streamLabel] ?? [`evidence_${p}.pdf`]).slice(0, count)
}

/* -------------------------------------------------------- row view model */

interface Row {
  id: string
  streamLabel: string
  streamDisplay: string
  period: string
  periodShort: string
  activityValue: string
  aiEstimate: string
  uncertainty: string
  flag: string | null
  status: 'Pending' | 'Queried' | 'Accepted' | 'Rejected'
  verifiedBy: string | null
  verifiedAtLabel: string | null
  verificationComment: string | null
  validation: { check: string; result: 'pass' | 'warn' | 'fail'; detail: string }[]
  evidenceCount: number
  operatorNote: string | null
  live: boolean
}

const CHECK_LABELS: Record<string, string> = {
  schema: 'Schema',
  units: 'Units',
  completeness: 'Completeness',
  range: 'Out-of-range',
  duplicates: 'Duplicates',
}

function toRow(s: Submission): Row {
  const enr = ENRICHMENT[s.id]
  const facility = FACILITIES.find((f) => f.id === s.facilityId)
  const streamDisplay =
    facility?.streams.find((st) => streamLabelFor(facility.id, st.id) === s.streamLabel)?.label ??
    s.streamLabel
  return {
    id: s.id,
    streamLabel: s.streamLabel,
    streamDisplay,
    period: s.period,
    periodShort: periodToShort(s.period),
    activityValue: s.activityValue,
    aiEstimate: s.aiEstimate.replace(' tCO2e', ''),
    uncertainty: s.uncertainty,
    flag: s.flag,
    status: s.status,
    verifiedBy: s.verifiedBy,
    verifiedAtLabel: isoToLabel(s.verifiedAt),
    verificationComment: s.verificationComment,
    validation: s.validation,
    evidenceCount: enr?.evidenceCount ?? 2,
    operatorNote: enr?.operatorNote ?? null,
    live: true,
  }
}

function toHistoricalRow(h: HistoricalRow): Row {
  return {
    id: h.id,
    streamLabel: h.streamLabel,
    streamDisplay: h.streamDisplay,
    period: h.period,
    periodShort: h.periodShort,
    activityValue: h.activityValue,
    aiEstimate: h.aiEstimate,
    uncertainty: h.uncertainty,
    flag: null,
    status: 'Accepted',
    verifiedBy: h.verifiedBy,
    verifiedAtLabel: h.verifiedAtLabel,
    verificationComment: null,
    validation: [
      { check: 'schema', result: 'pass', detail: 'All required fields present' },
      { check: 'units', result: 'pass', detail: 'Unit matches monitoring plan stream' },
      { check: 'range', result: 'pass', detail: 'Within expected band' },
      { check: 'duplicates', result: 'pass', detail: 'No duplicate period' },
    ],
    evidenceCount: h.evidenceCount,
    operatorNote: null,
    live: false,
  }
}

const STATUS_FILTERS = ['All', 'Pending', 'Verified', 'Queried', 'Rejected'] as const
type StatusFilter = (typeof STATUS_FILTERS)[number]

function statusCategory(r: Row): StatusFilter {
  if (r.status === 'Accepted') return 'Verified'
  if (r.status === 'Queried') return 'Queried'
  if (r.status === 'Rejected') return 'Rejected'
  return 'Pending'
}

/* ============================================================== page */

export default function Uploads() {
  const { persona } = useRole()
  const submissions = useSubmissions()
  const audit = useAuditTrail()

  const [facilityId, setFacilityId] = useState(FACILITIES[0].id)
  const facility: Facility = FACILITIES.find((f) => f.id === facilityId) ?? FACILITIES[0]

  const [wizardOpen, setWizardOpen] = useState(false)
  const [periodFilter, setPeriodFilter] = useState('All')
  const [streamFilter, setStreamFilter] = useState('All')
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('All')
  const [expanded, setExpanded] = useState<string | null>(null)
  const [responded, setResponded] = useState<Record<string, string>>({})
  const [respondTarget, setRespondTarget] = useState<Row | null>(null)
  const [reply, setReply] = useState('')

  const rows: Row[] = useMemo(() => {
    const live = submissions.filter((s) => s.facilityId === facility.id).map(toRow)
    const hist = HISTORICAL.filter((h) => h.facilityId === facility.id).map(toHistoricalRow)
    return [...live, ...hist]
  }, [submissions, facility.id])

  const filtered = rows.filter((r) => {
    if (periodFilter !== 'All' && r.periodShort !== periodFilter) return false
    if (streamFilter !== 'All' && r.streamLabel !== streamFilter) return false
    if (statusFilter !== 'All' && statusCategory(r) !== statusFilter) return false
    return true
  })

  const queried = rows.filter((r) => r.status === 'Queried' && !responded[r.id])

  const findDuplicate = (streamLabel: string, period: string): string | null => {
    const hit = rows.find((r) => r.streamLabel === streamLabel && r.period === period)
    return hit ? hit.id : null
  }

  const streamOptions = useMemo(() => {
    const set = new Map<string, string>()
    rows.forEach((r) => set.set(r.streamLabel, r.streamDisplay))
    return [...set.entries()]
  }, [rows])

  const periodOptions = useMemo(() => [...new Set(rows.map((r) => r.periodShort))], [rows])

  const sendResponse = () => {
    if (!respondTarget || !reply.trim()) return
    appendAudit({
      actor: persona.name,
      role: 'operator',
      action: 'QUERY_RESPONSE_SUBMITTED',
      entity: respondTarget.id,
      detail: `Response to verifier query — ${reply.trim().slice(0, 120)}`,
    })
    setResponded((prev) => ({ ...prev, [respondTarget.id]: reply.trim() }))
    setRespondTarget(null)
    setReply('')
    toast('Response sent — submission returned to the verification queue.')
  }

  if (wizardOpen) {
    return (
      <UploadWizard
        facility={facility}
        findDuplicate={findDuplicate}
        onClose={() => setWizardOpen(false)}
      />
    )
  }

  return (
    <div>
      <PageHeader
        crumb="Operator / Uploads"
        title="Uploads."
        sub="One upload per stream per period. Automated checks run before the verifier ever sees it."
        actions={
          <PrimaryButton onClick={() => setWizardOpen(true)}>
            <Plus className="h-4 w-4" strokeWidth={2} /> New upload
          </PrimaryButton>
        }
      />

      {/* ------------------------------------------- filter bar (§1) */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.4, delay: 0.1 }}
        className="mb-6 flex flex-wrap items-center gap-3 border-b border-line/60 pb-4"
      >
        {/* facility context (mirrors shell switcher — local to this page) */}
        <div className="flex items-center rounded-[2px] border border-line/60">
          {FACILITIES.map((f) => (
            <button
              key={f.id}
              type="button"
              onClick={() => {
                setFacilityId(f.id)
                setExpanded(null)
              }}
              className={cn(
                'px-3 py-2 font-mono text-[11px] tracking-[0.02em] transition-colors',
                facilityId === f.id ? 'bg-petrol text-ivory' : 'text-muted hover:text-ink',
              )}
            >
              {f.id}
            </button>
          ))}
        </div>

        <select
          value={periodFilter}
          onChange={(e) => setPeriodFilter(e.target.value)}
          className="rounded-[2px] border border-line/60 bg-ivory px-3 py-2 font-mono text-[12px] text-ink focus:border-copper focus:outline-none"
          aria-label="Filter by period"
        >
          <option value="All">All periods</option>
          {periodOptions.map((p) => (
            <option key={p}>{p}</option>
          ))}
        </select>

        <select
          value={streamFilter}
          onChange={(e) => setStreamFilter(e.target.value)}
          className="rounded-[2px] border border-line/60 bg-ivory px-3 py-2 font-sans text-[12px] text-ink focus:border-copper focus:outline-none"
          aria-label="Filter by stream"
        >
          <option value="All">All streams</option>
          {streamOptions.map(([label, display]) => (
            <option key={label} value={label}>
              {display}
            </option>
          ))}
        </select>

        <div className="flex items-center gap-1">
          {STATUS_FILTERS.map((s, i) => (
            <motion.button
              key={s}
              type="button"
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.15 + i * 0.04, ease: EASE_PRIMARY }}
              onClick={() => setStatusFilter(s)}
              className={cn(
                'rounded-[2px] px-[10px] py-[6px] font-sans text-[10px] font-semibold uppercase tracking-chip transition-colors',
                statusFilter === s
                  ? 'bg-petrol text-ivory'
                  : 'border border-line/60 text-muted hover:border-ink hover:text-ink',
              )}
            >
              {s}
            </motion.button>
          ))}
        </div>
      </motion.div>

      {/* -------------------------------- queried submissions callout (§4) */}
      <AnimatePresence>
        {queried.length > 0 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.4, ease: EASE_PRIMARY }}
            className="overflow-hidden"
          >
            <div className="mb-6 flex flex-wrap items-center justify-between gap-3 rounded-[2px] border border-copper bg-copper/5 px-5 py-4">
              <p className="font-sans text-[14px] text-ink">
                The verifier has asked a question on{' '}
                <span className="font-semibold">
                  {queried.length} submission{queried.length === 1 ? '' : 's'}
                </span>
                .{' '}
                <span className="font-mono text-[12px] text-muted">
                  {queried.map((q) => q.id).join(' · ')}
                </span>
              </p>
              <SecondaryButton onClick={() => setRespondTarget(queried[0])}>
                <MessageSquareReply className="h-4 w-4" strokeWidth={1.75} /> Respond
              </SecondaryButton>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ------------------------------------------- submissions table (§2) */}
      <DataTable>
        <DataTableHead
          columns={[
            'Submission',
            'Period',
            'Stream',
            'Activity value',
            'Validation',
            'AI estimate (tCO₂e)',
            'Status',
            'Evidence',
            '',
          ]}
        />
        <tbody>
          {filtered.length === 0 && (
            <DataTableEmpty
              colSpan={9}
              guidance="No submissions match the current filters. Widen the filters, or put a new period on the record."
              action={
                <PrimaryButton onClick={() => setWizardOpen(true)}>
                  <Plus className="h-4 w-4" strokeWidth={2} /> New upload
                </PrimaryButton>
              }
            />
          )}
          {filtered.map((r, i) => {
            const isOpen = expanded === r.id
            const hasWarn = r.validation.some((v) => v.result !== 'pass') || !!r.flag
            const isResponded = !!responded[r.id]
            return (
              <RowGroup
                key={r.id}
                row={r}
                index={i}
                isOpen={isOpen}
                hasWarn={hasWarn}
                isResponded={isResponded}
                onToggle={() => setExpanded(isOpen ? null : r.id)}
                audit={audit}
                onRespond={() => setRespondTarget(r)}
              />
            )
          })}
        </tbody>
      </DataTable>

      {/* ------------------------------------------------ respond drawer */}
      <Drawer
        open={!!respondTarget}
        onClose={() => setRespondTarget(null)}
        label="Respond to verifier query"
      >
        {respondTarget && (
          <div className="flex h-full flex-col">
            <div className="border-b border-line/60 px-8 py-6">
              <p className="kicker text-muted">Verifier query — {respondTarget.id}</p>
              <h2 className="mt-2 font-display text-[28px] leading-[1.1] text-ink">
                Respond to the verifier.
              </h2>
            </div>
            <div className="flex-1 overflow-y-auto px-8 py-6">
              <p className="kicker text-muted">Verifier's comment</p>
              <div className="mt-2 border-l-4 border-copper bg-sand/60 px-4 py-3">
                <p className="font-sans text-[14px] leading-[1.6] text-ink">
                  {respondTarget.verificationComment ??
                    'Please attach belt-scale raw logs BS-22 for 01–28 Feb.'}
                </p>
                <p className="mt-2 data-s text-muted">
                  Dr. F. Okafor · Accredited Verifier (ISO 14065) · Greenline Assurance Partners (demo)
                </p>
              </div>

              <p className="kicker mt-8 text-muted">Your reply</p>
              <textarea
                value={reply}
                onChange={(e) => setReply(e.target.value)}
                rows={5}
                placeholder="Answer the verifier's question. Your reply is read alongside the evidence and logged to the audit chain."
                className="mt-2 w-full resize-none rounded-[2px] border border-line bg-ivory px-3 py-2.5 font-sans text-[14px] leading-[1.6] text-ink placeholder:text-muted/50 focus:border-copper focus:outline-none"
              />

              <p className="kicker mt-6 text-muted">Attach new evidence (optional)</p>
              <label className="mt-2 flex cursor-pointer items-center gap-3 rounded-[2px] border border-dashed border-line px-4 py-4 transition-colors hover:border-copper">
                <FileText className="h-4 w-4 text-muted" strokeWidth={1.75} />
                <span className="font-sans text-[13px] text-muted">
                  Drop a file or browse — hashed on admission
                </span>
                <input
                  type="file"
                  className="hidden"
                  onChange={() => toast('Evidence attached and hashed.')}
                />
              </label>
            </div>
            <div className="flex items-center justify-between border-t border-line/60 px-8 py-5">
              <SecondaryButton onClick={() => setRespondTarget(null)}>Cancel</SecondaryButton>
              <PrimaryButton onClick={sendResponse} disabled={!reply.trim()}>
                Send response
              </PrimaryButton>
            </div>
          </div>
        )}
      </Drawer>
    </div>
  )
}

/* ----------------------------------------------------------- row group */

function RowGroup({
  row: r,
  index: i,
  isOpen,
  hasWarn,
  isResponded,
  onToggle,
  audit,
  onRespond,
}: {
  row: Row
  index: number
  isOpen: boolean
  hasWarn: boolean
  isResponded: boolean
  onToggle: () => void
  audit: ReturnType<typeof useAuditTrail>
  onRespond: () => void
}) {
  const verified = r.status === 'Accepted'
  const entries = audit.filter((e) => e.entity === r.id).slice(-3)

  return (
    <>
      <motion.tr
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: Math.min(i * 0.03, 0.3), ease: EASE_PRIMARY }}
        onClick={onToggle}
        className={cn(
          'group relative cursor-pointer border-b border-line/40 transition-colors duration-150 hover:bg-ivory',
          'before:absolute before:left-0 before:top-0 before:h-full before:w-[2px] before:bg-copper before:opacity-0 before:transition-opacity before:duration-150 hover:before:opacity-100',
        )}
      >
        <td className="min-h-[44px] py-3 pr-4 align-middle font-mono text-[13px] text-petrol">
          {r.id}
        </td>
        <td className="py-3 pr-4 align-middle font-mono text-[13px] text-ink">{r.periodShort}</td>
        <td className="py-3 pr-4 align-middle font-sans text-[13px] text-ink">{r.streamDisplay}</td>
        <td className={cn('py-3 pr-4 align-middle font-mono text-[13px]', r.flag ? 'font-medium text-alert' : 'text-ink')}>
          {r.activityValue}
        </td>
        <td className="py-3 pr-4 align-middle">
          {hasWarn ? (
            <span className="inline-flex items-center gap-2">
              <span className="font-sans text-[11px] font-semibold uppercase tracking-chip text-petrol">Pass</span>
              <span className="font-sans text-[11px] font-semibold uppercase tracking-chip text-alert">— 1 flag</span>
              <AnomalyDiamond />
            </span>
          ) : (
            <span className="font-sans text-[11px] font-semibold uppercase tracking-chip text-petrol">Pass</span>
          )}
        </td>
        <td className="py-3 pr-4 align-middle">
          {verified ? (
            <span className="block">
              <span className="font-mono text-[13px] text-ink">{r.aiEstimate}</span>
              <span className="mt-0.5 block font-mono text-[11px] tracking-[0.02em] text-petrol">
                — accepted {r.verifiedAtLabel} · {r.verifiedBy}
              </span>
            </span>
          ) : (
            <span className="block">
              <span className="font-mono text-[13px] text-ink">
                {r.aiEstimate} <span className="text-muted">{r.uncertainty}</span>
              </span>
              <AILabel className="mt-1" />
            </span>
          )}
        </td>
        <td className="py-3 pr-4 align-middle">
          {verified ? (
            <StatusChip
              status={r.id === 'SUB-2606-114' ? 'Verified — accepted with note' : 'Verified'}
              kind="verified"
            />
          ) : r.status === 'Rejected' ? (
            <StatusChip status="Rejected" kind="rejected" />
          ) : r.status === 'Queried' && !isResponded ? (
            <StatusChip status="Queried" kind="pending" />
          ) : isResponded ? (
            <StatusChip status="Pending — response sent" kind="pending" />
          ) : (
            <StatusChip status="Pending verification" kind="pending" />
          )}
        </td>
        <td className="py-3 pr-4 align-middle font-mono text-[13px] text-muted">
          {r.evidenceCount} files
        </td>
        <td className="py-3 align-middle">
          <ChevronDown
            className={cn('h-4 w-4 text-muted transition-transform duration-200', isOpen && 'rotate-180')}
            strokeWidth={1.75}
          />
        </td>
      </motion.tr>

      {/* expansion tray */}
      <AnimatePresence>
        {isOpen && (
          <tr>
            <td colSpan={9} className="border-b border-line/40 p-0">
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3, ease: EASE_PRIMARY }}
                className="overflow-hidden bg-ivory/60"
              >
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.25, delay: 0.1 }}
                  className="grid gap-8 px-6 py-6 md:grid-cols-3"
                >
                  {/* validation checks */}
                  <div>
                    <p className="kicker mb-3 text-muted">Automated validation</p>
                    <ul className="space-y-2">
                      {r.validation.map((v) => (
                        <li key={v.check} className="flex items-start gap-2">
                          <span
                            className={cn(
                              'mt-1 h-[6px] w-[6px] shrink-0',
                              v.result === 'pass' ? 'bg-petrol' : v.result === 'warn' ? 'bg-copper' : 'bg-alert',
                            )}
                          />
                          <span>
                            <span className="font-sans text-[12px] font-semibold uppercase tracking-chip text-ink">
                              {CHECK_LABELS[v.check] ?? v.check} {v.result === 'pass' ? '✓' : v.result === 'warn' ? '⚠' : '✗'}
                            </span>
                            <span className="block font-mono text-[11px] tracking-[0.02em] text-muted">
                              {v.detail}
                            </span>
                          </span>
                        </li>
                      ))}
                    </ul>
                    {r.flag && (
                      <p className="mt-4 inline-flex items-center gap-2 rounded-[2px] bg-alert px-[10px] py-[6px] font-sans text-[10px] font-semibold uppercase tracking-chip text-ivory">
                        Flag: {r.flag}
                        {r.flag.includes('intensity') ? ' vs 6-month mean' : ''}
                      </p>
                    )}
                  </div>

                  {/* evidence + notes */}
                  <div>
                    <p className="kicker mb-3 text-muted">Evidence</p>
                    <ul className="space-y-2">
                      {evidenceFiles(r.streamLabel, r.periodShort, r.evidenceCount).map((name) => (
                        <li key={name} className="flex items-center gap-2">
                          <FileText className="h-3.5 w-3.5 shrink-0 text-muted" strokeWidth={1.75} />
                          <span className="font-sans text-[12px] font-semibold text-ink">{name}</span>
                        </li>
                      ))}
                    </ul>
                    {r.operatorNote && (
                      <>
                        <p className="kicker mb-2 mt-5 text-muted">Operator note</p>
                        <p className="font-sans text-[13px] leading-[1.5] text-ink">{r.operatorNote}</p>
                      </>
                    )}
                    {r.status === 'Queried' && (
                      <>
                        <p className="kicker mb-2 mt-5 text-muted">Verifier query</p>
                        <p className="font-sans text-[13px] leading-[1.5] text-copper">
                          {r.verificationComment ?? 'Please attach belt-scale raw logs BS-22 for 01–28 Feb.'}
                        </p>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation()
                            onRespond()
                          }}
                          className="link-sweep mt-2 font-sans text-[13px] font-semibold text-petrol"
                        >
                          Respond to this query →
                        </button>
                      </>
                    )}
                    {verified && r.verifiedBy && (
                      <>
                        <p className="kicker mb-2 mt-5 text-muted">Verifier note</p>
                        <p className="font-sans text-[13px] leading-[1.5] text-petrol">
                          {ENRICHMENT[r.id]?.verifierNote ?? 'Evidence reviewed — accepted.'}
                        </p>
                      </>
                    )}
                  </div>

                  {/* mini audit strip */}
                  <div>
                    <p className="kicker mb-3 text-muted">Audit trail</p>
                    {entries.length === 0 ? (
                      <p className="font-mono text-[11px] text-muted">Entries predate the demo chain window.</p>
                    ) : (
                      <ul className="space-y-3">
                        {entries.map((e) => (
                          <li key={e.seq}>
                            <p className="font-sans text-[11px] font-semibold uppercase tracking-chip text-ink">
                              {e.action.replace(/_/g, ' ')}
                            </p>
                            <p className="font-mono text-[11px] tracking-[0.02em] text-muted">
                              {e.actor} · {truncateHash(e.hash)}
                            </p>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                </motion.div>
              </motion.div>
            </td>
          </tr>
        )}
      </AnimatePresence>
    </>
  )
}
