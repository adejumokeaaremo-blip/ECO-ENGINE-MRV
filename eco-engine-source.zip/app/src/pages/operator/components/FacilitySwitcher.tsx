import { ChevronDown } from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { FACILITIES } from '@/lib/demo-data'

/**
 * Page-local facility context switcher (operator pages). Mirrors the top-bar
 * switcher styling; swapping crossfades all page data (0.3s, handled by pages).
 */
export default function FacilitySwitcher({
  value,
  onChange,
  dark = false,
}: {
  value: string
  onChange: (facilityId: string) => void
  dark?: boolean
}) {
  const current = FACILITIES.find((f) => f.id === value) ?? FACILITIES[0]
  return (
    <DropdownMenu>
      <DropdownMenuTrigger
        className={
          dark
            ? 'flex items-center gap-2 rounded-[2px] border border-ivory/25 px-3 py-2 font-sans text-[12px] text-ivory transition-colors hover:border-ivory'
            : 'flex items-center gap-2 rounded-[2px] border border-line/60 bg-ivory px-3 py-2 font-sans text-[12px] text-ink transition-colors hover:border-ink'
        }
      >
        <span className={dark ? 'font-mono text-[11px] text-ivory/50' : 'font-mono text-[11px] text-muted'}>
          {current.id}
        </span>
        <span className="max-w-[200px] truncate">{current.name}</span>
        <ChevronDown className={dark ? 'h-3.5 w-3.5 text-ivory/60' : 'h-3.5 w-3.5 text-muted'} strokeWidth={1.75} />
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-[320px] rounded-[2px]">
        <DropdownMenuLabel className="kicker text-muted">Facility context</DropdownMenuLabel>
        {FACILITIES.map((f) => (
          <DropdownMenuItem
            key={f.id}
            onSelect={() => onChange(f.id)}
            className="flex flex-col items-start gap-0.5"
          >
            <span className="font-sans text-[13px] font-medium">{f.name}</span>
            <span className="data-s text-muted">
              {f.id} · {f.state}
            </span>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
