/**
 * Page-local constants for the operator pages — extends src/lib/demo-data.ts
 * (single source of truth) with per-page presentation records. All demo
 * entities are marked (demo) and stay consistent with design.md §8.
 */
import { DEMO_TODAY } from '@/lib/demo-data'
import { demoHash } from '@/lib/store'

/** Days from the demo "today" (15 Jul 2026) to a date like "15 Sep 2026". */
export function daysUntil(dateStr: string): number {
  const a = new Date(`${DEMO_TODAY}T00:00:00Z`).getTime()
  const b = new Date(dateStr).getTime()
  return Math.round((b - a) / 86400000)
}

/** Format an ISO audit timestamp as "15 Jul 2026 09:00". */
export function formatTs(iso: string): string {
  const d = new Date(iso)
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
  const hh = String(d.getUTCHours()).padStart(2, '0')
  const mm = String(d.getUTCMinutes()).padStart(2, '0')
  return `${String(d.getUTCDate()).padStart(2, '0')} ${months[d.getUTCMonth()]} ${d.getUTCFullYear()} ${hh}:${mm}`
}

/* ------------------------------------------------------- dashboard data */

export interface DeadlineDot {
  stream: string
  text: string
  tone: 'copper' | 'alert' | 'petrol'
}

export const DEADLINE_BANDS: Record<string, { dots: DeadlineDot[]; cta: string }> = {
  'FAC-RIV-004': {
    dots: [
      { stream: 'Flaring stream', text: 'Uploaded, pending verification', tone: 'copper' },
      { stream: 'Fuel gas', text: 'Uploaded, pending verification', tone: 'copper' },
      { stream: 'Diesel', text: 'Not yet uploaded', tone: 'alert' },
    ],
    cta: 'Upload diesel data →',
  },
  'FAC-KOG-002': {
    dots: [
      { stream: 'Clinker', text: 'Uploaded, pending verification', tone: 'copper' },
      { stream: 'Petcoke', text: 'Uploaded, pending verification', tone: 'copper' },
      { stream: 'Kiln gas', text: 'Not yet uploaded', tone: 'alert' },
    ],
    cta: 'Upload kiln gas data →',
  },
}

export interface StreamStatusRow {
  lastReport: string
  status: string
}

/** Last-report status per stream, keyed by facility id (dashboard §5). */
export const STREAM_STATUS: Record<string, StreamStatusRow[]> = {
  'FAC-RIV-004': [
    { lastReport: 'Jun 2026 — 1.42', status: 'Pending verification' },
    { lastReport: 'Jun 2026 — 1.41', status: 'Pending verification' },
    { lastReport: 'May 2026 — 17,940', status: 'Due today' },
  ],
  'FAC-KOG-002': [
    { lastReport: 'Jun 2026 — 117,715', status: 'Pending verification' },
    { lastReport: 'Jun 2026 — 9,588', status: 'Pending verification' },
    { lastReport: 'May 2026 — 41.2', status: 'Due today' },
  ],
}

export interface ChartMeta {
  /** multiply the primary-stream monthly value by this to get tCO₂e */
  perUnit: number
  anomalyMonth: string
  anomalyNote: string
  pendingMonth: string
  /** exact tCO₂e overrides (tie the chart to seeded submission figures) */
  overrides: Record<string, number>
  anomalyTooltip: string
}

export const CHART_META: Record<string, ChartMeta> = {
  'FAC-RIV-004': {
    perUnit: 60.3 * 30.4, // 60.3 t CO₂e/MMscf × ~30.4 days
    anomalyMonth: 'Mar 2026',
    anomalyNote: 'flag: intensity shift',
    pendingMonth: 'Jun 2026',
    overrides: { 'Mar 2026': 5614 },
    anomalyTooltip: 'verified 09 Apr 2026 by Dr. F. Okafor · flag: intensity shift',
  },
  'FAC-KOG-002': {
    perUnit: 0.52, // 0.52 t CO₂/t clinker
    anomalyMonth: 'Feb 2026',
    anomalyNote: 'flag: repeated identical values',
    pendingMonth: 'Jun 2026',
    overrides: { 'Feb 2026': 61585 },
    anomalyTooltip: 'queried 16 Mar 2026 by Dr. F. Okafor · flag: repeated identical values',
  },
}

/* ------------------------------------------------- facility profile data */

export interface UnitRow {
  unit: string
  type: string
  stream: string
}

export interface PermitRow {
  permit: string
  issuer: string
  number: string
  expiry: string
}

export interface ContactRow {
  label: string
  name: string
  phone: string
  email: string
}

export interface StatusHistoryEntry {
  label: string
  ts: string
  hash: string
  tone: 'petrol' | 'copper' | 'ink' | 'alert'
}

export interface ProfileExtra {
  legalName: string
  rc: string
  sectorDetail: string
  tin: string
  reportingContact: string
  boundaryNote: string
  unitRows: UnitRow[]
  permitRows: PermitRow[]
  contacts: ContactRow[]
  statusHistory: StatusHistoryEntry[]
  headerImage: string
  pinLabel: string
}

function h(seed: string): string {
  return demoHash(`facility-record|${seed}`)
}

export const PROFILE_EXTRA: Record<string, ProfileExtra> = {
  'FAC-RIV-004': {
    legalName: 'Delta Crest Energy Ltd (demo)',
    rc: 'RC 1772210 (demo)',
    sectorDetail: 'Oil & Gas — upstream production',
    tin: 'TIN-03884412 (demo)',
    reportingContact: 'Engr. T. Wokoma, Facility Environmental Manager',
    boundaryNote: 'Equity-share boundary over FS-4 process area; Scope 1 sources only',
    unitRows: [
      { unit: 'FL-01', type: 'Flaring stack — elevated flare', stream: 'Associated gas flared' },
      { unit: 'GE-01…03', type: 'Gas engine gensets — stationary combustion', stream: 'Fuel gas' },
      { unit: 'DG-01/02', type: 'Diesel standby gensets — stationary combustion', stream: 'Diesel' },
    ],
    permitRows: [
      { permit: 'NUPRC operating licence (demo)', issuer: 'NUPRC', number: 'OL/2024/118', expiry: '31 Dec 2027' },
      { permit: 'NMDPRA permit (demo)', issuer: 'NMDPRA', number: 'P/2025/0342', expiry: '28 Feb 2027' },
      { permit: 'NESREA effluent permit (demo)', issuer: 'NESREA', number: 'EA/RIV/2211', expiry: '30 Sep 2026' },
    ],
    contacts: [
      {
        label: 'Primary — reporting contact',
        name: 'Engr. T. Wokoma, Facility Environmental Manager',
        phone: '+234 803 555 0142 (demo)',
        email: 't.wokoma@deltacrest.ng (demo)',
      },
      {
        label: 'Secondary — control room',
        name: 'FS-4 Operations Control Room',
        phone: '+234 844 555 0117 (demo)',
        email: 'fs4.ops@deltacrest.ng (demo)',
      },
    ],
    statusHistory: [
      { label: 'Draft created', ts: '28 Jul 2025 09:41', hash: h('FAC-RIV-004|draft'), tone: 'copper' },
      { label: 'Submitted for approval', ts: '05 Aug 2025 14:12', hash: h('FAC-RIV-004|submitted'), tone: 'copper' },
      { label: 'Queried by regulator — permit evidence', ts: '08 Aug 2025 10:55', hash: h('FAC-RIV-004|queried'), tone: 'alert' },
      { label: 'Resubmitted with NESREA permit scan', ts: '11 Aug 2025 16:03', hash: h('FAC-RIV-004|resubmitted'), tone: 'copper' },
      { label: 'Approved — A. Bello (NCCC — MRV Directorate)', ts: '14 Aug 2025 10:22', hash: h('FAC-RIV-004|approved'), tone: 'petrol' },
    ],
    headerImage: '/flare-station.png',
    pinLabel: 'Rivers State',
  },
  'FAC-KOG-002': {
    legalName: 'Sahel Cement Company Ltd (demo)',
    rc: 'RC 1555033 (demo)',
    sectorDetail: 'Cement — clinker and cement manufacture',
    tin: 'TIN-05120977 (demo)',
    reportingContact: 'Engr. M. Adewale, Plant Environmental Manager (demo)',
    boundaryNote: 'Operational-control boundary over Line 2 kiln system; Scope 1 sources only',
    unitRows: [
      { unit: 'KL-2', type: 'Kiln line — 4,000 tpd', stream: 'Clinker production' },
      { unit: 'RM-2', type: 'Raw mill', stream: 'Kiln feed (internal)' },
      { unit: 'PM-2', type: 'Petcoke mill', stream: 'Kiln fuel — petcoke' },
    ],
    permitRows: [
      { permit: 'NESREA permit (demo)', issuer: 'NESREA', number: 'EA/KOG/0987', expiry: '19 Sep 2027' },
      { permit: 'Kogi State EIA approval (demo)', issuer: 'State EIA authority', number: 'EIA/KOG/2025/041', expiry: '—' },
    ],
    contacts: [
      {
        label: 'Primary — reporting contact',
        name: 'Engr. M. Adewale, Plant Environmental Manager (demo)',
        phone: '+234 806 555 0288 (demo)',
        email: 'm.adewale@sahelcement.ng (demo)',
      },
      {
        label: 'Secondary — line control room',
        name: 'Line 2 Central Control Room',
        phone: '+234 586 555 0130 (demo)',
        email: 'line2.ccr@sahelcement.ng (demo)',
      },
    ],
    statusHistory: [
      { label: 'Draft created', ts: '02 Sep 2025 11:08', hash: h('FAC-KOG-002|draft'), tone: 'copper' },
      { label: 'Submitted for approval', ts: '09 Sep 2025 09:37', hash: h('FAC-KOG-002|submitted'), tone: 'copper' },
      { label: 'Approved — A. Bello (NCCC — MRV Directorate)', ts: '19 Sep 2025 09:05', hash: h('FAC-KOG-002|approved'), tone: 'petrol' },
    ],
    headerImage: '/cement-plant.png',
    pinLabel: 'Kogi State',
  },
}

/* -------------------------------------------------- monitoring plan data */

export interface PlanStreamDetail {
  id: string
  name: string
  unit: string
  methodChip: string
  tier: string
  freq: string
  method: string
  meter: string
  calibrationDue: string | null
  tierNote: string
  qaqc: string
  frequencyNote: string
  ef: string
  efSource: string
}

export interface PlanVersionRow {
  version: string
  status: string
  note: string
  when: string
  hash: string
}

export interface PlanDetail {
  current: string
  approvedOn: string
  approvedBy: string
  supersedes: string | null
  hash: string
  streams: PlanStreamDetail[]
  history: PlanVersionRow[]
}

export const PLAN_DETAILS: Record<string, PlanDetail> = {
  'FAC-RIV-004': {
    current: 'v1.2',
    approvedOn: '02 Jun 2026',
    approvedBy: 'A. Bello (NCCC — MRV Directorate)',
    supersedes: 'v1.1',
    hash: h('FAC-RIV-004|plan|v1.2'),
    streams: [
      {
        id: 'S1',
        name: 'Associated gas flared',
        unit: 'MMscf/d',
        methodChip: 'Metered',
        tier: 'Tier 2',
        freq: 'Monthly',
        method: 'Continuous ultrasonic flare metering',
        meter: 'FL-201',
        calibrationDue: '15 Sep 2026',
        tierNote: 'Tier 2 — facility-specific meter uncertainty ±5%',
        qaqc:
          "Monthly meter proving vs reference orifice; flare-tip inspection log; data gap protocol: substitute with engineer's estimate flagged Tier 1",
        frequencyNote: 'Monthly, by the 15th',
        ef: '60.3 t CO₂e/MMscf — derived per GGFR + IPCC 2006 Vol. 2 Ch. 4 (illustrative)',
        efSource: 'Derived per GGFR guidance + IPCC 2006 Vol. 2 Ch. 4 — illustrative',
      },
      {
        id: 'S2',
        name: 'Fuel gas consumed',
        unit: 'MMscf/d',
        methodChip: 'Metered',
        tier: 'Tier 2',
        freq: 'Monthly',
        method: 'Continuous fuel-gas metering',
        meter: 'FG-104',
        calibrationDue: '02 Nov 2026',
        tierNote: 'Tier 2 — facility-specific meter uncertainty ±5%',
        qaqc: 'Quarterly meter verification; hourly data validation against genset run-hours',
        frequencyNote: 'Monthly, by the 15th',
        ef: '56,100 kg CO₂/TJ — IPCC 2006, Vol. 2, Ch. 2, Table 2.2 (default)',
        efSource: 'IPCC 2006, Vol. 2, Ch. 2, Table 2.2 (default)',
      },
      {
        id: 'S3',
        name: 'Diesel — gensets',
        unit: 'litres/month',
        methodChip: 'Estimated',
        tier: 'Tier 1',
        freq: 'Monthly',
        method: 'Estimated from delivery records (Tier 1)',
        meter: '—',
        calibrationDue: null,
        tierNote: 'Tier 1 — IPCC default uncertainty',
        qaqc: 'Delivery-note reconciliation; tank dip cross-check quarterly.',
        frequencyNote: 'Monthly, by the 15th',
        ef: '74,100 kg CO₂/TJ — IPCC 2006, Vol. 2, Ch. 2, Table 2.2 (default)',
        efSource: 'IPCC 2006, Vol. 2, Ch. 2, Table 2.2 (default)',
      },
    ],
    history: [
      {
        version: 'v1.2',
        status: 'Approved',
        note: 'Recalibration dates rolled forward; S3 QA/QC clarified after verifier query.',
        when: '02 Jun 2026 · A. Bello (NCCC)',
        hash: h('FAC-RIV-004|plan|v1.2'),
      },
      {
        version: 'v1.1',
        status: 'Superseded',
        note: 'Added diesel delivery-note reconciliation.',
        when: '14 Jan 2026 · Engr. T. Wokoma',
        hash: h('FAC-RIV-004|plan|v1.1'),
      },
      {
        version: 'v1.0',
        status: 'Superseded',
        note: 'Initial plan approved with facility onboarding.',
        when: '14 Aug 2025 · A. Bello (NCCC)',
        hash: h('FAC-RIV-004|plan|v1.0'),
      },
    ],
  },
  'FAC-KOG-002': {
    current: 'v1.0',
    approvedOn: '19 Sep 2025',
    approvedBy: 'A. Bello (NCCC — MRV Directorate)',
    supersedes: null,
    hash: h('FAC-KOG-002|plan|v1.0'),
    streams: [
      {
        id: 'S1',
        name: 'Clinker production',
        unit: 't/month',
        methodChip: 'Metered',
        tier: 'Tier 3',
        freq: 'Monthly',
        method: 'Continuous belt-scale weighing at kiln feed',
        meter: 'BS-22',
        calibrationDue: '30 Aug 2026',
        tierNote: 'Tier 3 — facility-specific activity data, calibrated belt scale ±2%',
        qaqc: 'Weekly belt-scale zero/span checks; monthly material balance vs raw-mill feed',
        frequencyNote: 'Monthly, by the 15th',
        ef: '0.52 t CO₂/t clinker (+2% CKD correction) — IPCC 2006, Vol. 3, Ch. 2, Eq. 2.4',
        efSource: 'IPCC 2006, Vol. 3, Ch. 2, Eq. 2.4',
      },
      {
        id: 'S2',
        name: 'Kiln fuel — petcoke',
        unit: 't/month',
        methodChip: 'Metered',
        tier: 'Tier 2',
        freq: 'Monthly',
        method: 'Continuous weighfeeder on petcoke mill',
        meter: 'WF-07',
        calibrationDue: '30 Aug 2026',
        tierNote: 'Tier 2 — facility-specific meter uncertainty ±5%',
        qaqc: 'Monthly weighfeeder calibration check; delivery tonnage reconciliation',
        frequencyNote: 'Monthly, by the 15th',
        ef: '97,500 kg CO₂/TJ — IPCC 2006, Vol. 2, Ch. 2, Table 2.2 (default)',
        efSource: 'IPCC 2006, Vol. 2, Ch. 2, Table 2.2 (default)',
      },
      {
        id: 'S3',
        name: 'Kiln fuel — natural gas',
        unit: 'MMscf/month',
        methodChip: 'Metered',
        tier: 'Tier 2',
        freq: 'Monthly',
        method: 'Continuous gas metering at kiln burner',
        meter: 'KG-03',
        calibrationDue: null,
        tierNote: 'Tier 2 — facility-specific meter uncertainty ±5%',
        qaqc: 'Quarterly meter verification; calorific value from supplier certificates',
        frequencyNote: 'Monthly, by the 15th',
        ef: '56,100 kg CO₂/TJ — IPCC 2006, Vol. 2, Ch. 2, Table 2.2 (default)',
        efSource: 'IPCC 2006, Vol. 2, Ch. 2, Table 2.2 (default)',
      },
    ],
    history: [
      {
        version: 'v1.0',
        status: 'Approved',
        note: 'Initial plan approved with facility onboarding.',
        when: '19 Sep 2025 · A. Bello (NCCC)',
        hash: h('FAC-KOG-002|plan|v1.0'),
      },
    ],
  },
}

/** "Compare with v1.1" — changed-fields view (monitoring plan, interactions). */
export const PLAN_DIFFS: Record<string, { field: string; before: string; after: string }[]> = {
  'FAC-RIV-004': [
    { field: 'S1 · Calibration due', before: '15 Sep 2025', after: '15 Sep 2026' },
    { field: 'S2 · Calibration due', before: '02 Nov 2025', after: '02 Nov 2026' },
    {
      field: 'S3 · QA/QC procedure',
      before: 'Delivery-note reconciliation.',
      after: 'Delivery-note reconciliation; tank dip cross-check quarterly.',
    },
  ],
  'FAC-KOG-002': [],
}

/* --------------------------------------------------------- wizard options */

export const NIGERIAN_STATES = [
  'Abia', 'Adamawa', 'Akwa Ibom', 'Anambra', 'Bauchi', 'Bayelsa', 'Benue', 'Borno',
  'Cross River', 'Delta', 'Ebonyi', 'Edo', 'Ekiti', 'Enugu', 'FCT — Abuja', 'Gombe',
  'Imo', 'Jigawa', 'Kaduna', 'Kano', 'Katsina', 'Kebbi', 'Kogi', 'Kwara', 'Lagos',
  'Nasarawa', 'Niger', 'Ogun', 'Ondo', 'Osun', 'Oyo', 'Plateau', 'Rivers', 'Sokoto',
  'Taraba', 'Yobe', 'Zamfara',
] as const

export const SECTOR_OPTIONS = ['Oil & Gas — upstream', 'Cement'] as const
export const ISSUER_OPTIONS = ['NUPRC', 'NMDPRA', 'NESREA', 'State EIA authority'] as const

export const UNIT_TEMPLATES = [
  { label: 'Use template: gas flaring stack', unit: 'FL-01', type: 'Flaring stack — elevated flare', stream: 'Associated gas flared' },
  { label: 'Use template: cement kiln line', unit: 'KL-2', type: 'Kiln line', stream: 'Clinker production' },
] as const
