import { useEffect, useRef, useState } from 'react'
import type { ChangeEvent, DragEvent } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { FileText, Plus, Trash2, UploadCloud, X } from 'lucide-react'
import { toast } from 'sonner'
import HashChip from '@/components/app/HashChip'
import StatusChip from '@/components/app/StatusChip'
import LedgerRule from '@/components/app/LedgerRule'
import { appendAudit, demoHash } from '@/lib/store'
import { ISSUER_OPTIONS, NIGERIAN_STATES, SECTOR_OPTIONS, UNIT_TEMPLATES } from './data'
import { cn } from '@/lib/utils'

const EASE = [0.22, 1, 0.36, 1] as [number, number, number, number]

const STEPS = [
  'Organisation',
  'Sector & boundaries',
  'Units & processes',
  'Permits',
  'Location & contacts',
  'Review & submit',
] as const

const SCOPE1_SOURCES = [
  'Stationary combustion',
  'Flaring',
  'Fugitive emissions',
  'Process emissions',
] as const

interface DraftUnit {
  unit: string
  type: string
  stream: string
}

interface DraftPermit {
  issuer: string
  number: string
  expiry: string
  fileName: string | null
  evidenceHash: string | null
}

interface WizardForm {
  legalName: string
  rc: string
  tin: string
  contactName: string
  sector: string
  boundary: 'equity' | 'operational'
  scopes: string[]
  units: DraftUnit[]
  permits: DraftPermit[]
  state: string
  lga: string
  lat: string
  lon: string
  phone: string
  email: string
}

const EMPTY_FORM: WizardForm = {
  legalName: '',
  rc: '',
  tin: '',
  contactName: '',
  sector: '',
  boundary: 'operational',
  scopes: ['Stationary combustion'],
  units: [{ unit: '', type: '', stream: '' }],
  permits: [{ issuer: 'NESREA', number: '', expiry: '', fileName: null, evidenceHash: null }],
  state: '',
  lga: '',
  lat: '',
  lon: '',
  phone: '',
  email: '',
}

/* ------------------------------------------------------------ form atoms */

function Field({
  label,
  helper,
  error,
  children,
}: {
  label: string
  helper?: string
  error?: string
  children: React.ReactNode
}) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="kicker text-muted">{label}</span>
      {children}
      {helper && !error && <span className="font-sans text-[13px] text-muted">{helper}</span>}
      {error && <span className="font-sans text-[12px] text-alert">{error}</span>}
    </label>
  )
}

const inputCls =
  'w-full rounded-[2px] border border-line bg-ivory px-3 py-2.5 font-sans text-[14px] text-ink placeholder:text-muted/60 focus:border-petrol focus:outline-none focus:ring-2 focus:ring-copper focus:ring-offset-2'

/* ---------------------------------------------------------------- wizard */

export default function OnboardingWizard({
  open,
  onClose,
}: {
  open: boolean
  onClose: () => void
}) {
  const [step, setStep] = useState(0)
  const [form, setForm] = useState<WizardForm>(EMPTY_FORM)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [invalidSteps, setInvalidSteps] = useState<Set<number>>(new Set())
  const [confirmExit, setConfirmExit] = useState(false)
  const [submittedHash, setSubmittedHash] = useState<string | null>(null)
  const fileInputs = useRef<Array<HTMLInputElement | null>>([])

  const set = <K extends keyof WizardForm>(key: K, value: WizardForm[K]) =>
    setForm((f) => ({ ...f, [key]: value }))

  /* Escape → save-as-draft confirmation (design §4 chrome) */
  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setConfirmExit(true)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open])

  useEffect(() => {
    if (open) {
      setStep(0)
      setErrors({})
      setInvalidSteps(new Set())
      setSubmittedHash(null)
    }
  }, [open])

  const validateStep = (s: number): Record<string, string> => {
    const errs: Record<string, string> = {}
    if (s === 0) {
      if (!form.legalName.trim()) errs.legalName = 'Legal name is required.'
      if (!form.rc.trim()) errs.rc = 'RC number is required.'
      if (!form.contactName.trim()) errs.contactName = 'A reporting contact is required.'
    }
    if (s === 1 && !form.sector) errs.sector = 'Select a sector.'
    if (s === 2 && form.units.some((u) => !u.unit.trim() || !u.stream.trim()))
      errs.units = 'Every unit row needs a unit ID and a stream.'
    if (s === 3 && form.permits.some((p) => !p.number.trim()))
      errs.permits = 'Every permit row needs a permit number.'
    if (s === 4) {
      if (!form.state) errs.state = 'Select a state.'
      if (!form.lga.trim()) errs.lga = 'LGA is required.'
    }
    return errs
  }

  const goNext = () => {
    const errs = validateStep(step)
    setErrors(errs)
    if (Object.keys(errs).length > 0) {
      setInvalidSteps((prev) => new Set(prev).add(step))
      return
    }
    setInvalidSteps((prev) => {
      const next = new Set(prev)
      next.delete(step)
      return next
    })
    setStep((s) => Math.min(5, s + 1))
  }

  const saveDraft = (andExit = false) => {
    toast('Draft saved — facility record kept as DRAFT.')
    if (andExit) onClose()
  }

  const submit = () => {
    const entry = appendAudit({
      actor: 'Engr. T. Wokoma',
      role: 'operator',
      action: 'FACILITY_SUBMITTED',
      entity: form.legalName || 'New facility (demo)',
      detail: `Facility onboarding submitted for approval — ${form.sector || 'sector pending'}, ${form.state || 'state pending'} (demo)`,
    })
    setSubmittedHash(entry.hash)
  }

  const attachEvidence = (index: number, file: File | null) => {
    if (!file) return
    const hash = demoHash(`permit-evidence|${file.name}|${file.size}`)
    setForm((f) => ({
      ...f,
      permits: f.permits.map((p, i) => (i === index ? { ...p, fileName: file.name, evidenceHash: hash } : p)),
    }))
    toast('Evidence attached — SHA-256 recorded.')
  }

  const onDrop = (index: number) => (e: DragEvent) => {
    e.preventDefault()
    attachEvidence(index, e.dataTransfer.files?.[0] ?? null)
  }

  const pickFile = (index: number) => (e: ChangeEvent<HTMLInputElement>) =>
    attachEvidence(index, e.target.files?.[0] ?? null)

  const summaryRows: Array<[string, string]> = [
    ['Legal name', form.legalName || '—'],
    ['RC number', form.rc || '—'],
    ['TIN', form.tin || '—'],
    ['Reporting contact', form.contactName || '—'],
    ['Sector', form.sector || '—'],
    [
      'Boundary',
      form.boundary === 'equity' ? 'Equity share' : 'Operational control',
    ],
    ['Scope 1 sources', form.scopes.join(', ') || '—'],
    ['Units & processes', form.units.filter((u) => u.unit).map((u) => u.unit).join(' · ') || '—'],
    ['Permits', form.permits.filter((p) => p.number).map((p) => `${p.issuer} ${p.number}`).join(' · ') || '—'],
    ['Location', [form.lga, form.state].filter(Boolean).join(', ') || '—'],
    ['Coordinates', form.lat && form.lon ? `${form.lat}° N, ${form.lon}° E (demo)` : '—'],
    ['Contact', [form.phone, form.email].filter(Boolean).join(' · ') || '—'],
  ]

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
          className="fixed inset-0 z-[70] flex flex-col bg-ivory"
          role="dialog"
          aria-modal="true"
          aria-label="Register a new facility"
        >
          {/* chrome */}
          <div className="flex items-center justify-between border-b border-line/60 px-8 py-4">
            <div>
              <p className="kicker text-muted">Operator / Facility / New</p>
              <p className="mt-1 font-sans text-[13px] text-muted">
                New facility registration — status starts as <span className="text-copper">DRAFT</span>.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setConfirmExit(true)}
              className="flex items-center gap-2 rounded-[2px] border border-ink/30 px-3 py-2 font-sans text-[12px] font-semibold text-ink transition-colors hover:border-ink hover:bg-sand"
            >
              <X className="h-3.5 w-3.5" strokeWidth={1.75} />
              Close
            </button>
          </div>

          {/* stepper (§6.14) */}
          {submittedHash === null && (
            <div className="border-b border-line/60 px-8 py-5">
              <div className="mx-auto flex max-w-[860px] items-start">
                {STEPS.map((label, i) => (
                  <div key={label} className="flex flex-1 items-start last:flex-none">
                    <div className="flex flex-col items-center gap-2">
                      <motion.span
                        animate={
                          i < step
                            ? { backgroundColor: '#0F4C5C', borderColor: '#0F4C5C', color: '#F5F0E6' }
                            : i === step
                              ? { borderColor: '#B5651D', color: '#B5651D' }
                              : invalidSteps.has(i)
                                ? { borderColor: '#A63D2F', color: '#A63D2F' }
                                : { borderColor: '#C9BBA2', color: '#5F7168' }
                        }
                        className="flex h-6 w-6 items-center justify-center border font-mono text-[12px]"
                      >
                        {String(i + 1).padStart(2, '0')}
                      </motion.span>
                      <span className="kicker text-center text-[9px] text-muted">{label}</span>
                    </div>
                    {i < STEPS.length - 1 && <span className="mx-2 mt-3 h-px flex-1 bg-line/60" aria-hidden="true" />}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* body */}
          <div className="flex-1 overflow-y-auto px-8 py-8">
            {submittedHash !== null ? (
              /* -------------------------------------------- success state */
              <motion.div
                initial={{ opacity: 0, y: 24 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, ease: EASE }}
                className="mx-auto flex max-w-[560px] flex-col items-start gap-5 pt-12"
              >
                <StatusChip status="Submitted" />
                <h2 className="font-display text-[48px] leading-none text-ink">Submitted.</h2>
                <p className="font-sans text-[13px] leading-[1.6] text-muted">
                  Status: SUBMITTED — a regulator will review this record. You will be notified. The
                  submission event has been written to the audit chain:
                </p>
                <HashChip hash={submittedHash} expanded className="max-w-full" />
                <button
                  type="button"
                  onClick={onClose}
                  className="mt-2 rounded-[2px] bg-petrol px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ivory transition-all duration-200 hover:-translate-y-px hover:bg-petrol-deep"
                >
                  Return to facility
                </button>
              </motion.div>
            ) : (
              <AnimatePresence mode="wait">
                <motion.div
                  key={step}
                  initial={{ opacity: 0, x: 24 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -24 }}
                  transition={{ duration: 0.3, ease: EASE }}
                  className="mx-auto max-w-[720px]"
                >
                  {/* ------------------------------------- 01 organisation */}
                  {step === 0 && (
                    <div className="flex flex-col gap-6">
                      <h2 className="font-display text-[28px] text-ink">Organisation.</h2>
                      <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
                        <Field label="Legal name" error={errors.legalName}>
                          <input
                            className={inputCls}
                            value={form.legalName}
                            onChange={(e) => set('legalName', e.target.value)}
                            placeholder="e.g. Delta Crest Energy Ltd"
                          />
                        </Field>
                        <Field label="RC number" helper="Corporate Affairs Commission registration." error={errors.rc}>
                          <input
                            className={inputCls}
                            value={form.rc}
                            onChange={(e) => set('rc', e.target.value)}
                            placeholder="RC 0000000"
                          />
                        </Field>
                        <Field label="TIN" helper="Federal Inland Revenue Service tax ID.">
                          <input
                            className={inputCls}
                            value={form.tin}
                            onChange={(e) => set('tin', e.target.value)}
                            placeholder="TIN-00000000"
                          />
                        </Field>
                        <Field label="Reporting contact" error={errors.contactName}>
                          <input
                            className={inputCls}
                            value={form.contactName}
                            onChange={(e) => set('contactName', e.target.value)}
                            placeholder="Name, role"
                          />
                        </Field>
                      </div>
                    </div>
                  )}

                  {/* --------------------------------- 02 sector/boundaries */}
                  {step === 1 && (
                    <div className="flex flex-col gap-6">
                      <h2 className="font-display text-[28px] text-ink">Sector & boundaries.</h2>
                      <Field label="Sector" error={errors.sector}>
                        <select className={inputCls} value={form.sector} onChange={(e) => set('sector', e.target.value)}>
                          <option value="">Select sector…</option>
                          {SECTOR_OPTIONS.map((s) => (
                            <option key={s} value={s}>
                              {s}
                            </option>
                          ))}
                        </select>
                      </Field>
                      <div className="flex flex-col gap-2">
                        <span className="kicker text-muted">Consolidation boundary</span>
                        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                          {(
                            [
                              ['equity', 'Equity share', 'Account for emissions in proportion to equity share of the operation.'],
                              ['operational', 'Operational control', 'Account for 100% of emissions from operations under operational control.'],
                            ] as const
                          ).map(([value, title, body]) => (
                            <button
                              key={value}
                              type="button"
                              onClick={() => set('boundary', value)}
                              className={cn(
                                'rounded-[2px] border p-4 text-left transition-colors',
                                form.boundary === value
                                  ? 'border-petrol bg-petrol/5'
                                  : 'border-line bg-ivory hover:border-ink/40',
                              )}
                            >
                              <span className="flex items-center gap-2 font-sans text-[14px] font-semibold text-ink">
                                <span
                                  className={cn(
                                    'h-3 w-3 rounded-full border-2',
                                    form.boundary === value ? 'border-petrol bg-petrol' : 'border-line',
                                  )}
                                />
                                {title}
                              </span>
                              <span className="mt-1.5 block font-sans text-[13px] leading-[1.5] text-muted">{body}</span>
                            </button>
                          ))}
                        </div>
                      </div>
                      <div className="flex flex-col gap-2">
                        <span className="kicker text-muted">Scope 1 sources present</span>
                        <div className="flex flex-wrap gap-2">
                          {SCOPE1_SOURCES.map((s) => {
                            const active = form.scopes.includes(s)
                            return (
                              <button
                                key={s}
                                type="button"
                                onClick={() =>
                                  set(
                                    'scopes',
                                    active ? form.scopes.filter((x) => x !== s) : [...form.scopes, s],
                                  )
                                }
                                className={cn(
                                  'rounded-[2px] border px-3 py-2 font-sans text-[13px] transition-colors',
                                  active
                                    ? 'border-petrol bg-petrol text-ivory'
                                    : 'border-line bg-ivory text-ink hover:border-ink/40',
                                )}
                              >
                                {s}
                              </button>
                            )
                          })}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* ------------------------------------- 03 units/processes */}
                  {step === 2 && (
                    <div className="flex flex-col gap-6">
                      <h2 className="font-display text-[28px] text-ink">Units & processes.</h2>
                      <div className="flex flex-wrap gap-3">
                        {UNIT_TEMPLATES.map((t) => (
                          <button
                            key={t.label}
                            type="button"
                            onClick={() =>
                              set('units', [...form.units, { unit: t.unit, type: t.type, stream: t.stream }])
                            }
                            className="link-sweep font-sans text-[13px] font-medium text-copper"
                          >
                            {t.label}
                          </button>
                        ))}
                      </div>
                      {errors.units && <p className="font-sans text-[12px] text-alert">{errors.units}</p>}
                      <div className="flex flex-col gap-3">
                        <AnimatePresence initial={false}>
                          {form.units.map((u, i) => (
                            <motion.div
                              key={i}
                              initial={{ opacity: 0, x: -24, height: 0 }}
                              animate={{ opacity: 1, x: 0, height: 'auto' }}
                              exit={{ opacity: 0, height: 0 }}
                              transition={{ duration: 0.3, ease: EASE }}
                              className="overflow-hidden"
                            >
                              <div className="grid grid-cols-[1fr_1fr_1fr_auto] items-end gap-3 rounded-[2px] border border-line/70 bg-ivory p-4">
                                <Field label="Unit ID">
                                  <input
                                    className={inputCls}
                                    value={u.unit}
                                    onChange={(e) =>
                                      set('units', form.units.map((x, j) => (j === i ? { ...x, unit: e.target.value } : x)))
                                    }
                                    placeholder="FL-01"
                                  />
                                </Field>
                                <Field label="Type">
                                  <input
                                    className={inputCls}
                                    value={u.type}
                                    onChange={(e) =>
                                      set('units', form.units.map((x, j) => (j === i ? { ...x, type: e.target.value } : x)))
                                    }
                                    placeholder="Flaring stack — elevated flare"
                                  />
                                </Field>
                                <Field label="Stream">
                                  <input
                                    className={inputCls}
                                    value={u.stream}
                                    onChange={(e) =>
                                      set('units', form.units.map((x, j) => (j === i ? { ...x, stream: e.target.value } : x)))
                                    }
                                    placeholder="Associated gas flared"
                                  />
                                </Field>
                                <button
                                  type="button"
                                  aria-label="Remove unit"
                                  onClick={() => set('units', form.units.filter((_, j) => j !== i))}
                                  className="mb-1 rounded-[2px] border border-alert/50 p-2.5 text-alert transition-colors hover:bg-alert hover:text-ivory"
                                >
                                  <Trash2 className="h-4 w-4" strokeWidth={1.75} />
                                </button>
                              </div>
                            </motion.div>
                          ))}
                        </AnimatePresence>
                      </div>
                      <button
                        type="button"
                        onClick={() => set('units', [...form.units, { unit: '', type: '', stream: '' }])}
                        className="flex w-fit items-center gap-2 rounded-[2px] border border-ink/30 px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ink transition-colors hover:border-ink hover:bg-sand"
                      >
                        <Plus className="h-3.5 w-3.5" strokeWidth={1.75} />
                        Add unit or process
                      </button>
                    </div>
                  )}

                  {/* -------------------------------------------- 04 permits */}
                  {step === 3 && (
                    <div className="flex flex-col gap-6">
                      <h2 className="font-display text-[28px] text-ink">Permits.</h2>
                      {errors.permits && <p className="font-sans text-[12px] text-alert">{errors.permits}</p>}
                      <div className="flex flex-col gap-4">
                        {form.permits.map((p, i) => (
                          <div key={i} className="flex flex-col gap-4 rounded-[2px] border border-line/70 bg-ivory p-4">
                            <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
                              <Field label="Issuer">
                                <select
                                  className={inputCls}
                                  value={p.issuer}
                                  onChange={(e) =>
                                    set('permits', form.permits.map((x, j) => (j === i ? { ...x, issuer: e.target.value } : x)))
                                  }
                                >
                                  {ISSUER_OPTIONS.map((o) => (
                                    <option key={o} value={o}>
                                      {o}
                                    </option>
                                  ))}
                                </select>
                              </Field>
                              <Field label="Permit number">
                                <input
                                  className={inputCls}
                                  value={p.number}
                                  onChange={(e) =>
                                    set('permits', form.permits.map((x, j) => (j === i ? { ...x, number: e.target.value } : x)))
                                  }
                                  placeholder="EA/RIV/0000 (demo)"
                                />
                              </Field>
                              <Field label="Expiry">
                                <input
                                  className={inputCls}
                                  value={p.expiry}
                                  onChange={(e) =>
                                    set('permits', form.permits.map((x, j) => (j === i ? { ...x, expiry: e.target.value } : x)))
                                  }
                                  placeholder="31 Dec 2027"
                                />
                              </Field>
                            </div>
                            {/* evidence drop zone */}
                            {p.evidenceHash ? (
                              <motion.div
                                initial={{ opacity: 0, y: 8 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ duration: 0.4, ease: EASE }}
                                className="flex items-center gap-3 rounded-[2px] border border-line/60 bg-sand px-4 py-3"
                              >
                                <FileText className="h-4 w-4 shrink-0 text-petrol" strokeWidth={1.75} />
                                <span className="font-sans text-[13px] font-medium text-ink">{p.fileName}</span>
                                <span className="data-s text-muted">SHA-256 recorded</span>
                                <HashChip hash={p.evidenceHash} />
                              </motion.div>
                            ) : (
                              <div
                                onDragOver={(e) => e.preventDefault()}
                                onDrop={onDrop(i)}
                                onClick={() => fileInputs.current[i]?.click()}
                                className="flex cursor-pointer flex-col items-center gap-2 rounded-[2px] border border-dashed border-line px-4 py-6 text-center transition-colors hover:border-copper"
                              >
                                <UploadCloud className="h-5 w-5 text-muted" strokeWidth={1.5} />
                                <p className="font-sans text-[13px] text-muted">
                                  Drop permit evidence here, or <span className="font-medium text-petrol">browse</span> — a
                                  SHA-256 hash is computed on attach.
                                </p>
                                <input
                                  ref={(el) => {
                                    fileInputs.current[i] = el
                                  }}
                                  type="file"
                                  className="hidden"
                                  onChange={pickFile(i)}
                                />
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                      <button
                        type="button"
                        onClick={() =>
                          set('permits', [...form.permits, { issuer: 'NESREA', number: '', expiry: '', fileName: null, evidenceHash: null }])
                        }
                        className="flex w-fit items-center gap-2 rounded-[2px] border border-ink/30 px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ink transition-colors hover:border-ink hover:bg-sand"
                      >
                        <Plus className="h-3.5 w-3.5" strokeWidth={1.75} />
                        Add permit
                      </button>
                    </div>
                  )}

                  {/* ----------------------------------- 05 location/contacts */}
                  {step === 4 && (
                    <div className="flex flex-col gap-6">
                      <h2 className="font-display text-[28px] text-ink">Location & contacts.</h2>
                      <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
                        <Field label="State" error={errors.state}>
                          <select className={inputCls} value={form.state} onChange={(e) => set('state', e.target.value)}>
                            <option value="">Select state…</option>
                            {NIGERIAN_STATES.map((s) => (
                              <option key={s} value={s}>
                                {s}
                              </option>
                            ))}
                          </select>
                        </Field>
                        <Field label="LGA" error={errors.lga}>
                          <input
                            className={inputCls}
                            value={form.lga}
                            onChange={(e) => set('lga', e.target.value)}
                            placeholder="e.g. Ahoada East"
                          />
                        </Field>
                        <Field label="Latitude" helper="Decimal degrees, WGS-84 (demo).">
                          <input
                            className={inputCls}
                            value={form.lat}
                            onChange={(e) => set('lat', e.target.value)}
                            placeholder="4.8812"
                          />
                        </Field>
                        <Field label="Longitude">
                          <input
                            className={inputCls}
                            value={form.lon}
                            onChange={(e) => set('lon', e.target.value)}
                            placeholder="6.6478"
                          />
                        </Field>
                        <Field label="Phone">
                          <input
                            className={inputCls}
                            value={form.phone}
                            onChange={(e) => set('phone', e.target.value)}
                            placeholder="+234 … (demo)"
                          />
                        </Field>
                        <Field label="Email">
                          <input
                            className={inputCls}
                            value={form.email}
                            onChange={(e) => set('email', e.target.value)}
                            placeholder="name@company.ng (demo)"
                          />
                        </Field>
                      </div>
                    </div>
                  )}

                  {/* --------------------------------------------- 06 review */}
                  {step === 5 && (
                    <div className="flex flex-col gap-6">
                      <h2 className="font-display text-[28px] text-ink">Review & submit.</h2>
                      <div className="rounded-[2px] border border-line/70 bg-ivory">
                        {summaryRows.map(([label, value], i) => (
                          <motion.div
                            key={label}
                            initial={{ opacity: 0, y: 8 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.3, delay: i * 0.04, ease: EASE }}
                            className="flex gap-6 border-b border-line/40 px-5 py-3 last:border-b-0"
                          >
                            <span className="kicker w-[170px] shrink-0 pt-0.5 text-muted">{label}</span>
                            <span className="font-sans text-[14px] text-ink">{value}</span>
                          </motion.div>
                        ))}
                      </div>
                      <div className="rounded-[2px] border border-line border-l-4 border-l-copper bg-ivory px-5 py-4">
                        <p className="font-sans text-[13px] leading-[1.6] text-ink">
                          On submission this record enters the audit chain with a hash. Status becomes{' '}
                          <span className="font-semibold text-copper">SUBMITTED</span> and a regulator reviews for
                          approval. Only an approved facility with an approved monitoring plan may report.
                        </p>
                      </div>
                    </div>
                  )}
                </motion.div>
              </AnimatePresence>
            )}
          </div>

          {/* footer */}
          {submittedHash === null && (
            <div className="flex items-center justify-between border-t border-line/60 px-8 py-4">
              <button
                type="button"
                onClick={() => saveDraft(false)}
                className="font-sans text-[13px] font-medium text-muted transition-colors hover:text-ink"
              >
                Save draft
              </button>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setStep((s) => Math.max(0, s - 1))}
                  disabled={step === 0}
                  className="rounded-[2px] border border-ink/30 px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ink transition-colors hover:border-ink hover:bg-sand disabled:cursor-not-allowed disabled:opacity-40"
                >
                  Back
                </button>
                {step < 5 ? (
                  <button
                    type="button"
                    onClick={goNext}
                    className="rounded-[2px] bg-petrol px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ivory transition-all duration-200 hover:-translate-y-px hover:bg-petrol-deep"
                  >
                    Continue
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={submit}
                    className="rounded-[2px] bg-copper px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ivory transition-all duration-200 hover:-translate-y-px hover:bg-copper-light hover:text-ink"
                  >
                    Submit for approval
                  </button>
                )}
              </div>
            </div>
          )}

          {/* escape → save-as-draft confirmation (§6.13 modal) */}
          <AnimatePresence>
            {confirmExit && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.25 }}
                className="absolute inset-0 z-10 flex items-center justify-center bg-petrol-deep/60 backdrop-blur-[4px]"
                onClick={() => setConfirmExit(false)}
              >
                <motion.div
                  initial={{ opacity: 0, scale: 0.97 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.97 }}
                  transition={{ duration: 0.25, ease: EASE }}
                  className="w-full max-w-[560px] rounded-[2px] border border-line bg-ivory p-8"
                  onClick={(e) => e.stopPropagation()}
                  role="alertdialog"
                  aria-label="Save draft and exit"
                >
                  <h3 className="font-display text-[28px] text-ink">Save draft and exit?</h3>
                  <LedgerRule className="mt-4" />
                  <p className="mt-4 font-sans text-[13px] leading-[1.6] text-muted">
                    The record stays a DRAFT — nothing enters the audit chain until you submit for approval.
                  </p>
                  <div className="mt-6 flex justify-end gap-3">
                    <button
                      type="button"
                      onClick={() => setConfirmExit(false)}
                      className="rounded-[2px] border border-ink/30 px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ink transition-colors hover:border-ink hover:bg-sand"
                    >
                      Keep editing
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setConfirmExit(false)
                        saveDraft(true)
                      }}
                      className="rounded-[2px] bg-petrol px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ivory transition-all duration-200 hover:-translate-y-px hover:bg-petrol-deep"
                    >
                      Save draft & exit
                    </button>
                  </div>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
