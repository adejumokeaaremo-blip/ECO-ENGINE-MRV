/**
 * New upload wizard (uploads.md §3) — 4 steps:
 * 01 Stream & period · 02 Activity data · 03 Evidence · 04 Validate & submit.
 * On submit, calls the store's submitUpload() so the new submission lands in the
 * verifier queue as an AI estimate — pending human verification.
 */
import { useEffect, useMemo, useRef, useState } from 'react'
import { useNavigate } from 'react-router'
import { AnimatePresence, motion } from 'framer-motion'
import { toast } from 'sonner'
import {
  AlertTriangle,
  Check,
  FileText,
  Image as ImageIcon,
  Loader2,
  UploadCloud,
  X,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import type { Facility, Stream } from '@/lib/demo-data'
import { demoHash, submitUpload, truncateHash, useAuditTrail } from '@/lib/store'
import AILabel from '@/components/app/AILabel'
import LedgerRule from '@/components/app/LedgerRule'
import {
  AccentButton,
  EASE_MICRO,
  EASE_PRIMARY,
  PrimaryButton,
  SecondaryButton,
  fmtInt,
  streamLabelFor,
} from './shared'

/* ------------------------------------------------------------ demo maths */

/** Demonstrator-grade AI estimate from activity data (IPCC 2006/2019-aligned factors, §8). */
function estimateFor(
  facilityId: string,
  streamId: string,
  value: number,
  days: number,
): { tonnes: number; uncertainty: string; factorNote: string } {
  if (facilityId === 'FAC-RIV-004') {
    if (streamId === 'S1')
      return {
        tonnes: value * days * 60.3,
        uncertainty: '±6%',
        factorNote: '60.3 t CO₂e/MMscf — GGFR guidance + IPCC 2006 Vol. 2 Ch. 4 (derived, illustrative)',
      }
    if (streamId === 'S2')
      return {
        tonnes: value * days * 1.093 * 56.1,
        uncertainty: '±6%',
        factorNote: '56,100 kg CO₂/TJ — IPCC 2006, Vol. 2, Ch. 2, Table 2.2 (default)',
      }
    return {
      tonnes: (value * 2.69) / 1000,
      uncertainty: '±12%',
      factorNote: '74,100 kg CO₂/TJ — IPCC 2006, Vol. 2, Ch. 2, Table 2.2 (default)',
    }
  }
  if (streamId === 'S1')
    return {
      tonnes: value * 0.52 * 1.02,
      uncertainty: '±5%',
      factorNote: '0.52 t CO₂/t clinker (+2% CKD) — IPCC 2006, Vol. 3, Ch. 2, Eq. 2.4',
    }
  if (streamId === 'S2')
    return {
      tonnes: value * 2.96,
      uncertainty: '±7%',
      factorNote: '97,500 kg CO₂/TJ — IPCC 2006, Vol. 2, Ch. 2, Table 2.2 (default)',
    }
  return {
    tonnes: value * 1.093 * 56.1,
    uncertainty: '±6%',
    factorNote: '56,100 kg CO₂/TJ — IPCC 2006, Vol. 2, Ch. 2, Table 2.2 (default)',
  }
}

const MONTHS_FULL = [
  'July 2025', 'August 2025', 'September 2025', 'October 2025', 'November 2025', 'December 2025',
  'January 2026', 'February 2026', 'March 2026', 'April 2026', 'May 2026', 'June 2026',
]
const MONTHS_SHORT = [
  'Jul 2025', 'Aug 2025', 'Sep 2025', 'Oct 2025', 'Nov 2025', 'Dec 2025',
  'Jan 2026', 'Feb 2026', 'Mar 2026', 'Apr 2026', 'May 2026', 'Jun 2026',
]

function daysInPeriod(period: string): number {
  const [m, y] = period.split(' ')
  return new Date(Number(y), new Date(`${m} 1, 2000`).getMonth() + 1, 0).getDate()
}

/** Trailing 6-month mean + previous value for the facility's primary stream. */
function baselineFor(facility: Facility, period: string): { mean: number | null; prev: number | null } {
  const idx = MONTHS_FULL.indexOf(period)
  if (idx < 0) return { mean: null, prev: null }
  const short = MONTHS_SHORT[idx]
  const hIdx = facility.history.findIndex((h) => h.month === short)
  if (hIdx <= 0) return { mean: null, prev: null }
  const trailing = facility.history.slice(Math.max(0, hIdx - 6), hIdx)
  const mean = trailing.reduce((a, b) => a + b.value, 0) / trailing.length
  return { mean, prev: facility.history[hIdx - 1].value }
}

/* ------------------------------------------------------- hash scramble */

const HEX = '0123456789abcdef'
function ScrambleHash({ target, className }: { target: string; className?: string }) {
  const [text, setText] = useState(target)
  useEffect(() => {
    const t0 = performance.now()
    let raf = 0
    const tick = (now: number) => {
      const p = Math.min(1, (now - t0) / 800)
      const settled = Math.floor(p * target.length)
      let out = target.slice(0, settled)
      for (let i = settled; i < target.length; i++) {
        out += i < 2 ? target[i] : HEX[Math.floor(Math.random() * 16)]
      }
      setText(out)
      if (p < 1) raf = requestAnimationFrame(tick)
      else setText(target)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [target])
  return <span className={cn('font-mono text-[11px] tracking-[0.02em] text-muted', className)}>{truncateHash(text)}</span>
}

/* ------------------------------------------------------------ evidence */

interface EvidenceFile {
  name: string
  size: string
  hash: string
  kind: string
  description: string
}

const EVIDENCE_KINDS = ['meter export', 'delivery note', 'report', 'photo']

/* ----------------------------------------------------------- validation */

interface Check {
  label: string
  detail: string
  result: 'pass' | 'warn'
}

function ValidationSequence({ checks }: { checks: Check[] }) {
  const [done, setDone] = useState(0)
  useEffect(() => {
    let i = 0
    const id = window.setInterval(() => {
      i += 1
      setDone(i)
      if (i >= checks.length) window.clearInterval(id)
    }, 350)
    return () => window.clearInterval(id)
  }, [checks])

  return (
    <ul className="divide-y divide-line/40">
      {checks.map((c, i) => {
        const state = i < done ? 'done' : i === done ? 'running' : 'queued'
        return (
          <li key={c.label} className="flex items-start gap-3 py-3">
            <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center">
              {state === 'running' && <Loader2 className="h-4 w-4 animate-spin text-muted" strokeWidth={1.75} />}
              {state === 'done' &&
                (c.result === 'pass' ? (
                  <motion.span
                    initial={{ scale: 0.4, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ duration: 0.3, ease: EASE_PRIMARY }}
                    className="flex h-5 w-5 items-center justify-center rounded-full bg-petrol"
                  >
                    <Check className="h-3 w-3 text-ivory" strokeWidth={3} />
                  </motion.span>
                ) : (
                  <motion.span
                    initial={{ scale: 0.4, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ duration: 0.3, ease: EASE_PRIMARY }}
                    className="flex h-5 w-5 items-center justify-center rounded-full border border-copper"
                  >
                    <AlertTriangle className="h-3 w-3 text-copper" strokeWidth={2} />
                  </motion.span>
                ))}
              {state === 'queued' && <span className="h-4 w-4 rounded-full border border-line" />}
            </span>
            <span className="min-w-0">
              <span
                className={cn(
                  'kicker',
                  state === 'done' ? (c.result === 'pass' ? 'text-petrol' : 'text-copper') : 'text-muted',
                )}
              >
                {c.label} {state === 'done' && (c.result === 'pass' ? '✓' : '⚠')}
              </span>
              <span className="mt-0.5 block font-sans text-[13px] text-muted">
                {state === 'done' ? c.detail : state === 'running' ? 'Running…' : 'Queued'}
              </span>
            </span>
          </li>
        )
      })}
    </ul>
  )
}

/* -------------------------------------------------------------- stepper */

const STEPS = ['Stream & period', 'Activity data', 'Evidence', 'Validate & submit']

function Stepper({ step }: { step: number }) {
  return (
    <div className="flex items-start">
      {STEPS.map((label, i) => {
        const state = i < step ? 'complete' : i === step ? 'current' : 'future'
        return (
          <div key={label} className="flex flex-1 items-start last:flex-none">
            <div className="flex flex-col items-center gap-2">
              <span
                className={cn(
                  'flex h-6 w-6 items-center justify-center rounded-[2px] font-mono text-[12px]',
                  state === 'complete' && 'bg-petrol text-ivory',
                  state === 'current' && 'border border-copper text-copper',
                  state === 'future' && 'border border-line text-muted',
                )}
              >
                {state === 'complete' ? <Check className="h-3 w-3" strokeWidth={3} /> : `0${i + 1}`}
              </span>
              <span className={cn('kicker whitespace-nowrap', state === 'future' ? 'text-muted/60' : 'text-muted')}>
                {label}
              </span>
            </div>
            {i < STEPS.length - 1 && <span className="mx-3 mt-3 h-px flex-1 bg-line/60" />}
          </div>
        )
      })}
    </div>
  )
}

/* --------------------------------------------------------------- wizard */

export default function UploadWizard({
  facility,
  findDuplicate,
  onClose,
}: {
  facility: Facility
  /** returns the conflicting submission id when stream+period is already on the ledger */
  findDuplicate: (streamLabel: string, period: string) => string | null
  onClose: () => void
}) {
  const navigate = useNavigate()
  const audit = useAuditTrail()
  const [step, setStep] = useState(0)
  const [streamId, setStreamId] = useState<string | null>(null)
  const [period, setPeriod] = useState('June 2026')
  const [value, setValue] = useState('')
  const [days, setDays] = useState(() => daysInPeriod('June 2026'))
  const [notes, setNotes] = useState('')
  const [touched, setTouched] = useState(false)
  const [files, setFiles] = useState<EvidenceFile[]>([])
  const [dragging, setDragging] = useState(false)
  const [submittedId, setSubmittedId] = useState<string | null>(null)
  const [submittedEstimate, setSubmittedEstimate] = useState<{ tonnes: number; uncertainty: string } | null>(null)
  const [estimateReady, setEstimateReady] = useState(false)
  const toastFired = useRef(false)
  const fileInput = useRef<HTMLInputElement | null>(null)

  const stream: Stream | null = facility.streams.find((s) => s.id === streamId) ?? null
  const streamLabel = stream ? streamLabelFor(facility.id, stream.id) : null
  const duplicate = streamLabel ? findDuplicate(streamLabel, period) : null

  const numValue = parseFloat(value.replace(/,/g, ''))
  const baseline = baselineFor(facility, period)
  const isPrimaryStream = streamId === facility.streams[0]?.id
  const deviationPct =
    isPrimaryStream && baseline.mean && Number.isFinite(numValue) && baseline.mean > 0
      ? (numValue / baseline.mean - 1) * 100
      : null
  const outOfRange = deviationPct !== null && Math.abs(deviationPct) > 30
  const repeatsPrevious =
    isPrimaryStream && baseline.prev !== null && Number.isFinite(numValue) && numValue === baseline.prev
  const flag = outOfRange
    ? `intensity shift ${deviationPct! > 0 ? '+' : ''}${Math.round(deviationPct!)}%`
    : repeatsPrevious
      ? 'repeated identical values'
      : null

  const estimate = useMemo(() => {
    if (!stream || !Number.isFinite(numValue) || numValue <= 0) return null
    return estimateFor(facility.id, stream.id, numValue, days)
  }, [stream, facility.id, numValue, days])

  const checks: Check[] = useMemo(() => {
    if (!stream) return []
    const dim = daysInPeriod(period)
    return [
      { label: 'Schema', detail: 'All required fields present', result: 'pass' },
      { label: 'Units', detail: `${stream.unit} matches plan ${stream.id}`, result: 'pass' },
      {
        label: 'Completeness',
        detail: `${days}/${dim} operating days${days < dim ? ' — partial period noted' : ''}`,
        result: 'pass',
      },
      outOfRange
        ? {
            label: 'Out-of-range',
            detail: `value ${deviationPct! > 0 ? '+' : ''}${Math.round(deviationPct!)}% vs 6-month mean — flag will be attached`,
            result: 'warn',
          }
        : repeatsPrevious
          ? { label: 'Out-of-range', detail: 'identical to previous period to the decimal — flag will be attached', result: 'warn' }
          : { label: 'Out-of-range', detail: 'Within expected band', result: 'pass' },
      { label: 'Duplicates', detail: 'No duplicate for period', result: 'pass' },
    ]
  }, [stream, period, days, outOfRange, repeatsPrevious, deviationPct])

  /* toast + estimate micro-sequence after submit */
  useEffect(() => {
    if (!submittedId) return
    const t = window.setTimeout(() => setEstimateReady(true), 1500)
    return () => window.clearTimeout(t)
  }, [submittedId])

  useEffect(() => {
    if (!submittedId || toastFired.current) return
    const entry = [...audit].reverse().find((e) => e.entity === submittedId)
    if (entry) {
      toastFired.current = true
      toast(`Logged to audit chain — ${truncateHash(entry.hash)}`)
    }
  }, [audit, submittedId])

  const canContinue =
    step === 0
      ? !!stream && !duplicate
      : step === 1
        ? Number.isFinite(numValue) && numValue > 0 && days > 0
        : step === 2
          ? files.length > 0
          : true

  const addFiles = (list: FileList | null) => {
    if (!list) return
    const next = Array.from(list).map((f, i) => ({
      name: f.name,
      size: f.size > 1024 * 1024 ? `${(f.size / 1024 / 1024).toFixed(1)} MB` : `${Math.max(1, Math.round(f.size / 1024))} KB`,
      hash: demoHash(`${f.name}|${f.size}|${Date.now()}|${i}`),
      kind: 'meter export',
      description: '',
    }))
    setFiles((prev) => [...prev, ...next])
  }

  const doSubmit = () => {
    if (!stream || !streamLabel || !estimate) return
    const sub = submitUpload({
      facilityId: facility.id,
      streamLabel,
      period,
      activityValue: `${numValue.toLocaleString('en-US', { maximumFractionDigits: 2 })} ${stream.unit}`,
      aiEstimate: `${fmtInt(estimate.tonnes)} tCO2e`,
      uncertainty: estimate.uncertainty,
      flag,
    })
    setSubmittedEstimate({ tonnes: estimate.tonnes, uncertainty: estimate.uncertainty })
    setSubmittedId(sub.id)
  }

  /* -------------------------------------------------------- success view */
  if (submittedId && submittedEstimate) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: EASE_PRIMARY }}
        className="mx-auto max-w-[640px] py-16 text-center"
      >
        <p className="kicker text-muted">Submission {submittedId}</p>
        <h2 className="mt-4 font-display text-[48px] leading-none text-ink">Submitted.</h2>
        <div className="mt-6 flex justify-center">
          <AILabel size="lg" />
        </div>
        <p className="mx-auto mt-6 max-w-[480px] font-sans text-[15px] leading-[1.6] text-muted">
          The engine is estimating emissions for this submission. It will appear in the verifier's
          queue as an AI estimate — pending human verification.
        </p>
        <div className="mt-8 min-h-[64px]">
          <AnimatePresence>
            {estimateReady && (
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, ease: EASE_PRIMARY }}
              >
                <p className="kicker text-muted">AI estimate ready</p>
                <p className="mt-1 font-display text-[40px] leading-none text-copper">
                  {fmtInt(submittedEstimate.tonnes)}{' '}
                  <span className="text-[20px] text-ink">tCO₂e {submittedEstimate.uncertainty}</span>
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        <div className="mt-8 flex justify-center gap-3">
          <PrimaryButton onClick={onClose}>View in uploads</PrimaryButton>
          <SecondaryButton onClick={() => navigate('/operator')}>Go to dashboard</SecondaryButton>
        </div>
      </motion.div>
    )
  }

  /* ------------------------------------------------------------ wizard */
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: EASE_PRIMARY }}
    >
      <div className="mb-8 flex items-start justify-between gap-4">
        <div>
          <p className="kicker text-muted">Operator / Uploads / New</p>
          <h1 className="mt-3 font-display text-[40px] leading-[1.05] text-ink">New upload.</h1>
          <p className="mt-2 font-sans text-[15px] text-muted">
            {facility.name} · monitoring plan {facility.plan.version}
          </p>
        </div>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close wizard"
          className="mt-2 text-muted transition-colors hover:text-ink"
        >
          <X className="h-5 w-5" strokeWidth={1.75} />
        </button>
      </div>

      <div className="rounded-[2px] border border-line bg-ivory p-8">
        <Stepper step={step} />
        <LedgerRule className="my-8" />

        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, x: 24 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -24 }}
            transition={{ duration: 0.3, ease: EASE_PRIMARY }}
          >
            {/* ------------------------------------------- step 1: stream & period */}
            {step === 0 && (
              <div className="grid gap-8 md:grid-cols-[1fr_260px]">
                <div>
                  <p className="kicker mb-4 text-muted">Plan stream</p>
                  <div className="divide-y divide-line/40 border-y border-line/60">
                    {facility.streams.map((s) => {
                      const active = streamId === s.id
                      return (
                        <button
                          key={s.id}
                          type="button"
                          onClick={() => setStreamId(s.id)}
                          className={cn(
                            'flex w-full items-center justify-between gap-4 py-4 text-left transition-colors',
                            active ? 'bg-sand/60' : 'hover:bg-sand/40',
                          )}
                        >
                          <span className="flex items-center gap-3 pl-2">
                            <span
                              className={cn(
                                'h-3 w-3 rounded-full border',
                                active ? 'border-[4px] border-petrol' : 'border-line',
                              )}
                            />
                            <span className="font-display text-[18px] text-ink">{s.label}</span>
                          </span>
                          <span className="flex items-center gap-2 pr-2">
                            <span className="rounded-[2px] bg-ink/10 px-2 py-1 font-sans text-[10px] font-semibold uppercase tracking-chip text-ink">
                              {s.tier}
                            </span>
                            <span className="rounded-[2px] border border-copper px-2 py-1 font-sans text-[10px] font-semibold uppercase tracking-chip text-copper">
                              {s.method === 'metered' ? 'metered' : 'estimated'}
                            </span>
                            <span className="data-s hidden text-muted md:inline">{s.meter}</span>
                          </span>
                        </button>
                      )
                    })}
                  </div>
                  {duplicate && (
                    <motion.p
                      initial={{ opacity: 0, y: 4 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="mt-4 border-l-4 border-alert bg-alert/5 px-4 py-3 font-sans text-[13px] text-alert"
                    >
                      A submission for this stream and period already exists ({duplicate}). Duplicates
                      are not admitted to the ledger.
                    </motion.p>
                  )}
                </div>
                <div>
                  <p className="kicker mb-4 text-muted">Reporting period</p>
                  <select
                    value={period}
                    onChange={(e) => {
                      setPeriod(e.target.value)
                      setDays(daysInPeriod(e.target.value))
                    }}
                    className="w-full rounded-[2px] border border-line bg-ivory px-3 py-2.5 font-mono text-[13px] text-ink focus:border-copper focus:outline-none"
                  >
                    {MONTHS_FULL.map((m) => (
                      <option key={m} value={m}>
                        {m}
                      </option>
                    ))}
                  </select>
                  <p className="mt-3 font-sans text-[13px] leading-[1.5] text-muted">
                    One upload per stream per period. June 2026 reports are due today, 15 July 2026.
                  </p>
                </div>
              </div>
            )}

            {/* --------------------------------------------- step 2: activity data */}
            {step === 1 && stream && (
              <div className="max-w-[560px]">
                <p className="kicker text-muted">Activity value — {stream.label}</p>
                <div className="mt-3 flex items-baseline gap-3 border-b border-line pb-3">
                  <input
                    value={value}
                    onChange={(e) => setValue(e.target.value)}
                    onBlur={() => setTouched(true)}
                    inputMode="decimal"
                    placeholder="0.00"
                    autoFocus
                    className="w-full bg-transparent font-sans text-[24px] text-ink placeholder:text-muted/40 focus:outline-none"
                  />
                  <span className="shrink-0 font-mono text-[13px] text-muted">{stream.unit}</span>
                </div>
                <AnimatePresence>
                  {touched && outOfRange && (
                    <motion.p
                      initial={{ opacity: 0, y: 4 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className="mt-3 flex items-start gap-2 border-l-4 border-copper bg-copper/5 px-4 py-3 font-sans text-[13px] text-copper"
                    >
                      <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" strokeWidth={1.75} />
                      This is {Math.abs(Math.round(deviationPct!))}% {deviationPct! > 0 ? 'above' : 'below'} your
                      6-month mean. It will be flagged for the verifier — consider adding a note and
                      evidence.
                    </motion.p>
                  )}
                  {touched && repeatsPrevious && !outOfRange && (
                    <motion.p
                      initial={{ opacity: 0, y: 4 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className="mt-3 flex items-start gap-2 border-l-4 border-copper bg-copper/5 px-4 py-3 font-sans text-[13px] text-copper"
                    >
                      <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" strokeWidth={1.75} />
                      Identical to the previous period to the decimal. It will be flagged for the
                      verifier — consider adding a note and evidence.
                    </motion.p>
                  )}
                </AnimatePresence>

                <div className="mt-6 grid gap-6 md:grid-cols-[160px_1fr]">
                  <div>
                    <p className="kicker text-muted">Operating days</p>
                    <input
                      value={days}
                      onChange={(e) => setDays(Math.max(0, Math.min(31, Number(e.target.value) || 0)))}
                      inputMode="numeric"
                      className="mt-3 w-full rounded-[2px] border border-line bg-ivory px-3 py-2.5 font-mono text-[13px] text-ink focus:border-copper focus:outline-none"
                    />
                    <p className="mt-2 data-s text-muted">of {daysInPeriod(period)} in period</p>
                  </div>
                  <div>
                    <p className="kicker text-muted">Notes for the verifier</p>
                    <textarea
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      rows={3}
                      placeholder="Explain anything the verifier should know — this is read alongside the evidence."
                      className="mt-3 w-full resize-none rounded-[2px] border border-line bg-ivory px-3 py-2.5 font-sans text-[13px] leading-[1.5] text-ink placeholder:text-muted/50 focus:border-copper focus:outline-none"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* -------------------------------------------------- step 3: evidence */}
            {step === 2 && (
              <div>
                <div
                  onDragOver={(e) => {
                    e.preventDefault()
                    setDragging(true)
                  }}
                  onDragLeave={() => setDragging(false)}
                  onDrop={(e) => {
                    e.preventDefault()
                    setDragging(false)
                    addFiles(e.dataTransfer.files)
                  }}
                  className={cn(
                    'flex flex-col items-center justify-center gap-3 rounded-[2px] border border-dashed px-6 py-12 text-center transition-colors',
                    dragging ? 'border-copper bg-copper/5' : 'border-line bg-sand/40',
                  )}
                >
                  <UploadCloud className="h-6 w-6 text-muted" strokeWidth={1.5} />
                  <p className="kicker text-muted">Drop files or browse</p>
                  <p className="font-sans text-[13px] text-muted">
                    Meter exports, delivery notes, reports, photographs. Each file is hashed (SHA-256)
                    on admission.
                  </p>
                  <SecondaryButton onClick={() => fileInput.current?.click()}>Browse files</SecondaryButton>
                  <input
                    ref={fileInput}
                    type="file"
                    multiple
                    className="hidden"
                    onChange={(e) => {
                      addFiles(e.target.files)
                      e.target.value = ''
                    }}
                  />
                </div>

                {files.length === 0 && (
                  <p className="mt-4 font-sans text-[13px] text-copper">
                    At least one evidence file is required.
                  </p>
                )}

                <ul className="mt-4 divide-y divide-line/40">
                  <AnimatePresence>
                    {files.map((f, i) => (
                      <motion.li
                        key={f.hash}
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.25, ease: EASE_MICRO }}
                        className="flex flex-wrap items-center gap-4 py-3"
                      >
                        {f.kind === 'photo' ? (
                          <ImageIcon className="h-4 w-4 shrink-0 text-muted" strokeWidth={1.75} />
                        ) : (
                          <FileText className="h-4 w-4 shrink-0 text-muted" strokeWidth={1.75} />
                        )}
                        <span className="min-w-[180px] flex-1">
                          <span className="block font-sans text-[13px] font-semibold text-ink">{f.name}</span>
                          <span className="data-s text-muted">
                            {f.size} · Engr. T. Wokoma · 15 Jul 2026
                          </span>
                        </span>
                        <ScrambleHash target={f.hash} />
                        <select
                          value={f.kind}
                          onChange={(e) =>
                            setFiles((prev) => prev.map((p, j) => (j === i ? { ...p, kind: e.target.value } : p)))
                          }
                          className="rounded-[2px] border border-line bg-ivory px-2 py-1.5 font-sans text-[12px] text-ink focus:border-copper focus:outline-none"
                        >
                          {EVIDENCE_KINDS.map((k) => (
                            <option key={k}>{k}</option>
                          ))}
                        </select>
                        <input
                          value={f.description}
                          onChange={(e) =>
                            setFiles((prev) =>
                              prev.map((p, j) => (j === i ? { ...p, description: e.target.value } : p)),
                            )
                          }
                          placeholder="Description"
                          className="w-[160px] rounded-[2px] border border-line bg-ivory px-2 py-1.5 font-sans text-[12px] text-ink placeholder:text-muted/50 focus:border-copper focus:outline-none"
                        />
                        <button
                          type="button"
                          onClick={() => setFiles((prev) => prev.filter((_, j) => j !== i))}
                          aria-label={`Remove ${f.name}`}
                          className="text-muted transition-colors hover:text-alert"
                        >
                          <X className="h-4 w-4" strokeWidth={1.75} />
                        </button>
                      </motion.li>
                    ))}
                  </AnimatePresence>
                </ul>
              </div>
            )}

            {/* -------------------------------------- step 4: validate & submit */}
            {step === 3 && stream && estimate && (
              <div className="grid gap-10 md:grid-cols-2">
                <div>
                  <p className="kicker mb-4 text-muted">Summary</p>
                  <dl className="divide-y divide-line/40 border-y border-line/60">
                    {[
                      ['Submission', 'assigned on submit'],
                      ['Facility', facility.name],
                      ['Stream', `${stream.id} — ${stream.label}`],
                      ['Period', period],
                      ['Activity value', `${numValue.toLocaleString('en-US')} ${stream.unit}`],
                      ['Operating days', `${days} / ${daysInPeriod(period)}`],
                      ['Evidence', `${files.length} file${files.length === 1 ? '' : 's'} — hashed`],
                      ['Notes', notes.trim() ? notes.trim() : '—'],
                    ].map(([k, v]) => (
                      <div key={k} className="flex items-baseline justify-between gap-6 py-2.5">
                        <dt className="kicker shrink-0 text-muted">{k}</dt>
                        <dd className="text-right font-mono text-[13px] text-ink">{v}</dd>
                      </div>
                    ))}
                  </dl>
                  <p className="mt-4 data-s text-muted">
                    Estimate basis: {estimate.factorNote}
                  </p>
                  <div className="mt-4">
                    <AILabel />
                  </div>
                </div>
                <div className="rounded-[2px] border border-line bg-ivory px-5 py-2">
                  <p className="kicker py-3 text-muted">Automated validation</p>
                  <ValidationSequence key={`${stream.id}|${period}|${flag ?? 'clean'}`} checks={checks} />
                </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>

        {/* footer */}
        <div className="mt-10 flex items-center justify-between border-t border-line/60 pt-6">
          <SecondaryButton onClick={() => (step === 0 ? onClose() : setStep((s) => s - 1))}>
            Back
          </SecondaryButton>
          <div className="flex items-center gap-4">
            {step === 3 && flag && (
              <span className="font-sans text-[13px] text-copper">
                1 flag will be attached — the verifier sees it with your note.
              </span>
            )}
            {step < 3 ? (
              <PrimaryButton onClick={() => setStep((s) => s + 1)} disabled={!canContinue}>
                Continue
              </PrimaryButton>
            ) : (
              <AccentButton onClick={doSubmit} disabled={!estimate}>Submit to verification queue</AccentButton>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  )
}
