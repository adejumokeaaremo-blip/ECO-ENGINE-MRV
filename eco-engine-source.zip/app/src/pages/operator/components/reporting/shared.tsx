/**
 * Reporting pages — shared local primitives (Uploads / DQI / Disclosure Packs).
 * Buttons (design.md §6.5), modal & drawer (§6.13), page header, motion tokens (§5).
 */
import { useEffect, type ReactNode } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { X } from 'lucide-react'
import { cn } from '@/lib/utils'
import LedgerRule from '@/components/app/LedgerRule'

export const EASE_PRIMARY = [0.22, 1, 0.36, 1] as [number, number, number, number]
export const EASE_MICRO = [0.4, 0, 0.2, 1] as [number, number, number, number]

export const fmtInt = (v: number) => Math.round(v).toLocaleString('en-US')

/** Stream label used across submissions/queue for a plan stream (demo mapping). */
export function streamLabelFor(facilityId: string, streamId: string): string {
  const map: Record<string, Record<string, string>> = {
    'FAC-RIV-004': { S1: 'flaring', S2: 'fuel gas', S3: 'diesel' },
    'FAC-KOG-002': { S1: 'clinker', S2: 'petcoke', S3: 'natural gas' },
  }
  return map[facilityId]?.[streamId] ?? streamId
}

/* ------------------------------------------------------------- buttons */

type BtnProps = {
  children: ReactNode
  onClick?: () => void
  disabled?: boolean
  className?: string
  type?: 'button' | 'submit'
}

const BTN_BASE =
  'inline-flex items-center justify-center gap-2 rounded-[2px] px-[18px] py-[10px] font-sans text-[13px] font-semibold transition-all duration-200 hover:-translate-y-px disabled:translate-y-0 disabled:cursor-not-allowed disabled:opacity-40'

export function PrimaryButton({ children, onClick, disabled, className, type = 'button' }: BtnProps) {
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={cn(BTN_BASE, 'bg-petrol text-ivory hover:bg-petrol-deep', className)}
    >
      {children}
    </button>
  )
}

export function AccentButton({ children, onClick, disabled, className, type = 'button' }: BtnProps) {
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={cn(BTN_BASE, 'bg-copper text-ivory hover:bg-copper-light hover:text-ink', className)}
    >
      {children}
    </button>
  )
}

export function SecondaryButton({ children, onClick, disabled, className, type = 'button' }: BtnProps) {
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={cn(
        BTN_BASE,
        'border border-ink/30 bg-transparent text-ink hover:border-ink hover:bg-sand',
        className,
      )}
    >
      {children}
    </button>
  )
}

/* --------------------------------------------------------- page header */

export function PageHeader({
  crumb,
  title,
  sub,
  actions,
}: {
  crumb: string
  title: string
  sub: string
  actions?: ReactNode
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: EASE_PRIMARY }}
      className="mb-8"
    >
      <p className="kicker text-muted">{crumb}</p>
      <div className="mt-3 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-[40px] leading-[1.05] text-ink">{title}</h1>
          <p className="mt-2 max-w-[640px] font-sans text-[15px] leading-[1.6] text-muted">{sub}</p>
        </div>
        {actions && <div className="flex items-center gap-3">{actions}</div>}
      </div>
      <LedgerRule className="mt-6" />
    </motion.div>
  )
}

/* ---------------------------------------------------------------- modal */

export function Modal({
  open,
  onClose,
  children,
  wide = false,
  label,
}: {
  open: boolean
  onClose: () => void
  children: ReactNode
  wide?: boolean
  label: string
}) {
  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open, onClose])

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25, ease: EASE_MICRO }}
          className="fixed inset-0 z-[80] flex items-center justify-center bg-petrol-deep/60 p-6 backdrop-blur-[4px]"
          onClick={onClose}
          role="dialog"
          aria-modal="true"
          aria-label={label}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.97 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.97 }}
            transition={{ duration: 0.25, ease: EASE_PRIMARY }}
            className={cn(
              'relative max-h-[86dvh] w-full overflow-y-auto rounded-[2px] border border-line bg-ivory',
              wide ? 'max-w-[760px]' : 'max-w-[560px]',
            )}
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={onClose}
              aria-label="Close"
              className="absolute right-4 top-4 z-10 text-muted transition-colors hover:text-ink"
            >
              <X className="h-4 w-4" strokeWidth={1.75} />
            </button>
            {children}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

/* --------------------------------------------------------------- drawer */

export function Drawer({
  open,
  onClose,
  children,
  label,
}: {
  open: boolean
  onClose: () => void
  children: ReactNode
  label: string
}) {
  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open, onClose])

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25, ease: EASE_MICRO }}
          className="fixed inset-0 z-[80] bg-petrol-deep/60 backdrop-blur-[4px]"
          onClick={onClose}
          role="dialog"
          aria-modal="true"
          aria-label={label}
        >
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ duration: 0.35, ease: EASE_PRIMARY }}
            className="absolute right-0 top-0 flex h-full w-full max-w-[560px] flex-col border-l border-line bg-ivory"
            onClick={(e) => e.stopPropagation()}
          >
            {children}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

/* ------------------------------------------------------ anomaly diamond */

/** 8px alert diamond anomaly marker (design.md §6.17). */
export function AnomalyDiamond({ className }: { className?: string }) {
  return (
    <motion.span
      initial={{ scale: 1 }}
      animate={{ scale: [1, 1.3, 1] }}
      transition={{ duration: 0.5, ease: EASE_MICRO, delay: 0.3 }}
      className={cn('inline-block h-[8px] w-[8px] rotate-45 bg-alert', className)}
      aria-label="anomaly flag"
      role="img"
    />
  )
}
