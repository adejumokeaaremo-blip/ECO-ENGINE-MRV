/**
 * DQI page charts (dqi.md §3/§4): 12-month trend line with draw-on animation and
 * annotation callouts, plus the 12-point sparkline used in the per-stream table.
 * Chart style per design.md §6.17 — hairline axes, petrol series, Data S labels.
 */
import { useRef } from 'react'
import { motion, useInView } from 'framer-motion'
import { EASE_PRIMARY } from './shared'

const MONTHS = ['Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun']

export interface TrendAnnotation {
  index: number
  text: string
}

export function DqiTrendChart({
  values,
  annotations,
}: {
  values: number[]
  annotations: TrendAnnotation[]
}) {
  const ref = useRef<HTMLDivElement>(null)
  const inView = useInView(ref, { once: true, amount: 0.25 })

  const W = 760
  const H = 280
  const PAD_L = 40
  const PAD_R = 16
  const PAD_T = 28
  const PAD_B = 34

  const min = Math.min(...values) - 3
  const max = Math.max(...values) + 3
  const x = (i: number) => PAD_L + (i / (values.length - 1)) * (W - PAD_L - PAD_R)
  const y = (v: number) => PAD_T + (1 - (v - min) / (max - min)) * (H - PAD_T - PAD_B)

  const points = values.map((v, i) => `${x(i)},${y(v)}`).join(' ')
  const path = values.map((v, i) => `${i === 0 ? 'M' : 'L'} ${x(i)} ${y(v)}`).join(' ')

  const ticks = 4
  const gridVals = Array.from({ length: ticks }, (_, i) => min + ((max - min) * (i + 0.5)) / ticks)

  return (
    <div ref={ref} className="w-full overflow-x-auto">
      <svg viewBox={`0 0 ${W} ${H}`} className="min-w-[640px]" role="img" aria-label="DQI 12-month trend">
        {/* horizontal gridlines (3–4 ticks, line 30%) */}
        {gridVals.map((g, i) => (
          <g key={i}>
            <line x1={PAD_L} x2={W - PAD_R} y1={y(g)} y2={y(g)} stroke="#C9BBA2" strokeOpacity="0.3" strokeWidth="1" />
            <text
              x={PAD_L - 8}
              y={y(g) + 3}
              textAnchor="end"
              fontSize="10"
              fontFamily="'IBM Plex Mono', monospace"
              fill="#5F7168"
            >
              {Math.round(g)}
            </text>
          </g>
        ))}
        {/* axis */}
        <line x1={PAD_L} x2={W - PAD_R} y1={H - PAD_B} y2={H - PAD_B} stroke="#C9BBA2" strokeOpacity="0.6" strokeWidth="1" />
        {MONTHS.map((m, i) => (
          <text
            key={m + i}
            x={x(i)}
            y={H - PAD_B + 18}
            textAnchor="middle"
            fontSize="10"
            fontFamily="'IBM Plex Mono', monospace"
            fill="#5F7168"
          >
            {m}
          </text>
        ))}
        <text
          x={x(0)}
          y={H - 6}
          textAnchor="middle"
          fontSize="9"
          fontFamily="'IBM Plex Mono', monospace"
          fill="#5F7168"
          opacity="0.7"
        >
          2025
        </text>
        <text
          x={x(11)}
          y={H - 6}
          textAnchor="middle"
          fontSize="9"
          fontFamily="'IBM Plex Mono', monospace"
          fill="#5F7168"
          opacity="0.7"
        >
          2026
        </text>

        {/* series line — draws on scroll into view */}
        <motion.path
          d={path}
          fill="none"
          stroke="#0F4C5C"
          strokeWidth="2"
          initial={{ pathLength: 0 }}
          animate={inView ? { pathLength: 1 } : {}}
          transition={{ duration: 1.6, ease: EASE_PRIMARY }}
        />
        {/* point nodes — 4px petrol squares, pop after draw */}
        {values.map((v, i) => (
          <motion.rect
            key={i}
            x={x(i) - 2}
            y={y(v) - 2}
            width="4"
            height="4"
            fill="#0F4C5C"
            initial={{ scale: 0, opacity: 0 }}
            animate={inView ? { scale: 1, opacity: 1 } : {}}
            transition={{ duration: 0.3, delay: 1.0 + i * 0.05, ease: EASE_PRIMARY }}
            style={{ transformOrigin: `${x(i)}px ${y(v)}px` }}
          />
        ))}
        <polyline points={points} fill="none" stroke="none" />

        {/* annotations — Data S callouts with hairline leaders */}
        {annotations.map((a, i) => {
          const ax = x(a.index)
          const ay = y(values[a.index])
          const above = values[a.index] >= values[Math.max(0, a.index - 1)]
          const ty = above ? ay - 34 : ay + 22
          return (
            <motion.g
              key={a.index}
              initial={{ opacity: 0 }}
              animate={inView ? { opacity: 1 } : {}}
              transition={{ duration: 0.4, delay: 1.6 + i * 0.15 }}
            >
              <line x1={ax} y1={ay} x2={ax} y2={ty + (above ? 8 : -4)} stroke="#C9BBA2" strokeWidth="1" />
              <text
                x={ax}
                y={ty}
                textAnchor="middle"
                fontSize="10"
                fontFamily="'IBM Plex Mono', monospace"
                fill={above ? '#0F4C5C' : '#A63D2F'}
              >
                {a.text}
              </text>
            </motion.g>
          )
        })}
      </svg>
    </div>
  )
}

/** 12-point sparkline (dqi.md §4) — petrol for rising, copper for flat/estimated. */
export function Sparkline({
  values,
  tone = 'petrol',
  width = 96,
  height = 28,
}: {
  values: number[]
  tone?: 'petrol' | 'copper'
  width?: number
  height?: number
}) {
  const min = Math.min(...values)
  const max = Math.max(...values)
  const range = max - min || 1
  const pts = values
    .map((v, i) => `${(i / (values.length - 1)) * width},${height - 3 - ((v - min) / range) * (height - 6)}`)
    .join(' ')
  return (
    <svg width={width} height={height} aria-hidden="true">
      <motion.polyline
        points={pts}
        fill="none"
        stroke={tone === 'petrol' ? '#0F4C5C' : '#B5651D'}
        strokeWidth="1.5"
        initial={{ pathLength: 0 }}
        whileInView={{ pathLength: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8, ease: EASE_PRIMARY }}
      />
    </svg>
  )
}
