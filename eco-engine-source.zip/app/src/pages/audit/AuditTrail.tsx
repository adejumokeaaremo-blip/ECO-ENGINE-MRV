/**
 * Page 14 — Audit Trail Explorer (`/audit`), audit-trail.md.
 * The shared trust surface: tamper-evident, hash-chained log of every event.
 * Consumes useAuditTrail(); "Verify chain" recomputes via the store's verifyChain().
 */
import { useEffect, useMemo, useState } from 'react'
import { useSearchParams } from 'react-router'
import { AnimatePresence, motion } from 'framer-motion'
import { format } from 'date-fns'
import {
  ArrowDownWideNarrow,
  Check,
  ChevronRight,
  FileCheck,
  KeyRound,
  Loader2,
  Package,
  PenLine,
  RotateCcw,
  Search,
  ShieldCheck,
  Upload,
  X,
  Zap,
} from 'lucide-react'
import { toast } from 'sonner'
import type { LucideIcon } from 'lucide-react'
import StatusChip from '@/components/app/StatusChip'
import HashChip from '@/components/app/HashChip'
import LedgerRule from '@/components/app/LedgerRule'
import DataTable, {
  DataTableCell,
  DataTableEmpty,
  DataTableHead,
  DataTableRow,
} from '@/components/app/DataTable'
import {
  demoHash,
  truncateHash,
  useAuditTrail,
  useRole,
  useSubmissions,
  verifyChain,
  type AuditEntry,
} from '@/lib/store'
import { FACILITIES } from '@/lib/demo-data'
import { cn } from '@/lib/utils'

/* ------------------------------------------------------------- action meta */

type Tint = 'teal' | 'copper' | 'alert' | 'ink'

interface ActionMeta {
  label: string
  icon: LucideIcon
  tint: Tint
}

const ACTION_META: Record<string, ActionMeta> = {
  LOGIN: { label: 'Login', icon: KeyRound, tint: 'ink' },
  UPLOAD_SUBMITTED: { label: 'Upload submitted', icon: Upload, tint: 'ink' },
  AI_ESTIMATE_GENERATED: { label: 'AI estimate generated', icon: Zap, tint: 'copper' },
  SUBMISSION_ACCEPTED: { label: 'Decision — accepted', icon: PenLine, tint: 'teal' },
  SUBMISSION_QUERIED: { label: 'Decision — queried', icon: PenLine, tint: 'copper' },
  SUBMISSION_REJECTED: { label: 'Decision — rejected', icon: PenLine, tint: 'alert' },
  PLAN_VERSION_APPROVED: { label: 'Plan version approved', icon: FileCheck, tint: 'teal' },
  FACILITY_APPROVED: { label: 'Facility approved', icon: ShieldCheck, tint: 'teal' },
  EXPORT_GENERATED: { label: 'Export generated', icon: Package, tint: 'teal' },
  EXPORT_RECEIVED: { label: 'Export received by NIMO', icon: Package, tint: 'teal' },
  PROFILE_UPDATED: { label: 'Profile updated', icon: PenLine, tint: 'ink' },
  SESSION_REVOKED: { label: 'Session revoked', icon: KeyRound, tint: 'alert' },
  DEMO_RESET: { label: 'Demo scenario reset', icon: RotateCcw, tint: 'copper' },
}

function metaOf(action: string): ActionMeta {
  return (
    ACTION_META[action] ?? {
      label: action.toLowerCase().replace(/_/g, ' ').replace(/^\w/, (c) => c.toUpperCase()),
      icon: FileCheck,
      tint: 'ink',
    }
  )
}

const TINT_TEXT: Record<Tint, string> = {
  teal: 'text-petrol',
  copper: 'text-copper',
  alert: 'text-alert',
  ink: 'text-ink',
}

const NODE_FILL: Record<Tint, string> = {
  teal: '#2E8B9A',
  copper: '#B5651D',
  alert: '#A63D2F',
  ink: 'rgba(245,240,230,0.35)',
}

/* ------------------------------------------------------------ filter model */

const ACTOR_OPTIONS = [
  ['all', 'All actors'],
  ['operator', 'Operator'],
  ['verifier', 'Verifier'],
  ['regulator', 'Regulator'],
  ['compiler', 'Compiler'],
  ['system', 'System'],
] as const

const TYPE_OPTIONS = [
  ['all', 'All events'],
  ['login', 'Login'],
  ['submission', 'Submission'],
  ['estimate', 'Estimate'],
  ['decision', 'Decision'],
  ['plan', 'Plan version'],
  ['dqi', 'DQI publication'],
  ['export', 'Export'],
] as const

function typeMatches(type: string, action: string): boolean {
  switch (type) {
    case 'all':
      return true
    case 'login':
      return action === 'LOGIN'
    case 'submission':
      return action === 'UPLOAD_SUBMITTED'
    case 'estimate':
      return action === 'AI_ESTIMATE_GENERATED'
    case 'decision':
      return action.startsWith('SUBMISSION_') && action !== 'UPLOAD_SUBMITTED'
    case 'plan':
      return action.startsWith('PLAN_VERSION')
    case 'dqi':
      return action.startsWith('DQI')
    case 'export':
      return action.startsWith('EXPORT')
    default:
      return true
  }
}

function fmtTs(iso: string): string {
  try {
    return format(new Date(iso), 'dd MMM yyyy HH:mm')
  } catch {
    return iso
  }
}

/* -------------------------------------------------------------- chain strip */

function ChainStrip({
  entries,
  verifying,
  onOpen,
}: {
  entries: AuditEntry[]
  verifying: boolean
  onOpen: (e: AuditEntry) => void
}) {
  const nodes = entries.slice(-14)
  return (
    <div className="relative overflow-hidden rounded-[2px] border border-ivory/10 bg-petrol-deep px-6 py-6">
      <style>{`@keyframes chain-drift { from { transform: translateX(0); } to { transform: translateX(-50%); } }`}</style>
      {/* connecting hairline — draws left→right on load */}
      <motion.div
        className="absolute left-6 right-6 top-[46px] h-px origin-left bg-ivory/20"
        initial={{ scaleX: 0 }}
        animate={{ scaleX: 1 }}
        transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
      />
      <div
        className="flex w-max hover:[animation-play-state:paused]"
        style={{ animation: 'chain-drift 48s linear infinite' }}
      >
        {[0, 1].map((dup) => (
          <div key={dup} className="flex" aria-hidden={dup === 1}>
            {nodes.map((e, i) => {
              const meta = metaOf(e.action)
              const isNewest = i === nodes.length - 1
              const fill = isNewest ? '#B5651D' : NODE_FILL[meta.tint]
              const Icon = meta.icon
              return (
                <div key={`${dup}-${e.seq}`} className="flex w-[88px] shrink-0 flex-col items-center">
                  <Icon className="h-3.5 w-3.5 text-ivory/50" strokeWidth={1.75} />
                  <motion.button
                    type="button"
                    onClick={() => onOpen(e)}
                    title={`${meta.label} · ${fmtTs(e.ts)} — open entry →`}
                    initial={{ scale: 0, opacity: 0 }}
                    animate={
                      verifying
                        ? { scale: 1, opacity: 1, backgroundColor: ['#2E8B9A', fill] }
                        : { scale: 1, opacity: 1 }
                    }
                    transition={
                      verifying
                        ? { duration: 1.5, delay: i * 0.1, backgroundColor: { duration: 0.6, delay: i * 0.1 } }
                        : { duration: 0.3, delay: 0.2 + i * 0.05 }
                    }
                    className={cn(
                      'mt-2 h-3 w-3 rounded-[1px] border border-ivory/30',
                      isNewest && 'animate-pulse',
                    )}
                    style={{ backgroundColor: fill }}
                    aria-label={`${meta.label} · ${e.entity}`}
                  />
                  <span className="data-s mt-2 text-ivory/50">{truncateHash(e.hash).slice(0, 6)}…</span>
                </div>
              )
            })}
          </div>
        ))}
      </div>
    </div>
  )
}

/* ------------------------------------------------------------------- page */

export default function AuditTrail() {
  const audit = useAuditTrail()
  const submissions = useSubmissions()
  const { role } = useRole()
  const [searchParams, setSearchParams] = useSearchParams()
  const [verifying, setVerifying] = useState(false)
  const [lastVerified, setLastVerified] = useState('just now')
  const [shown, setShown] = useState(10)
  const [openEntry, setOpenEntry] = useState<AuditEntry | null>(null)
  const [entryCheck, setEntryCheck] = useState<'idle' | 'checking' | 'valid' | 'broken'>('idle')
  const [presentation, setPresentation] = useState(false)
  const [filtersOpen, setFiltersOpen] = useState(false)

  useEffect(() => {
    const onPres = (ev: Event) => {
      const d = (ev as CustomEvent<{ on: boolean }>).detail
      setPresentation(Boolean(d?.on))
      if (!d?.on) setFiltersOpen(false)
    }
    window.addEventListener('ecoengine:presentation-mode', onPres)
    return () => window.removeEventListener('ecoengine:presentation-mode', onPres)
  }, [])

  /* filter state lives in the URL query string */
  const fActor = searchParams.get('actor') ?? 'all'
  const fType = searchParams.get('type') ?? 'all'
  const fFacility = searchParams.get('facility') ?? 'all'
  const fFrom = searchParams.get('from') ?? ''
  const fTo = searchParams.get('to') ?? ''
  const fQ = searchParams.get('q') ?? ''

  const setParam = (key: string, value: string) => {
    const next = new URLSearchParams(searchParams)
    if (value && value !== 'all') next.set(key, value)
    else next.delete(key)
    setSearchParams(next, { replace: true })
    setShown(10)
  }

  /* deep link: /audit?entry=<seq> */
  useEffect(() => {
    const seq = searchParams.get('entry')
    if (seq) {
      const hit = audit.find((e) => String(e.seq) === seq)
      if (hit) {
        setOpenEntry(hit)
        setEntryCheck('idle')
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const subFacility = useMemo(() => {
    const m = new Map<string, string>()
    submissions.forEach((s) => m.set(s.id, s.facilityId))
    return m
  }, [submissions])

  const facilityOf = (e: AuditEntry): string | null => {
    if (FACILITIES.some((f) => f.id === e.entity)) return e.entity
    return subFacility.get(e.entity) ?? null
  }

  const filtered = useMemo(() => {
    const q = fQ.trim().toLowerCase()
    return audit
      .filter((e) => (fActor === 'all' ? true : e.role === fActor))
      .filter((e) => typeMatches(fType, e.action))
      .filter((e) => (fFacility === 'all' ? true : facilityOf(e) === fFacility))
      .filter((e) => (fFrom ? e.ts.slice(0, 10) >= fFrom : true))
      .filter((e) => (fTo ? e.ts.slice(0, 10) <= fTo : true))
      .filter((e) =>
        q
          ? e.hash.toLowerCase().includes(q) ||
            e.entity.toLowerCase().includes(q) ||
            e.actor.toLowerCase().includes(q) ||
            e.detail.toLowerCase().includes(q)
          : true,
      )
      .slice()
      .sort((a, b) => b.seq - a.seq)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [audit, fActor, fType, fFacility, fFrom, fTo, fQ, subFacility])

  const visible = filtered.slice(0, shown)

  const activeChips: Array<{ key: string; label: string }> = []
  if (fActor !== 'all') activeChips.push({ key: 'actor', label: `Actor: ${ACTOR_OPTIONS.find(([v]) => v === fActor)?.[1] ?? fActor}` })
  if (fType !== 'all') activeChips.push({ key: 'type', label: `Event: ${TYPE_OPTIONS.find(([v]) => v === fType)?.[1] ?? fType}` })
  if (fFacility !== 'all') activeChips.push({ key: 'facility', label: `Facility: ${fFacility}` })
  if (fFrom) activeChips.push({ key: 'from', label: `From: ${fFrom}` })
  if (fTo) activeChips.push({ key: 'to', label: `To: ${fTo}` })
  if (fQ.trim()) activeChips.push({ key: 'q', label: `“${fQ.trim()}”` })

  const runVerify = () => {
    if (verifying) return
    setVerifying(true)
    setTimeout(() => {
      const broken = verifyChain()
      setVerifying(false)
      setLastVerified('just now')
      if (broken === null) {
        toast.success(`Chain verified — ${audit.length}/${audit.length} hashes valid`)
      } else {
        toast.error(`Chain broken at entry #${broken} — hashes after it no longer validate.`)
      }
    }, 1600)
  }

  const openDrawer = (e: AuditEntry) => {
    setOpenEntry(e)
    setEntryCheck('idle')
  }

  const verifyEntry = () => {
    if (!openEntry || entryCheck === 'checking') return
    setEntryCheck('checking')
    setTimeout(() => {
      const recomputed = demoHash(
        `${openEntry.prevHash}|${openEntry.ts}|${openEntry.actor}|${openEntry.action}|${openEntry.entity}|${openEntry.detail}`,
      )
      setEntryCheck(recomputed === openEntry.hash ? 'valid' : 'broken')
    }, 600)
  }

  /* payload visibility: other organisations' evidence stays restricted (audit-trail.md §interactions) */
  const restrictedPayload = (e: AuditEntry): boolean => {
    if (role !== 'operator') return false
    return facilityOf(e) === 'FAC-KOG-002'
  }

  const nextOf = (e: AuditEntry): AuditEntry | null => audit.find((x) => x.seq === e.seq + 1) ?? null

  const filterBar = (
    <div className="flex flex-col gap-3">
      <div className="flex flex-wrap items-end gap-3">
        <label className="flex flex-col gap-1.5">
          <span className="kicker text-muted">Actor</span>
          <select
            value={fActor}
            onChange={(e) => setParam('actor', e.target.value)}
            className="rounded-[2px] border border-line bg-ivory px-3 py-2 font-sans text-[13px] text-ink"
          >
            {ACTOR_OPTIONS.map(([v, l]) => (
              <option key={v} value={v}>{l}</option>
            ))}
          </select>
        </label>
        <label className="flex flex-col gap-1.5">
          <span className="kicker text-muted">Event type</span>
          <select
            value={fType}
            onChange={(e) => setParam('type', e.target.value)}
            className="rounded-[2px] border border-line bg-ivory px-3 py-2 font-sans text-[13px] text-ink"
          >
            {TYPE_OPTIONS.map(([v, l]) => (
              <option key={v} value={v}>{l}</option>
            ))}
          </select>
        </label>
        <label className="flex flex-col gap-1.5">
          <span className="kicker text-muted">Facility</span>
          <select
            value={fFacility}
            onChange={(e) => setParam('facility', e.target.value)}
            className="rounded-[2px] border border-line bg-ivory px-3 py-2 font-mono text-[13px] text-ink"
          >
            <option value="all">All facilities</option>
            {FACILITIES.map((f) => (
              <option key={f.id} value={f.id}>{f.id}</option>
            ))}
          </select>
        </label>
        <label className="flex flex-col gap-1.5">
          <span className="kicker text-muted">From</span>
          <input
            type="date"
            value={fFrom}
            onChange={(e) => setParam('from', e.target.value)}
            className="rounded-[2px] border border-line bg-ivory px-3 py-2 font-mono text-[12px] text-ink"
          />
        </label>
        <label className="flex flex-col gap-1.5">
          <span className="kicker text-muted">To</span>
          <input
            type="date"
            value={fTo}
            onChange={(e) => setParam('to', e.target.value)}
            className="rounded-[2px] border border-line bg-ivory px-3 py-2 font-mono text-[12px] text-ink"
          />
        </label>
        <label className="flex min-w-[220px] flex-1 flex-col gap-1.5">
          <span className="kicker text-muted">Search hash / ID</span>
          <span className="relative">
            <Search className="absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted" strokeWidth={1.75} />
            <input
              type="text"
              value={fQ}
              onChange={(e) => setParam('q', e.target.value)}
              placeholder="0x9f2c… · SUB-2606-114"
              className="w-full rounded-[2px] border border-line bg-ivory py-2 pl-9 pr-3 font-mono text-[12px] text-ink placeholder:text-muted/60"
            />
          </span>
        </label>
      </div>
      {/* active filter chips */}
      {activeChips.length > 0 && (
        <div className="flex flex-wrap gap-2">
          <AnimatePresence>
            {activeChips.map((c) => (
              <motion.button
                key={c.key}
                type="button"
                onClick={() => setParam(c.key, '')}
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="flex items-center gap-1.5 rounded-[2px] border border-copper px-2.5 py-1 font-sans text-[11px] font-semibold text-copper"
              >
                {c.label}
                <X className="h-3 w-3" strokeWidth={2} />
              </motion.button>
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  )

  return (
    <div className="flex flex-col gap-8">
      {/* §1 — header */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        className="flex flex-wrap items-end justify-between gap-4"
      >
        <div>
          <p className="kicker text-muted">{role} / Audit trail</p>
          <h1 className="mt-2 font-display text-[40px] leading-[1.05] text-ink">Audit trail.</h1>
          <p className="mt-3 max-w-[560px] font-sans text-[15px] leading-[1.6] text-muted">
            Every event, hash-chained to the one before it. Break any link, and the chain tells you.
          </p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 rounded-[2px] border border-line/60 bg-ivory px-3 py-2">
            <motion.span
              className="h-2 w-2 rounded-full"
              style={{ backgroundColor: '#2E8B9A' }}
              animate={{ opacity: [1, 0.5, 1] }}
              transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
            />
            <span className="data-s text-muted">
              Chain intact · {audit.length} entries · last verified {lastVerified}
            </span>
          </div>
          <button
            type="button"
            onClick={runVerify}
            disabled={verifying}
            className="flex items-center gap-2 rounded-[2px] border border-ink/30 px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ink transition-all duration-200 hover:-translate-y-px hover:border-ink hover:bg-sand disabled:translate-y-0 disabled:opacity-40"
          >
            {verifying ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" strokeWidth={1.75} />
            ) : (
              <ShieldCheck className="h-3.5 w-3.5" strokeWidth={1.75} />
            )}
            {verifying ? 'Verifying…' : 'Verify chain'}
          </button>
        </div>
      </motion.div>

      {/* §2 — chain visual */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
      >
        <ChainStrip entries={audit} verifying={verifying} onOpen={openDrawer} />
      </motion.div>

      {/* §3 — filter bar (collapses behind "Advanced" in presentation mode) */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.15, ease: [0.22, 1, 0.36, 1] }}
      >
        {presentation ? (
          <div className="rounded-[2px] border border-line/60 bg-ivory">
            <button
              type="button"
              onClick={() => setFiltersOpen((o) => !o)}
              className="flex w-full items-center justify-between px-4 py-3"
            >
              <span className="kicker text-muted">Advanced — filters</span>
              <ChevronRight className={cn('h-4 w-4 text-muted transition-transform', filtersOpen && 'rotate-90')} strokeWidth={1.75} />
            </button>
            {filtersOpen && <div className="border-t border-line/40 p-4">{filterBar}</div>}
          </div>
        ) : (
          filterBar
        )}
      </motion.div>

      {/* §4 — the ledger table */}
      <section>
        <DataTable>
          <DataTableHead columns={['#', 'Timestamp', 'Actor', 'Event', 'Subject', 'Hash', '']} />
          <tbody>
            {visible.length === 0 && (
              <DataTableEmpty
                colSpan={7}
                guidance="No chain entries match the active filters. Clear a filter chip to widen the record."
              />
            )}
            {visible.map((e, i) => {
              const meta = metaOf(e.action)
              const Icon = meta.icon
              return (
                <DataTableRow key={e.seq} onClick={() => openDrawer(e)}>
                  <DataTableCell className="text-muted">
                    <motion.span
                      initial={{ opacity: 0, y: 6 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: Math.min(i, 12) * 0.02 }}
                    >
                      {e.seq}
                    </motion.span>
                  </DataTableCell>
                  <DataTableCell>{fmtTs(e.ts)}</DataTableCell>
                  <DataTableCell mono={false}>
                    <span className="font-sans text-[13px] text-ink">{e.actor}</span>
                    <span className="data-s ml-2 text-muted">{e.role}</span>
                  </DataTableCell>
                  <DataTableCell mono={false}>
                    <span className={cn('flex items-center gap-2 font-sans text-[13px]', TINT_TEXT[meta.tint])}>
                      <Icon className="h-3.5 w-3.5 shrink-0" strokeWidth={1.75} />
                      {meta.label}
                    </span>
                  </DataTableCell>
                  <DataTableCell>{e.entity}</DataTableCell>
                  <DataTableCell mono={false}>
                    <HashChip hash={e.hash} />
                  </DataTableCell>
                  <DataTableCell>
                    <ChevronRight className="h-4 w-4 text-muted" strokeWidth={1.75} />
                  </DataTableCell>
                </DataTableRow>
              )
            })}
          </tbody>
        </DataTable>
        <div className="mt-4 flex items-center justify-between">
          <p className="font-sans text-[12px] text-muted">
            All roles see the same chain — transparency by construction. Payload details of other
            organisations' evidence remain access-controlled.
          </p>
          {shown < filtered.length && (
            <button
              type="button"
              onClick={() => setShown((s) => s + 25)}
              className="flex items-center gap-2 rounded-[2px] border border-ink/30 px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ink transition-all duration-200 hover:-translate-y-px hover:border-ink hover:bg-sand"
            >
              <ArrowDownWideNarrow className="h-3.5 w-3.5" strokeWidth={1.75} />
              Load older ({filtered.length - shown} more)
            </button>
          )}
        </div>
      </section>

      {/* §6 — integrity explainer (dark band) */}
      <section className="-mx-8 bg-petrol-deep px-8 py-12">
        <div className="mx-auto max-w-[1200px]">
          <LedgerRule dark className="mb-4" />
          <p className="kicker text-copper-light">Why this matters</p>
          <h2 className="mt-4 max-w-[720px] font-display text-[28px] leading-[1.1] text-ivory">
            {'Trust is not a promise. It is a property of the record.'.split(' ').map((w, i) => (
              <motion.span
                key={i}
                className="inline-block"
                initial={{ opacity: 0, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-25%' }}
                transition={{ duration: 0.4, delay: i * 0.03 }}
              >
                {w}&nbsp;
              </motion.span>
            ))}
          </h2>
          <p className="mt-5 max-w-[720px] font-sans text-[14px] leading-[1.6] text-ivory/75">
            Each entry embeds the hash of the entry before it. Altering history — a figure, a
            decision, a timestamp — invalidates every hash that follows, visibly. No administrator,
            operator, or ECO ENGINE engineer can quietly rewrite the record.
          </p>
        </div>
      </section>

      {/* §5 — entry detail drawer */}
      <AnimatePresence>
        {openEntry && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25 }}
              onClick={() => setOpenEntry(null)}
              className="fixed inset-0 z-50 bg-petrol-deep/60 backdrop-blur-[4px]"
            />
            <motion.aside
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
              className="fixed right-0 top-0 z-50 flex h-full w-full max-w-[560px] flex-col border-l border-line bg-ivory"
            >
              {(() => {
                const meta = metaOf(openEntry.action)
                const isDecision = openEntry.action.startsWith('SUBMISSION_') && openEntry.action !== 'UPLOAD_SUBMITTED'
                const chipStatus =
                  openEntry.action === 'SUBMISSION_ACCEPTED'
                    ? 'Accepted'
                    : openEntry.action === 'SUBMISSION_REJECTED'
                      ? 'Rejected'
                      : 'Queried'
                const next = nextOf(openEntry)
                return (
                  <>
                    <div className="flex items-start justify-between border-b border-line/60 p-6">
                      <div>
                        <p className="kicker text-muted">Entry #{openEntry.seq}</p>
                        <h3 className="mt-2 font-sans text-[18px] font-semibold tracking-[0.01em] text-ink">
                          {meta.label}
                        </h3>
                        <p className="data-s mt-1 text-muted">{openEntry.entity}</p>
                      </div>
                      <div className="flex items-center gap-3">
                        {isDecision && <StatusChip status={chipStatus} />}
                        <button
                          type="button"
                          onClick={() => setOpenEntry(null)}
                          aria-label="Close"
                          className="rounded-[2px] p-1.5 text-muted transition-colors hover:text-ink"
                        >
                          <X className="h-4 w-4" strokeWidth={1.75} />
                        </button>
                      </div>
                    </div>
                    <div className="flex-1 overflow-y-auto p-6">
                      <div className="flex flex-col gap-5">
                        <div className="flex flex-col gap-1 border-b border-line/40 pb-3">
                          <span className="kicker text-muted">Actor</span>
                          <span className="font-sans text-[14px] text-ink">
                            {openEntry.actor}
                            <span className="ml-2 font-sans text-[13px] text-muted">
                              {openEntry.role === 'system' ? 'ECO ENGINE engine (system actor)' : `${openEntry.role} seat`}
                            </span>
                          </span>
                        </div>
                        <div className="flex flex-col gap-1 border-b border-line/40 pb-3">
                          <span className="kicker text-muted">Timestamp</span>
                          <span className="font-mono text-[13px] text-ink">
                            {openEntry.ts} <span className="text-muted">· Africa/Lagos</span>
                          </span>
                        </div>
                        <div className="flex flex-col gap-1 border-b border-line/40 pb-3">
                          <span className="kicker text-muted">Subject</span>
                          <span className="font-mono text-[13px] text-petrol">{openEntry.entity}</span>
                        </div>
                        <div className="flex flex-col gap-1 border-b border-line/40 pb-3">
                          <span className="kicker text-muted">Payload summary</span>
                          {restrictedPayload(openEntry) ? (
                            <span className="font-sans text-[13px] italic text-muted">
                              Restricted payload — evidence details of another organisation are
                              access-controlled.
                            </span>
                          ) : (
                            <span className="font-sans text-[14px] leading-[1.6] text-ink">{openEntry.detail}</span>
                          )}
                        </div>

                        {/* chain block — the tamper-evidence visual */}
                        <div className="rounded-[2px] border border-line/60 bg-sand p-4">
                          <p className="kicker text-muted">Chain block</p>
                          <div className="mt-3 flex flex-col">
                            {[
                              { label: 'prev hash', hash: openEntry.prevHash, highlight: false },
                              { label: 'entry hash', hash: openEntry.hash, highlight: true },
                              { label: 'next hash', hash: next ? next.hash : '— chain head —', highlight: false },
                            ].map((row, i) => (
                              <motion.div
                                key={row.label}
                                initial={{ opacity: 0, y: 8 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ duration: 0.35, delay: i * 0.12 }}
                                className="relative flex items-center gap-3 py-2"
                              >
                                {i < 2 && (
                                  <motion.span
                                    className="absolute bottom-[-8px] left-[52px] h-[16px] w-px origin-top bg-line"
                                    initial={{ scaleY: 0 }}
                                    animate={{ scaleY: 1 }}
                                    transition={{ duration: 0.3, delay: i * 0.12 + 0.15 }}
                                  />
                                )}
                                <span className="data-s w-[72px] shrink-0 text-muted">{row.label}</span>
                                <span
                                  className={cn(
                                    'flex-1 break-all rounded-[2px] px-2 py-1 font-mono text-[11px] tracking-[0.02em]',
                                    row.highlight ? 'bg-copper/10 text-copper' : 'bg-ink/5 text-muted',
                                  )}
                                >
                                  {row.hash}
                                </span>
                                {row.hash.startsWith('0x') && (
                                  <span className="flex shrink-0 items-center gap-1 font-sans text-[10px] font-semibold uppercase tracking-[0.12em] text-petrol">
                                    <Check className="h-3 w-3" strokeWidth={2.5} /> valid
                                  </span>
                                )}
                              </motion.div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center justify-between border-t border-line/60 p-6">
                      <button
                        type="button"
                        onClick={verifyEntry}
                        disabled={entryCheck === 'checking'}
                        className="link-sweep flex items-center gap-2 font-sans text-[13px] font-semibold text-petrol"
                      >
                        {entryCheck === 'checking' && (
                          <Loader2 className="h-3.5 w-3.5 animate-spin" strokeWidth={1.75} />
                        )}
                        Verify this entry
                      </button>
                      {entryCheck === 'valid' && (
                        <span className="flex items-center gap-1.5 font-sans text-[12px] font-semibold text-petrol">
                          <Check className="h-3.5 w-3.5" strokeWidth={2.5} /> hash matches chain
                        </span>
                      )}
                      {entryCheck === 'broken' && (
                        <span className="flex items-center gap-1.5 font-sans text-[12px] font-semibold text-alert">
                          <X className="h-3.5 w-3.5" strokeWidth={2.5} /> hash mismatch
                        </span>
                      )}
                    </div>
                  </>
                )
              })()}
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </div>
  )
}
