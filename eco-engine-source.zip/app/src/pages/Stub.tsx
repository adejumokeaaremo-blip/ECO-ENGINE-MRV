/**
 * Route stub — simple centered heading with the page name.
 * Page agents replace these with the real screens (design.md §7).
 */
export default function Stub({ name }: { name: string }) {
  return (
    <div className="flex min-h-[50vh] flex-col items-center justify-center gap-3 text-center">
      <p className="kicker text-muted">Route stub</p>
      <h1 className="font-display text-[40px] leading-none text-ink">{name}</h1>
    </div>
  )
}
