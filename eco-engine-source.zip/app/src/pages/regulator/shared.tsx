/**
 * Regulator (NCCC) shared building blocks — read-only oversight seat.
 * Design: design.md §2 palette, §3 typography, §4 ledger rule, §6 shared components.
 */
import type { ReactNode } from 'react'
import { useEffect, useRef, useState } from 'react'
import { motion } from 'framer-motion'
import { cn } from '@/lib/utils'

/* ------------------------------------------------------------- motion */

export const EASE = [0.22, 1, 0.36, 1] as [number, number, number, number]
export const EASE_MICRO = [0.4, 0, 0.2, 1] as [number, number, number, number]

export const riseVariants = {
  hidden: { opacity: 0, y: 16 },
  show: (i: number = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: EASE, delay: i * 0.06 },
  }),
}

/* -------------------------------------------------------------- panel */

/** 1px-ruled panel, 2px radius, kicker header (design.md §4/§5). */
export function Panel({
  kicker,
  right,
  children,
  className,
  bodyClassName,
}: {
  kicker?: string
  right?: ReactNode
  children: ReactNode
  className?: string
  bodyClassName?: string
}) {
  return (
    <section className={cn('rounded-[2px] border border-line/60 bg-ivory', className)}>
      {(kicker || right) && (
        <header className="flex flex-wrap items-center justify-between gap-3 border-b border-line/40 px-5 py-3.5">
          {kicker ? <p className="kicker text-muted">{kicker}</p> : <span />}
          {right}
        </header>
      )}
      <div className={cn('p-5', bodyClassName)}>{children}</div>
    </section>
  )
}

/* ------------------------------------------------------------ mini DQI */

/** Inline mini DQI arc for tables (petrol ≥80 · copper 60–79 · alert <60). */
export function MiniDqi({ value, className }: { value: number; className?: string }) {
  const color = value >= 80 ? '#0F4C5C' : value >= 60 ? '#B5651D' : '#A63D2F'
  const r = 15
  const cx = 19
  const cy = 19
  const arcLen = Math.PI * r
  const dash = (Math.max(0, Math.min(100, value)) / 100) * arcLen
  const d = `M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}`
  return (
    <span className={cn('inline-flex items-center gap-2', className)}>
      <svg width="38" height="22" viewBox="0 0 38 22" aria-hidden="true">
        <path d={d} fill="none" stroke="#C9BBA2" strokeWidth="3" />
        <path d={d} fill="none" stroke={color} strokeWidth="3" strokeDasharray={`${dash} ${arcLen}`} />
      </svg>
      <span className="font-mono text-[13px] leading-none text-ink">{value}</span>
    </span>
  )
}

/* ------------------------------------------------------- alert glyphs */

/** 8px status diamond (design.md §6.17 anomaly marker language). */
export function Diamond({ tone, className }: { tone: 'alert' | 'copper'; className?: string }) {
  return (
    <span
      aria-hidden="true"
      className={cn(
        'inline-block h-2 w-2 shrink-0 rotate-45',
        tone === 'alert' ? 'bg-alert' : 'bg-copper',
        className,
      )}
    />
  )
}

/* ---------------------------------------------------------- formatters */

export function fmt(n: number): string {
  return n.toLocaleString('en-US')
}

export function dqiTextColor(v: number): string {
  return v >= 80 ? 'text-petrol' : v >= 60 ? 'text-copper' : 'text-alert'
}

/* ------------------------------------------------------------ reveal */

/** Section wrapper that rises into view once (20% viewport trigger, §5). */
export function Reveal({
  children,
  className,
  delay = 0,
}: {
  children: ReactNode
  className?: string
  delay?: number
}) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{ duration: 0.6, ease: EASE, delay }}
    >
      {children}
    </motion.div>
  )
}

/* ------------------------------------------------ count-up (in-view) */

/**
 * Decimal-aware count-up that starts when the element scrolls into view
 * (design.md §5 — 1.2s ease-primary, 40% threshold, reduced-motion safe).
 */
export function useCountUpInView(target: number, duration = 1400) {
  const reduced =
    typeof window !== 'undefined' &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches
  const [value, setValue] = useState(reduced ? target : 0)
  const ref = useRef<HTMLSpanElement | null>(null)
  const started = useRef(false)
  useEffect(() => {
    const el = ref.current
    if (!el || reduced) return
    const io = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !started.current) {
          started.current = true
          const t0 = performance.now()
          const tick = (now: number) => {
            const p = Math.min(1, (now - t0) / duration)
            const eased = 1 - Math.pow(1 - p, 3)
            setValue(target * eased)
            if (p < 1) requestAnimationFrame(tick)
            else setValue(target)
          }
          requestAnimationFrame(tick)
          io.disconnect()
        }
      },
      { threshold: 0.4 },
    )
    io.observe(el)
    return () => io.disconnect()
  }, [target, duration, reduced])
  return [value, ref] as const
}

/** KPI stat on the dark band (design.md §6.9 — ivory numerals, copper deltas). */
export function DarkStat({
  label,
  value,
  format,
  suffix,
  sub,
  delta,
  delay = 0,
}: {
  label: string
  value: number
  format: (v: number) => string
  suffix?: string
  sub?: string
  delta?: string
  delay?: number
}) {
  const [v, ref] = useCountUpInView(value, 1400)
  return (
    <div className="flex flex-col gap-2">
      <span className="kicker text-ivory/50">{label}</span>
      <span ref={ref} className="font-display text-[48px] leading-none text-ivory md:text-[64px]">
        {format(v)}
        {suffix ? <span className="text-[0.5em]">{suffix}</span> : null}
      </span>
      {(sub || delta) && (
        <motion.span
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: delay + 0.4 }}
          className="font-sans text-[13px] leading-[1.5] text-ivory/60"
        >
          {delta && <span className="mr-2 font-mono text-[12px] text-copper-light">▲ {delta}</span>}
          {sub}
        </motion.span>
      )}
    </div>
  )
}
