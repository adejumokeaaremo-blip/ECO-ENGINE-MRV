/**
 * Page 10 — Regulator National Dashboard (`/regulator`).
 * NCCC read-only oversight: portfolio KPIs (dark band), DQI distribution,
 * Nigeria map with facility pins, verification funnel, sector split, alerts feed.
 * Persona: A. Bello — Deputy Director, MRV Directorate, NCCC. All read-only.
 */
import { useMemo, useState } from 'react'
import { Link, useNavigate } from 'react-router'
import { AnimatePresence, motion } from 'framer-motion'
import { AlertTriangle, ChevronDown, Clock } from 'lucide-react'
import AILabel from '@/components/app/AILabel'
import LedgerRule from '@/components/app/LedgerRule'
import StatusChip from '@/components/app/StatusChip'
import DataTable, {
  DataTableCell,
  DataTableHead,
  DataTableRow,
} from '@/components/app/DataTable'
import { useFacilities, useSubmissions, useDqi } from '@/lib/store'
import type { Facility } from '@/lib/demo-data'
import { cn } from '@/lib/utils'
import { DarkStat, Diamond, EASE, MiniDqi, Panel, Reveal, fmt } from './shared'

/* --------------------------------------------- page constants (design) */

const PERIODS = ['FY Jul 2025–Jun 2026', 'FY Jul 2026–Jun 2027 (not started)'] as const

const FUNNEL = [
  { stage: 'Submitted', value: 156, width: 100, fill: 'bg-petrol/60' },
  { stage: 'AI-estimated', value: 156, width: 100, fill: 'bg-copper/70' },
  { stage: 'Human-verified', value: 149, width: 95.5, fill: 'bg-petrol/85' },
  { stage: 'In official record', value: 149, width: 95.5, fill: 'bg-petrol' },
] as const

const SECTOR_SPLIT = [
  { category: '1.B.2 Oil & natural gas (flaring)', value: 247960 },
  { category: '1.A.1 Energy industries', value: 136852 },
  { category: '2.A.1 Cement production', value: 1131000 },
] as const
const SECTOR_TOTAL = 1515812

/** Pending AI-estimate totals per facility (page design §5, verbatim). */
const PENDING_TCO2E: Record<string, string> = {
  'FAC-RIV-004': '5,190',
  'FAC-KOG-002': '90,002',
}
const OPEN_FLAGS: Record<string, number> = {
  'FAC-RIV-004': 1,
  'FAC-KOG-002': 2,
}

/** Map pin positions (% of the nigeria-map.svg viewBox 1200×900 copper pins). */
const PIN_POS: Record<string, { x: number; y: number }> = {
  'FAC-RIV-004': { x: 33.8, y: 84.5 }, // Rivers State (south)
  'FAC-KOG-002': { x: 32.4, y: 58.5 }, // Kogi State (central)
}

const ALERTS = [
  {
    tone: 'alert' as const,
    kind: 'diamond' as const,
    text: 'Anomaly — flaring intensity +45% · NigerDelta FS-4 · Mar 2026 · pending verification',
    ts: 'flag raised 15 Apr 2026 08:12',
    to: '/regulator/facilities/FAC-RIV-004',
  },
  {
    tone: 'copper' as const,
    kind: 'diamond' as const,
    text: 'Query open 3 days — clinker Feb 2026 · Sahel Cement L2',
    ts: 'queried 12 Jul 2026 09:18',
    to: '/regulator/facilities/FAC-KOG-002',
  },
  {
    tone: 'copper' as const,
    kind: 'clock' as const,
    text: 'Calibration due in 62 days — meter FL-201 · NigerDelta FS-4',
    ts: 'due 15 Sep 2026',
    to: '/regulator/facilities/FAC-RIV-004',
  },
  {
    tone: 'alert' as const,
    kind: 'clock' as const,
    text: 'June 2026 diesel upload not yet received — due today · NigerDelta FS-4',
    ts: '15 Jul 2026 · due today',
    to: '/regulator/compliance',
    pulse: true,
  },
]

/* ---------------------------------------------------- DQI histogram (§3) */

function DqiHistogram() {
  // Bins 60–69 / 70–79 / 80–89 / 90–100; FS-4 = 86, SCW-L2 = 71; mean 78.5.
  const bins = [
    { label: '60–69', count: 0, note: null as string | null },
    { label: '70–79', count: 1, note: 'SCW-L2 · 71' },
    { label: '80–89', count: 1, note: 'FS-4 · 86' },
    { label: '90–100', count: 0, note: null },
  ]
  const W = 460
  const H = 230
  const padL = 34
  const padB = 30
  const padT = 30
  const plotW = W - padL - 16
  const plotH = H - padT - padB
  const binW = plotW / 4
  const yMax = 1
  const y = (v: number) => padT + plotH - (v / yMax) * plotH
  // mean line at 78.5 across the 60–100 bin span
  const meanX = padL + ((78.5 - 60) / 40) * plotW

  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img" aria-label="DQI distribution histogram">
      {/* horizontal gridlines only, line 30% (§6.17) */}
      {[0, 0.5, 1].map((g) => (
        <line
          key={g}
          x1={padL}
          x2={W - 16}
          y1={y(g)}
          y2={y(g)}
          stroke="#C9BBA2"
          strokeOpacity={g === 0 ? 0.7 : 0.3}
          strokeWidth="1"
        />
      ))}
      {[0, 1].map((t) => (
        <text
          key={t}
          x={padL - 8}
          y={y(t) + 3}
          textAnchor="end"
          fontSize="10"
          fontFamily="'IBM Plex Mono', monospace"
          fill="#5F7168"
        >
          {t}
        </text>
      ))}
      {/* bars — grow stagger 0.08s */}
      {bins.map((b, i) => {
        const bw = binW * 0.58
        const bx = padL + i * binW + (binW - bw) / 2
        const bh = (b.count / yMax) * plotH
        return (
          <g key={b.label}>
            {b.count > 0 && (
              <motion.rect
                x={bx}
                y={y(b.count)}
                width={bw}
                height={bh}
                rx={1}
                fill="#0F4C5C"
                style={{ transformBox: 'fill-box', transformOrigin: 'bottom' }}
                initial={{ scaleY: 0 }}
                whileInView={{ scaleY: 1 }}
                viewport={{ once: true, amount: 0.4 }}
                transition={{ duration: 0.7, ease: EASE, delay: i * 0.08 }}
              />
            )}
            {b.note && (
              <motion.text
                x={bx + bw / 2}
                y={y(b.count) - 8}
                textAnchor="middle"
                fontSize="10"
                fontFamily="'IBM Plex Mono', monospace"
                fill="#1C2B28"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: 0.5 + i * 0.08 }}
              >
                {b.note}
              </motion.text>
            )}
            <text
              x={padL + i * binW + binW / 2}
              y={H - 12}
              textAnchor="middle"
              fontSize="10"
              fontFamily="'IBM Plex Mono', monospace"
              fill="#5F7168"
            >
              {b.label}
            </text>
          </g>
        )
      })}
      {/* mean line — dashed copper at 78.5 */}
      <motion.line
        x1={meanX}
        x2={meanX}
        y1={padT - 6}
        y2={y(0)}
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8, ease: EASE, delay: 0.4 }}
        stroke="#B5651D"
        strokeWidth="1.5"
        strokeDasharray="4 4"
      />
      <text
        x={meanX + 6}
        y={padT - 10}
        fontSize="10"
        letterSpacing="1.5"
        fontFamily="'IBM Plex Mono', monospace"
        fill="#B5651D"
      >
        MEAN 78.5
      </text>
      <text
        x={padL}
        y={H - 0}
        fontSize="9"
        letterSpacing="1.5"
        fontFamily="Liter, sans-serif"
        fontWeight="600"
        fill="#5F7168"
      >
        FACILITIES PER BIN
      </text>
    </svg>
  )
}

/* --------------------------------------------------------- map panel */

function MapPanel({ facilities }: { facilities: Facility[] }) {
  const navigate = useNavigate()
  const [hovered, setHovered] = useState<string | null>(null)
  const hoveredFacility = facilities.find((f) => f.id === hovered) ?? null

  return (
    <Panel
      kicker="Facilities by state"
      className="h-full"
      bodyClassName="flex h-full flex-col"
    >
      <motion.div
        className="relative flex-1"
        initial={{ opacity: 0, scale: 0.98 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true, amount: 0.2 }}
        transition={{ duration: 0.8, ease: EASE }}
      >
        <img src="/nigeria-map.svg" alt="Outline map of Nigeria with facility pins" className="w-full" />
        {facilities.map((f, i) => {
          const pos = PIN_POS[f.id]
          if (!pos) return null
          return (
            <button
              key={f.id}
              type="button"
              onClick={() => navigate(`/regulator/facilities/${f.id}`)}
              onMouseEnter={() => setHovered(f.id)}
              onMouseLeave={() => setHovered(null)}
              onFocus={() => setHovered(f.id)}
              onBlur={() => setHovered(null)}
              aria-label={`Drill down — ${f.name}`}
              className="group absolute -translate-x-1/2 -translate-y-1/2 p-2"
              style={{ left: `${pos.x}%`, top: `${pos.y}%` }}
            >
              {/* one-time ring pulse, stagger 0.25s */}
              <motion.span
                className="absolute left-1/2 top-1/2 h-6 w-6 -translate-x-1/2 -translate-y-1/2 border border-copper"
                initial={{ scale: 0.6, opacity: 0.9 }}
                whileInView={{ scale: 2, opacity: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, ease: EASE, delay: 0.3 + i * 0.25 }}
              />
              <span className="block h-3 w-3 bg-copper transition-transform duration-200 group-hover:scale-125" />
            </button>
          )
        })}

        {/* hover tooltip card */}
        <AnimatePresence>
          {hoveredFacility && PIN_POS[hoveredFacility.id] && (
            <motion.div
              key={hoveredFacility.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 8 }}
              transition={{ duration: 0.25, ease: EASE }}
              className="pointer-events-none absolute z-10 w-[240px] rounded-[2px] border border-line bg-ivory p-4"
              style={{
                left: `${Math.min(PIN_POS[hoveredFacility.id].x + 3, 58)}%`,
                top: `${Math.max(PIN_POS[hoveredFacility.id].y - 34, 2)}%`,
              }}
            >
              <p className="font-sans text-[13px] font-semibold text-ink">{hoveredFacility.name}</p>
              <p className="mt-0.5 font-sans text-[11px] text-muted">
                {hoveredFacility.sector} · {hoveredFacility.state}
              </p>
              <div className="mt-3 flex items-end justify-between gap-3">
                <div>
                  <p className="kicker text-muted">Verified tCO₂e</p>
                  <p className="mt-1 font-mono text-[14px] text-ink">{fmt(hoveredFacility.verifiedYtd)}</p>
                </div>
                <MiniDqi value={hoveredFacility.dqi} />
              </div>
              <p className="mt-3 border-t border-line/40 pt-2 font-sans text-[12px] font-medium text-petrol">
                Drill down →
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
      <p className="data-s mt-4 border-t border-line/40 pt-3 text-muted">
        Stage 2 adds refining, power and steel — one national standard.
      </p>
    </Panel>
  )
}

/* ==================================================================== */

export default function Dashboard() {
  const facilities = useFacilities()
  const submissions = useSubmissions()
  const dqi = useDqi()
  const navigate = useNavigate()
  const [period, setPeriod] = useState<string>(PERIODS[0])

  const meanDqi = useMemo(
    () => (dqi.length ? dqi.reduce((a, d) => a + d.dqi, 0) / dqi.length : 0),
    [dqi],
  )
  const pendingCount = submissions.filter((s) => s.status === 'Pending').length

  return (
    <div className="flex flex-col gap-10">
      {/* ── Section 1 — page header ─────────────────────────────────── */}
      <motion.header
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: EASE }}
        className="flex flex-wrap items-end justify-between gap-6"
      >
        <div>
          <p className="kicker text-muted">NCCC — MRV Directorate / National Dashboard</p>
          <h1 className="mt-3 font-display text-[40px] leading-[1.05] text-ink">
            National oversight.
          </h1>
          <p className="mt-3 max-w-[560px] font-sans text-[15px] leading-[1.6] text-muted">
            Industrial MRV portfolio · Stage 1 sectors: oil &amp; gas, cement · demonstration
            portfolio.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <StatusChip status="Read-only oversight" kind="neutral" />
          <div className="relative">
            <select
              value={period}
              onChange={(e) => setPeriod(e.target.value)}
              className="appearance-none rounded-[2px] border border-line/60 bg-transparent py-[9px] pl-3 pr-9 font-mono text-[12px] text-ink transition-colors hover:border-ink focus:border-copper"
              aria-label="Reporting period"
            >
              {PERIODS.map((p) => (
                <option key={p} value={p} disabled={p !== PERIODS[0]}>
                  {p}
                </option>
              ))}
            </select>
            <ChevronDown
              className="pointer-events-none absolute right-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted"
              strokeWidth={1.75}
            />
          </div>
        </div>
      </motion.header>

      {/* ── Section 2 — national KPI band (dark) ────────────────────── */}
      <motion.section
        initial={{ opacity: 0, y: -16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: EASE, delay: 0.1 }}
        className="rounded-[2px] bg-petrol-deep px-8 py-10"
      >
        <AnimatePresence mode="wait">
          <motion.div
            key={period}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4, ease: EASE }}
            className="grid grid-cols-2 gap-y-10 md:grid-cols-5 md:gap-y-0"
          >
            {[
              <DarkStat
                key="facilities"
                label="Facilities on the rails"
                value={facilities.length}
                format={(v) => String(Math.round(v))}
                sub="oil & gas · cement"
                delay={0}
              />,
              <DarkStat
                key="verified"
                label="tCO₂e verified — this cycle year"
                value={1.52}
                format={(v) => `${v.toFixed(2)}M`}
                delta="on track vs 1.48M estimate"
                delay={0.1}
              />,
              <DarkStat
                key="dqi"
                label="Portfolio mean DQI"
                value={78.5}
                format={(v) => v.toFixed(1)}
                sub={`range ${Math.min(...dqi.map((d) => d.dqi))} – ${Math.max(...dqi.map((d) => d.dqi))}`}
                delay={0.2}
              />,
              <DarkStat
                key="ontime"
                label="On-time reporting rate"
                value={94}
                format={(v) => String(Math.round(v))}
                suffix="%"
                sub="2 late submissions in 12 months"
                delay={0.3}
              />,
              <DarkStat
                key="flags"
                label="Open anomaly flags"
                value={3}
                format={(v) => String(Math.round(v))}
                sub="1 high · 1 queried · 1 advisory"
                delay={0.4}
              />,
            ].map((stat, i) => (
              <div key={i} className="relative flex md:justify-center">
                {i > 0 && (
                  <motion.span
                    aria-hidden="true"
                    className="absolute left-0 top-1 hidden h-[calc(100%-8px)] w-px origin-top bg-ivory/[0.12] md:block"
                    initial={{ scaleY: 0 }}
                    whileInView={{ scaleY: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.6, ease: EASE, delay: 0.2 + i * 0.08 }}
                  />
                )}
                <div className="md:pl-8">{stat}</div>
              </div>
            ))}
          </motion.div>
        </AnimatePresence>
        <p className="data-s mt-8 border-t border-ivory/10 pt-4 text-ivory/40">
          {period} · {pendingCount} submissions pending human verification · mean DQI{' '}
          {meanDqi.toFixed(1)} across the portfolio
        </p>
      </motion.section>

      {/* ── Section 3 — map + DQI distribution ──────────────────────── */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[55fr_45fr]">
        <Reveal>
          <MapPanel facilities={facilities} />
        </Reveal>
        <Reveal delay={0.08}>
          <Panel kicker="DQI distribution — portfolio" className="h-full">
            <DqiHistogram />
            <p className="data-s mt-4 border-t border-line/40 pt-3 text-muted">
              DQI is published per facility and immutable.
            </p>
          </Panel>
        </Reveal>
      </div>

      {/* ── Section 4 — verification funnel + sector split ──────────── */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Reveal>
          <Panel kicker="From upload to official record — 12 months" className="h-full">
            <div className="flex flex-col gap-5">
              {FUNNEL.map((s, i) => (
                <div key={s.stage} className="flex items-center gap-5">
                  <span className="w-[92px] shrink-0 font-display text-[36px] leading-none text-ink">
                    {s.value}
                  </span>
                  <div className="min-w-0 flex-1">
                    <motion.div
                      className={cn('flex h-9 origin-left items-center rounded-[2px] px-3', s.fill)}
                      style={{ width: `${s.width}%` }}
                      initial={{ scaleX: 0 }}
                      whileInView={{ scaleX: 1 }}
                      viewport={{ once: true, amount: 0.4 }}
                      transition={{ duration: 0.7, ease: EASE, delay: i * 0.15 }}
                    >
                      <span className="whitespace-nowrap font-sans text-[12px] font-medium text-ivory origin-left">
                        {s.stage}
                      </span>
                    </motion.div>
                  </div>
                </div>
              ))}
            </div>
            <p className="mt-6 flex items-center gap-2 border-t border-line/40 pt-4 font-sans text-[13px] text-muted">
              <span className="h-[6px] w-[6px] shrink-0 bg-copper" />
              7 in flight: 3 pending · 1 queried · 3 superseded
            </p>
          </Panel>
        </Reveal>
        <Reveal delay={0.08}>
          <Panel kicker="Verified emissions by IPCC category" className="h-full">
            <DataTable>
              <DataTableHead columns={['IPCC category', 'Verified tCO₂e (FY)']} />
              <tbody>
                {SECTOR_SPLIT.map((r, i) => (
                  <motion.tr
                    key={r.category}
                    className="border-b border-line/40"
                    initial={{ opacity: 0, y: 8 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, ease: EASE, delay: i * 0.04 }}
                  >
                    <DataTableCell mono={false}>{r.category}</DataTableCell>
                    <DataTableCell>{fmt(r.value)}</DataTableCell>
                  </motion.tr>
                ))}
                <motion.tr
                  className="border-b border-line/40 bg-petrol/[0.06]"
                  initial={{ opacity: 0, y: 8 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, ease: EASE, delay: 0.16 }}
                >
                  <DataTableCell mono={false} className="font-semibold text-petrol">
                    Total — official record
                  </DataTableCell>
                  <DataTableCell className="font-semibold text-petrol">
                    {fmt(SECTOR_TOTAL)}
                  </DataTableCell>
                </motion.tr>
              </tbody>
            </DataTable>
            <p className="data-s mt-4 text-muted">
              Aggregated for the national inventory — see Inventory Export (NIMO).
            </p>
          </Panel>
        </Reveal>
      </div>

      {/* ── Section 5 — facilities table (drill-down entry) ─────────── */}
      <Reveal>
        <section>
          <LedgerRule className="mb-4" />
          <p className="kicker mb-4 text-muted">Facilities — drill down</p>
          <DataTable>
            <DataTableHead
              columns={[
                'Facility',
                'State',
                'Sector',
                'Plan status',
                'Verified tCO₂e (FY)',
                'Pending',
                'DQI',
                'Open flags',
                'Last report',
                '',
              ]}
            />
            <tbody>
              {facilities.map((f, i) => (
                <DataTableRow
                  key={f.id}
                  onClick={() => navigate(`/regulator/facilities/${f.id}`)}
                  className="motion-safe:animate-none"
                >
                  <DataTableCell mono={false}>
                    <motion.span
                      className="block font-medium"
                      initial={{ opacity: 0, y: 8 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.4, ease: EASE, delay: i * 0.05 }}
                    >
                      {f.name}
                      <span className="data-s mt-0.5 block text-muted">{f.id}</span>
                    </motion.span>
                  </DataTableCell>
                  <DataTableCell>{f.state.replace(' State', '')}</DataTableCell>
                  <DataTableCell mono={false}>{f.sector.replace(' (upstream)', '')}</DataTableCell>
                  <DataTableCell mono={false}>
                    <StatusChip status={`${f.plan.version} Approved`} kind="verified" />
                  </DataTableCell>
                  <DataTableCell>{fmt(f.verifiedYtd)}</DataTableCell>
                  <DataTableCell mono={false}>
                    <span className="flex flex-col gap-1.5">
                      <span className="font-mono text-[13px] text-copper">
                        {PENDING_TCO2E[f.id] ?? '—'}
                      </span>
                      <AILabel />
                    </span>
                  </DataTableCell>
                  <DataTableCell mono={false}>
                    <MiniDqi value={f.dqi} />
                  </DataTableCell>
                  <DataTableCell mono={false}>
                    <span className="inline-flex items-center gap-1.5">
                      <AlertTriangle
                        className={cn(
                          'h-3.5 w-3.5',
                          (OPEN_FLAGS[f.id] ?? 0) > 1 ? 'text-alert' : 'text-copper',
                        )}
                        strokeWidth={1.75}
                      />
                      <span className="font-mono text-[13px] text-ink">{OPEN_FLAGS[f.id] ?? 0}</span>
                    </span>
                  </DataTableCell>
                  <DataTableCell>Jun 2026</DataTableCell>
                  <DataTableCell mono={false}>
                    <span className="link-sweep whitespace-nowrap font-medium text-petrol">
                      Drill down →
                    </span>
                  </DataTableCell>
                </DataTableRow>
              ))}
            </tbody>
          </DataTable>
        </section>
      </Reveal>

      {/* ── Section 6 — alerts feed ─────────────────────────────────── */}
      <Reveal>
        <section>
          <LedgerRule className="mb-4" />
          <p className="kicker mb-4 text-muted">Alerts — requiring attention</p>
          <div className="divide-y divide-line/40 rounded-[2px] border border-line/60 bg-ivory">
            {ALERTS.map((a, i) => (
              <motion.div
                key={a.text}
                initial={{ opacity: 0, x: -16 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, amount: 0.4 }}
                transition={{ duration: 0.45, ease: EASE, delay: i * 0.08 }}
                className="flex flex-wrap items-center gap-x-4 gap-y-2 px-5 py-4"
              >
                <motion.span
                  animate={a.pulse ? { scale: [1, 1.02, 1] } : undefined}
                  transition={{ duration: 0.4, delay: 0.4 + i * 0.08 }}
                  className="flex min-w-0 flex-1 items-center gap-3"
                >
                  {a.kind === 'diamond' ? (
                    <Diamond tone={a.tone} />
                  ) : (
                    <Clock
                      className={cn('h-3.5 w-3.5 shrink-0', a.tone === 'alert' ? 'text-alert' : 'text-copper')}
                      strokeWidth={1.75}
                    />
                  )}
                  <span className="font-sans text-[13px] text-ink">{a.text}</span>
                </motion.span>
                <span className="data-s text-muted">{a.ts}</span>
                <Link
                  to={a.to}
                  className="link-sweep shrink-0 font-sans text-[12px] font-medium text-petrol"
                >
                  View →
                </Link>
              </motion.div>
            ))}
          </div>
          <div className="mt-4 flex justify-end">
            <Link to="/regulator/compliance" className="link-sweep font-sans text-[13px] font-medium text-petrol">
              Compliance calendar →
            </Link>
          </div>
        </section>
      </Reveal>
    </div>
  )
}
