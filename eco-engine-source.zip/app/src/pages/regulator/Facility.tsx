/**
 * Page 11 — Regulator Facility Drill-Down (`/regulator/facilities/:id`).
 * Read-only deep view: profile, streams, verified emissions history, DQI,
 * verification decisions, evidence provenance. Zero mutation controls.
 * Default: FAC-RIV-004 (NigerDelta Flow Station 4).
 */
import { useMemo, useState } from 'react'
import { Link, useParams } from 'react-router'
import { AnimatePresence, motion } from 'framer-motion'
import { ArrowLeft, ArrowRight, Check, FileText } from 'lucide-react'
import {
  Bar,
  Cell,
  ComposedChart,
  CartesianGrid,
  ResponsiveContainer,
  Scatter,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import AILabel from '@/components/app/AILabel'
import DqiGauge from '@/components/app/DqiGauge'
import HashChip from '@/components/app/HashChip'
import LedgerRule from '@/components/app/LedgerRule'
import StatusChip from '@/components/app/StatusChip'
import DataTable, {
  DataTableCell,
  DataTableHead,
  DataTableRow,
} from '@/components/app/DataTable'
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet'
import { demoHash, useFacilities, usePlans } from '@/lib/store'
import type { Facility as FacilityT } from '@/lib/demo-data'
import { cn } from '@/lib/utils'
import { EASE, Reveal, fmt } from './shared'

/* ---------------------------------------------------------- demo model */

const DAYS_IN_MONTH: Record<string, number> = {
  Jan: 31, Feb: 28, Mar: 31, Apr: 30, May: 31, Jun: 30,
  Jul: 31, Aug: 31, Sep: 30, Oct: 31, Nov: 30, Dec: 31,
}

const OPERATOR_RC: Record<string, string> = {
  'FAC-RIV-004': 'RC 1744552 (demo)',
  'FAC-KOG-002': 'RC 1092837 (demo)',
}
const BOUNDARY: Record<string, string> = {
  'FAC-RIV-004': 'Operational control — flow station fence-line (demo)',
  'FAC-KOG-002': 'Operational control — Line 2 plant boundary (demo)',
}
const CONTACT: Record<string, string> = {
  'FAC-RIV-004': 'Engr. T. Wokoma — Facility Environmental Manager',
  'FAC-KOG-002': 'Facility Environmental Desk (demo)',
}
const ANOMALY_MONTH: Record<string, string> = {
  'FAC-RIV-004': 'Mar 2026',
  'FAC-KOG-002': 'Feb 2026',
}

interface VerifiedRow {
  month: string
  stream: string
  activity: string
  tco2e: number
  verifier: string
  hash: string
}

/** Verified official-record rows derived from demo-data history + EF library. */
function verifiedRows(f: FacilityT): VerifiedRow[] {
  const isA = f.id === 'FAC-RIV-004'
  const rows: VerifiedRow[] = []
  for (const h of f.history) {
    if (h.month === 'Jun 2026') continue // pending — never in the official record
    if (!isA && h.month === 'Feb 2026') continue // queried — excluded pending resolution
    const mon = h.month.slice(0, 3)
    const days = DAYS_IN_MONTH[mon] ?? 30
    const tco2e = isA
      ? h.month === 'Mar 2026'
        ? 5614 // demo constant — accepted anomaly, verbatim
        : Math.round(h.value * 60.3 * days) // GGFR/IPCC derived factor
      : Math.round(h.value * 0.52) // IPCC 2006 Vol. 3 Ch. 2 Eq. 2.4
    rows.push({
      month: h.month,
      stream: isA ? 'S1 · Associated gas flared' : 'S1 · Clinker production',
      activity: isA ? `${h.value.toFixed(2)} MMscf/d` : `${fmt(h.value)} t`,
      tco2e,
      verifier: 'Dr. F. Okafor',
      hash: demoHash(`DECISION|${f.id}|${h.month}`),
    })
  }
  return rows.reverse() // newest first
}

interface EvidenceRow {
  file: string
  submission: string
  period: string
  type: string
  size: string
  by: string
  at: string
}

const EVIDENCE: Record<string, EvidenceRow[]> = {
  'FAC-RIV-004': [
    { file: 'FL-201_meter_export_Mar2026.csv', submission: 'SUB-2606-114', period: 'Mar 2026', type: 'Meter export', size: '184 KB', by: 'Engr. T. Wokoma', at: '15 Apr 2026 08:12' },
    { file: 'turnaround_flare_event_note_Mar2026.pdf', submission: 'SUB-2606-114', period: 'Mar 2026', type: 'Operator note', size: '96 KB', by: 'Engr. T. Wokoma', at: '15 Apr 2026 08:14' },
    { file: 'FG-104_meter_export_Jun2026.csv', submission: 'SUB-2607-003', period: 'Jun 2026', type: 'Meter export', size: '172 KB', by: 'Engr. T. Wokoma', at: '15 Jul 2026 07:45' },
    { file: 'diesel_delivery_records_May2026.pdf', submission: 'SUB-2605-091', period: 'May 2026', type: 'Delivery records', size: '88 KB', by: 'Engr. T. Wokoma', at: '15 Jun 2026 08:03' },
  ],
  'FAC-KOG-002': [
    { file: 'BS-22_belt_scale_export_Feb2026.csv', submission: 'SUB-2606-118', period: 'Feb 2026', type: 'Meter export', size: '241 KB', by: 'Engr. T. Wokoma', at: '15 Mar 2026 11:30' },
    { file: 'WF-07_weighfeeder_export_Jun2026.csv', submission: 'SUB-2607-007', period: 'Jun 2026', type: 'Meter export', size: '198 KB', by: 'Engr. T. Wokoma', at: '15 Jul 2026 08:02' },
    { file: 'KG-03_meter_export_May2026.csv', submission: 'SUB-2606-122', period: 'May 2026', type: 'Meter export', size: '165 KB', by: 'Engr. T. Wokoma', at: '15 Jun 2026 07:58' },
    { file: 'clinker_production_log_Jan2026.xlsx', submission: 'SUB-2602-064', period: 'Jan 2026', type: 'Production log', size: '312 KB', by: 'Engr. T. Wokoma', at: '17 Feb 2026 10:21' },
  ],
}

interface Decision {
  kind: 'Accepted' | 'Queried' | 'Rejected' | 'Pending'
  text: string
  note?: string
  by: string | null
  ts: string
  hash: string
}

const DECISIONS: Record<string, Decision[]> = {
  'FAC-RIV-004': [
    { kind: 'Pending', text: 'Fuel gas Jun 2026 · 2,602 tCO₂e AI estimate — awaiting human verification', by: null, ts: 'submitted 15 Jul 2026 07:45', hash: demoHash('RUN|SUB-2607-003') },
    { kind: 'Accepted', text: 'Flaring Mar 2026 · 5,614 tCO₂e', note: 'Evidence reviewed — accepted with note', by: 'Dr. F. Okafor', ts: '09 Apr 2026 14:22', hash: demoHash('DECISION|SUB-2606-114') },
    { kind: 'Accepted', text: 'Flaring Feb 2026 · 3,495 tCO₂e', note: 'Routine acceptance', by: 'Dr. F. Okafor', ts: '12 Mar 2026 15:31', hash: demoHash('DECISION|FAC-RIV-004|Feb 2026') },
    { kind: 'Rejected', text: 'Diesel Sep 2025', note: 'Rejected — reason: evidence insufficient', by: 'Dr. F. Okafor', ts: '06 Oct 2025 11:40', hash: demoHash('DECISION|FAC-RIV-004|Sep 2025') },
  ],
  'FAC-KOG-002': [
    { kind: 'Pending', text: 'Petcoke Jun 2026 · 28,417 tCO₂e AI estimate — flag: peer deviation (borderline)', by: null, ts: 'submitted 15 Jul 2026 08:02', hash: demoHash('RUN|SUB-2607-007') },
    { kind: 'Queried', text: 'Clinker Feb 2026 · 61,585 tCO₂e', note: 'Please attach belt-scale BS-22 raw logs for February.', by: 'Dr. F. Okafor', ts: '12 Jul 2026 09:18', hash: demoHash('DECISION|SUB-2606-118') },
    { kind: 'Accepted', text: 'Clinker May 2026 · 62,624 tCO₂e', note: 'Routine acceptance', by: 'Dr. F. Okafor', ts: '11 Jun 2026 13:47', hash: demoHash('DECISION|FAC-KOG-002|May 2026') },
    { kind: 'Accepted', text: 'Clinker Jan 2026 · 61,585 tCO₂e', note: 'Routine acceptance', by: 'Dr. F. Okafor', ts: '09 Mar 2026 10:05', hash: demoHash('DECISION|FAC-KOG-002|Jan 2026') },
  ],
}

const DECISION_FILTERS = ['All', 'Accepted', 'Queried', 'Rejected'] as const

/* ------------------------------------------------------ emissions chart */

function AnomalyDiamond(props: { cx?: number; cy?: number }) {
  const { cx = 0, cy = 0 } = props
  return (
    <rect
      x={cx - 5}
      y={cy - 14}
      width={9}
      height={9}
      fill="#A63D2F"
      transform={`rotate(45 ${cx} ${cy - 10})`}
    />
  )
}

function ChartTip({
  active,
  payload,
  label,
  unit,
}: {
  active?: boolean
  payload?: Array<{ payload: { pending: boolean; anomaly: boolean; value: number } }>
  label?: string
  unit: string
}) {
  if (!active || !payload || payload.length === 0) return null
  const p = payload[0].payload
  return (
    <div className="rounded-[2px] border border-ink/30 bg-ink px-3 py-2">
      <p className="data-s text-ivory">{label}</p>
      <p className="data-s mt-1 text-ivory/80">
        {typeof p.value === 'number' ? fmt(p.value) : p.value} {unit}
      </p>
      {p.pending && <p className="data-s mt-1 text-copper-light">Pending — excluded from record</p>}
      {p.anomaly && <p className="data-s mt-1 text-copper-light">Anomaly flag raised</p>}
    </div>
  )
}

function EmissionsChart({ facility }: { facility: FacilityT }) {
  const isA = facility.id === 'FAC-RIV-004'
  const anomalyMonth = ANOMALY_MONTH[facility.id]
  const unit = isA ? 'MMscf/d' : 't/month'
  const data = facility.history.map((h) => ({
    month: h.month.slice(0, 3),
    full: h.month,
    value: h.value,
    pending: h.month === 'Jun 2026',
    anomaly: h.month === anomalyMonth,
  }))
  const anomalyPoint = data.filter((d) => d.anomaly)

  return (
    <div>
      <ResponsiveContainer width="100%" height={260}>
        <ComposedChart data={data} margin={{ top: 16, right: 8, bottom: 0, left: isA ? -18 : 4 }}>
          <defs>
            <pattern
              id="pendingHatch"
              width="6"
              height="6"
              patternTransform="rotate(45)"
              patternUnits="userSpaceOnUse"
            >
              <rect width="6" height="6" fill="#F5F0E6" />
              <line x1="0" y1="0" x2="0" y2="6" stroke="#B5651D" strokeWidth="1.5" />
            </pattern>
          </defs>
          <CartesianGrid horizontal vertical={false} stroke="#C9BBA2" strokeOpacity={0.3} />
          <XAxis
            dataKey="month"
            tickLine={false}
            axisLine={{ stroke: '#C9BBA2', strokeOpacity: 0.6 }}
            tick={{ fontSize: 10, fontFamily: "'IBM Plex Mono', monospace", fill: '#5F7168' }}
          />
          <YAxis
            tickLine={false}
            axisLine={false}
            tickCount={4}
            domain={isA ? [0, 3.4] : [110000, 125000]}
            tickFormatter={(v: number) => (isA ? v.toFixed(1) : `${Math.round(v / 1000)}k`)}
            tick={{ fontSize: 10, fontFamily: "'IBM Plex Mono', monospace", fill: '#5F7168' }}
          />
          <Tooltip content={<ChartTip unit={unit} />} cursor={{ fill: '#1C2B28', fillOpacity: 0.04 }} />
          <Bar dataKey="value" radius={[1, 1, 0, 0]} maxBarSize={36}>
            {data.map((d) => (
              <Cell
                key={d.full}
                fill={d.pending ? 'url(#pendingHatch)' : '#0F4C5C'}
                stroke={d.pending ? '#B5651D' : 'none'}
                strokeWidth={d.pending ? 1 : 0}
              />
            ))}
          </Bar>
          <Scatter data={anomalyPoint} dataKey="value" shape={<AnomalyDiamond />} />
        </ComposedChart>
      </ResponsiveContainer>
      <div className="mt-3 flex flex-wrap items-center justify-between gap-3 border-t border-line/40 pt-3">
        <AILabel />
        <p className="data-s text-muted">
          Jun 2026 — pending verification, excluded from the official record ·{' '}
          {isA ? '◆ Mar 2026 anomaly (accepted with note)' : '◆ Feb 2026 anomaly (queried)'}
        </p>
      </div>
    </div>
  )
}

/* ------------------------------------------------------------- tab 1 */

function OverviewTab({ facility }: { facility: FacilityT }) {
  const profile: Array<[string, string]> = [
    ['Operator organisation', facility.operatorOrg],
    ['Company RC', OPERATOR_RC[facility.id] ?? '— (demo)'],
    ['Sector', facility.sector],
    [
      'Location',
      `${facility.lga}, ${facility.state} · ${facility.coords.lat.toFixed(4)}° N, ${facility.coords.lon.toFixed(4)}° E (demo coordinates)`,
    ],
    ['Boundary', BOUNDARY[facility.id] ?? 'Operational control (demo)'],
    ['Units / processes', facility.units.join(' · ')],
    ['Facility ID', facility.id],
    ['Status', `Approved — ${facility.approvedOn}`],
    ['Contact', CONTACT[facility.id] ?? '— (demo)'],
  ]
  const isA = facility.id === 'FAC-RIV-004'
  return (
    <div className="grid grid-cols-1 gap-8 lg:grid-cols-[1fr_280px]">
      <dl className="divide-y divide-line/40">
        {profile.map(([k, v], i) => (
          <motion.div
            key={k}
            className="grid grid-cols-[180px_1fr] gap-4 py-3"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, ease: EASE, delay: i * 0.04 }}
          >
            <dt className="kicker pt-0.5 text-muted">{k}</dt>
            <dd className="font-sans text-[14px] leading-[1.5] text-ink">{v}</dd>
          </motion.div>
        ))}
      </dl>
      <aside className="flex flex-col items-center gap-4 border-l border-line/40 pl-8 max-lg:border-l-0 max-lg:pl-0">
        <DqiGauge value={facility.dqi} size={170} />
        <p className="data-s text-muted">
          {facility.dqiTrend.from} → {facility.dqiTrend.to} over 12 months · published, immutable
        </p>
        <Link to="/operator/dqi" className="link-sweep font-sans text-[13px] font-medium text-petrol">
          Open DQI history →
        </Link>
        <div className="mt-2 w-full border-t border-line/40 pt-4">
          <p className="kicker text-muted">Next deadline</p>
          {isA ? (
            <p className="mt-2 font-sans text-[13px] font-medium text-alert">
              June 2026 diesel — due today, not uploaded
            </p>
          ) : (
            <p className="mt-2 flex items-center gap-2 font-sans text-[13px] text-petrol">
              <Check className="h-3.5 w-3.5" strokeWidth={2} />
              June 2026 cycle — 3 of 3 streams uploaded, pending verification
            </p>
          )}
          <p className="data-s mt-1 text-muted">rule: 15th of the following month</p>
        </div>
      </aside>
    </div>
  )
}

/* ------------------------------------------------------------- tab 2 */

function EmissionsTab({ facility }: { facility: FacilityT }) {
  const rows = useMemo(() => verifiedRows(facility), [facility])
  const [showAll, setShowAll] = useState(false)
  const visible = showAll ? rows : rows.slice(0, 6)
  const isA = facility.id === 'FAC-RIV-004'
  return (
    <div className="flex flex-col gap-8">
      <div>
        <p className="kicker mb-4 text-muted">Verified emissions — official record only</p>
        <EmissionsChart facility={facility} />
      </div>
      <DataTable>
        <DataTableHead
          columns={['Month', 'Stream', 'Activity', 'Verified tCO₂e', 'Verifier', 'Decision hash']}
        />
        <tbody>
          {visible.map((r, i) => (
            <DataTableRow key={r.month}>
              <DataTableCell>
                <motion.span
                  className="block"
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.35, ease: EASE, delay: Math.min(i, 11) * 0.02 }}
                >
                  {r.month}
                </motion.span>
              </DataTableCell>
              <DataTableCell mono={false}>{r.stream}</DataTableCell>
              <DataTableCell>{r.activity}</DataTableCell>
              <DataTableCell className="font-medium">{fmt(r.tco2e)}</DataTableCell>
              <DataTableCell mono={false}>{r.verifier}</DataTableCell>
              <DataTableCell mono={false}>
                <HashChip hash={r.hash} />
              </DataTableCell>
            </DataTableRow>
          ))}
        </tbody>
      </DataTable>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="data-s text-muted">
          Pending AI estimates are never shown as part of the official record.
          {!isA && ' Feb 2026 is queried and excluded pending resolution.'}
        </p>
        {!showAll && rows.length > 6 && (
          <button
            type="button"
            onClick={() => setShowAll(true)}
            className="rounded-[2px] border border-ink/30 px-4 py-2 font-sans text-[13px] font-semibold text-ink transition-all duration-200 hover:-translate-y-px hover:border-ink hover:bg-sand"
          >
            Show all {rows.length} verified months
          </button>
        )}
      </div>
    </div>
  )
}

/* ------------------------------------------------------------- tab 3 */

const DECISION_NODE: Record<Decision['kind'], string> = {
  Accepted: 'bg-petrol',
  Queried: 'bg-copper',
  Pending: 'bg-copper',
  Rejected: 'bg-alert',
}

function DecisionsTab({ facility }: { facility: FacilityT }) {
  const decisions = DECISIONS[facility.id] ?? []
  const [filter, setFilter] = useState<(typeof DECISION_FILTERS)[number]>('All')
  const visible = decisions.filter((d) => filter === 'All' || d.kind === filter)
  return (
    <div>
      <div className="mb-6 flex flex-wrap gap-2">
        {DECISION_FILTERS.map((f) => (
          <button
            key={f}
            type="button"
            onClick={() => setFilter(f)}
            className={cn(
              'rounded-[2px] border px-3 py-1.5 font-sans text-[10px] font-semibold uppercase tracking-chip transition-colors duration-200',
              filter === f
                ? 'border-petrol bg-petrol text-ivory'
                : 'border-line/60 text-muted hover:border-ink hover:text-ink',
            )}
          >
            {f}
          </button>
        ))}
      </div>
      <div className="flex flex-col">
        {visible.length === 0 && (
          <p className="py-10 text-center font-display text-[20px] text-ink">
            Nothing on the record yet.
          </p>
        )}
        {visible.map((d, i) => (
          <motion.div
            key={d.ts + d.text}
            initial={{ opacity: 0, x: -16 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.45, ease: EASE, delay: i * 0.07 }}
            className="flex gap-4 border-b border-line/40 py-4 last:border-b-0"
          >
            <span className={cn('mt-1.5 h-[8px] w-[8px] shrink-0', DECISION_NODE[d.kind])} />
            <div className="min-w-0 flex-1">
              <p className="font-sans text-[14px] font-medium text-ink">
                <span
                  className={cn(
                    'mr-2 font-sans text-[10px] font-semibold uppercase tracking-chip',
                    d.kind === 'Accepted' && 'text-petrol',
                    (d.kind === 'Queried' || d.kind === 'Pending') && 'text-copper',
                    d.kind === 'Rejected' && 'text-alert',
                  )}
                >
                  {d.kind}
                </span>
                {d.text}
              </p>
              {d.note && <p className="mt-1 font-sans text-[13px] italic text-muted">“{d.note}”</p>}
              {d.kind === 'Pending' && (
                <div className="mt-2">
                  <AILabel />
                </div>
              )}
              <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-2">
                <span className="data-s text-muted">
                  {d.by ? `${d.by} · ` : ''}
                  {d.ts}
                </span>
                <HashChip hash={d.hash} />
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  )
}

/* ------------------------------------------------------------- tab 4 */

function EvidenceTab({ facility }: { facility: FacilityT }) {
  const rows = EVIDENCE[facility.id] ?? []
  const [open, setOpen] = useState<EvidenceRow | null>(null)
  const fileHash = (e: EvidenceRow) => demoHash(`EVIDENCE|${e.file}`)
  const runHash = (e: EvidenceRow) => demoHash(`RUN|${e.submission}`)
  const decisionHash = (e: EvidenceRow) => demoHash(`DECISION|${e.submission}`)

  return (
    <div>
      <DataTable>
        <DataTableHead
          columns={['Evidence file', 'Submission', 'Period', 'Type', 'SHA-256', 'Uploaded by / at', 'Chain status']}
        />
        <tbody>
          {rows.map((e, i) => (
            <DataTableRow key={e.file} onClick={() => setOpen(e)}>
              <DataTableCell mono={false}>
                <motion.span
                  className="flex items-center gap-2 font-medium"
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.35, ease: EASE, delay: i * 0.04 }}
                >
                  <FileText className="h-3.5 w-3.5 shrink-0 text-muted" strokeWidth={1.75} />
                  {e.file}
                </motion.span>
              </DataTableCell>
              <DataTableCell>{e.submission}</DataTableCell>
              <DataTableCell>{e.period}</DataTableCell>
              <DataTableCell mono={false}>{e.type}</DataTableCell>
              <DataTableCell mono={false}>
                <HashChip hash={fileHash(e)} />
              </DataTableCell>
              <DataTableCell mono={false}>
                <span className="font-sans text-[13px] text-ink">{e.by}</span>
                <span className="data-s block text-muted">{e.at}</span>
              </DataTableCell>
              <DataTableCell mono={false}>
                <span className="data-s flex items-center gap-1.5 text-petrol">
                  <Check className="h-3 w-3" strokeWidth={2.5} />
                  hash verified
                </span>
              </DataTableCell>
            </DataTableRow>
          ))}
        </tbody>
      </DataTable>

      {/* read-only evidence drawer (§6.13) */}
      <Sheet open={open !== null} onOpenChange={(o) => !o && setOpen(null)}>
        <SheetContent side="right" className="w-[480px] overflow-y-auto rounded-[2px] bg-ivory sm:max-w-[480px]">
          {open && (
            <>
              <SheetHeader>
                <SheetTitle className="font-display text-[24px] font-normal text-ink">
                  Evidence provenance
                </SheetTitle>
                <SheetDescription className="font-sans text-[13px] text-muted">
                  Read-only · every artefact resolves to the hash chain.
                </SheetDescription>
              </SheetHeader>
              <div className="mt-6 flex flex-col gap-1 px-6 pb-8">
                <div className="rounded-[2px] border border-line/60 bg-sand/60 p-4">
                  <p className="flex items-center gap-2 font-sans text-[13px] font-semibold text-ink">
                    <FileText className="h-3.5 w-3.5 text-muted" strokeWidth={1.75} />
                    {open.file}
                  </p>
                  <div className="data-s mt-3 grid grid-cols-2 gap-x-4 gap-y-2 text-muted">
                    <span>size · {open.size}</span>
                    <span>type · {open.type}</span>
                    <span>submission · {open.submission}</span>
                    <span>period · {open.period}</span>
                    <span className="col-span-2">
                      uploaded · {open.by} · {open.at}
                    </span>
                  </div>
                </div>

                {/* provenance chain */}
                <div className="mt-6">
                  <p className="kicker mb-4 text-muted">Provenance chain</p>
                  {[
                    { label: 'Uploaded', detail: `${open.by} · ${open.at}`, hash: null },
                    { label: 'Hashed — SHA-256', detail: open.file, hash: fileHash(open) },
                    {
                      label: 'Referenced in AI estimate run',
                      detail: open.submission,
                      hash: runHash(open),
                    },
                    {
                      label: 'Cited in verification decision',
                      detail: open.submission,
                      hash: decisionHash(open),
                    },
                  ].map((step, i, arr) => (
                    <div key={step.label} className="relative flex gap-4 pb-6 last:pb-0">
                      {i < arr.length - 1 && (
                        <span className="absolute left-[5px] top-4 h-[calc(100%-12px)] w-px bg-line" />
                      )}
                      <span
                        className={cn(
                          'mt-1 h-[11px] w-[11px] shrink-0 rounded-full border-2',
                          i === 0 ? 'border-copper bg-copper' : 'border-petrol bg-petrol',
                        )}
                      />
                      <div className="min-w-0">
                        <p className="font-sans text-[13px] font-semibold text-ink">{step.label}</p>
                        <p className="data-s mt-0.5 text-muted">{step.detail}</p>
                        {step.hash && <HashChip hash={step.hash} expanded className="mt-2" />}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </div>
  )
}

/* ------------------------------------------------------------- tab 5 */

function PlanTab({ facility }: { facility: FacilityT }) {
  const plans = usePlans()
  const plan = plans.find((p) => p.facilityId === facility.id)
  return (
    <div className="flex flex-col gap-10">
      {/* stream panels (condensed, read-only) */}
      <div>
        <p className="kicker mb-4 text-muted">
          Monitoring plan {facility.plan.version} — approved {facility.plan.approvedOn} · read-only
        </p>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
          {facility.streams.map((s, i) => (
            <motion.div
              key={s.id}
              className="rounded-[2px] border border-line/60 bg-sand/50 p-4"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, ease: EASE, delay: i * 0.08 }}
            >
              <p className="flex items-baseline gap-2">
                <span className="font-mono text-[11px] text-copper">{s.id}</span>
                <span className="font-sans text-[14px] font-semibold text-ink">{s.label}</span>
              </p>
              <dl className="mt-3 flex flex-col gap-1.5">
                {(
                  [
                    ['Unit', s.unit],
                    ['Method', s.method],
                    ['Meter / source', s.meter],
                    ['Calibration due', s.calibrationDue ?? 'n/a — estimated stream'],
                    ['Tier', s.tier],
                    ['Frequency', s.frequency],
                    ['IPCC category', s.ipccCategory],
                  ] as Array<[string, string]>
                ).map(([k, v]) => (
                  <div key={k} className="flex items-baseline justify-between gap-3">
                    <dt className="font-sans text-[11px] uppercase tracking-[0.08em] text-muted">{k}</dt>
                    <dd className="text-right font-mono text-[11px] text-ink">{v}</dd>
                  </div>
                ))}
              </dl>
            </motion.div>
          ))}
        </div>
      </div>

      {/* permits */}
      <div>
        <p className="kicker mb-4 text-muted">Permits &amp; approvals</p>
        <DataTable>
          <DataTableHead columns={['Permit', 'Status']} />
          <tbody>
            {facility.permits.map((p) => (
              <DataTableRow key={p}>
                <DataTableCell mono={false}>{p}</DataTableCell>
                <DataTableCell mono={false}>
                  <StatusChip status="Valid" kind="verified" />
                </DataTableCell>
              </DataTableRow>
            ))}
          </tbody>
        </DataTable>
      </div>

      {/* version history */}
      <div>
        <p className="kicker mb-4 text-muted">Plan version history</p>
        <div className="flex flex-col">
          {(plan?.versions ?? []).map((v) => (
            <div key={v.version} className="flex flex-wrap items-center gap-x-4 gap-y-2 border-b border-line/40 py-3 last:border-b-0">
              <span className="font-mono text-[13px] font-medium text-ink">{v.version}</span>
              <StatusChip
                status={v.status}
                kind={v.status === 'Approved' ? 'verified' : v.status === 'Draft' ? 'pending' : 'pending'}
              />
              <span className="data-s text-muted">
                {v.approvedOn ? `approved ${v.approvedOn}` : 'not yet submitted'} · {v.note}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

/* ==================================================================== */

const TABS = [
  { id: 'overview', label: 'Overview' },
  { id: 'emissions', label: 'Emissions record' },
  { id: 'decisions', label: 'Verification decisions' },
  { id: 'evidence', label: 'Evidence & provenance' },
  { id: 'plan', label: 'Plan & permits' },
] as const

type TabId = (typeof TABS)[number]['id']

/** Chip on the dark header band (petrol-deep). */
function DarkChip({
  label,
  tone,
  delay,
}: {
  label: string
  tone: 'teal' | 'ink' | 'copper'
  delay: number
}) {
  return (
    <motion.span
      initial={{ opacity: 0, scale: 0.92 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3, ease: EASE, delay }}
      className={cn(
        'inline-flex items-center rounded-[2px] px-[10px] py-[6px] font-sans text-[10px] font-semibold uppercase tracking-chip',
        tone === 'teal' && 'border border-ivory/20 bg-petrol text-ivory',
        tone === 'ink' && 'border border-ivory/25 text-ivory/80',
        tone === 'copper' && 'border border-copper text-copper-light',
      )}
    >
      {label}
    </motion.span>
  )
}

export default function Facility() {
  const { id } = useParams<{ id: string }>()
  const facilities = useFacilities()
  const facility = facilities.find((f) => f.id === id) ?? facilities[0]
  const [tab, setTab] = useState<TabId>('overview')

  const openFlags = facility.id === 'FAC-RIV-004' ? 1 : 2

  return (
    <div className="flex flex-col gap-8">
      {/* ── Section 1 — header band (dark) ──────────────────────────── */}
      <motion.section
        initial={{ opacity: 0, y: -16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: EASE }}
        className="rounded-[2px] bg-petrol-deep px-8 py-8"
      >
        <Link
          to="/regulator"
          className="link-sweep inline-flex items-center gap-2 font-sans text-[12px] font-medium text-copper-light"
        >
          <ArrowLeft className="h-3.5 w-3.5" strokeWidth={1.75} />
          National dashboard
        </Link>
        <h1 className="mt-4 font-display text-[36px] leading-[1.05] text-ivory">{facility.name}</h1>
        <p className="mt-2 font-sans text-[13px] text-ivory/70">
          {facility.operatorOrg} · {facility.sector} · {facility.lga.replace(' LGA', '')},{' '}
          {facility.state} · {facility.id}
        </p>
        <div className="mt-5 flex flex-wrap gap-2">
          <DarkChip label="Approved" tone="teal" delay={0.15} />
          <DarkChip label={`Plan ${facility.plan.version}`} tone="ink" delay={0.21} />
          <DarkChip label={`DQI ${facility.dqi}`} tone="teal" delay={0.27} />
          <DarkChip label={`${openFlags} open flag${openFlags > 1 ? 's' : ''}`} tone="copper" delay={0.33} />
          <DarkChip label="Read-only" tone="ink" delay={0.39} />
        </div>
      </motion.section>

      {/* facility switcher (read-only navigation between the two demo sites) */}
      <div className="flex flex-wrap gap-2">
        {facilities.map((f) => (
          <Link
            key={f.id}
            to={`/regulator/facilities/${f.id}`}
            className={cn(
              'rounded-[2px] border px-3 py-1.5 font-sans text-[11px] font-semibold transition-colors duration-200',
              f.id === facility.id
                ? 'border-petrol bg-petrol text-ivory'
                : 'border-line/60 text-muted hover:border-ink hover:text-ink',
            )}
          >
            {f.id}
          </Link>
        ))}
      </div>

      {/* ── Section 2 — tab strip + content ─────────────────────────── */}
      <div>
        <div className="flex flex-wrap gap-x-6 gap-y-2 border-b border-line/60" role="tablist">
          {TABS.map((t) => (
            <button
              key={t.id}
              type="button"
              role="tab"
              aria-selected={tab === t.id}
              onClick={() => setTab(t.id)}
              className={cn(
                'relative pb-3 font-sans text-[11px] font-semibold uppercase tracking-kicker transition-colors duration-200',
                tab === t.id ? 'text-petrol' : 'text-muted hover:text-ink',
              )}
            >
              {t.label}
              {tab === t.id && (
                <motion.span
                  layoutId="regulator-facility-tab"
                  className="absolute inset-x-0 -bottom-px h-[2px] bg-petrol"
                  transition={{ duration: 0.3, ease: EASE }}
                />
              )}
            </button>
          ))}
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={tab + facility.id}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25, ease: EASE }}
            className="pt-8"
          >
            {tab === 'overview' && <OverviewTab facility={facility} />}
            {tab === 'emissions' && <EmissionsTab facility={facility} />}
            {tab === 'decisions' && <DecisionsTab facility={facility} />}
            {tab === 'evidence' && <EvidenceTab facility={facility} />}
            {tab === 'plan' && <PlanTab facility={facility} />}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* ── Section 3 — oversight note strip (dark band) ────────────── */}
      <Reveal>
        <section className="rounded-[2px] bg-petrol-deep px-8 py-10">
          <LedgerRule dark className="mb-6" />
          <p className="font-display text-[24px] leading-[1.15] text-ivory">
            {'Oversight without paperwork.'.split(' ').map((w, i) => (
              <motion.span
                key={i}
                className="mr-[0.28em] inline-block"
                initial={{ opacity: 0, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.6 }}
                transition={{ duration: 0.45, ease: EASE, delay: i * 0.03 }}
              >
                {w}
              </motion.span>
            ))}
          </p>
          <p className="mt-3 max-w-[720px] font-sans text-[13px] leading-[1.6] text-ivory/70">
            Every figure on this page resolves to a hashed chain of evidence, estimation and human
            decision — inspectable at any time, without a request letter.
          </p>
          <Link
            to="/audit"
            className="link-sweep mt-6 inline-flex items-center gap-2 font-sans text-[12px] font-medium text-copper-light"
          >
            Open the audit trail
            <ArrowRight className="h-3.5 w-3.5" strokeWidth={1.75} />
          </Link>
        </section>
      </Reveal>
    </div>
  )
}
