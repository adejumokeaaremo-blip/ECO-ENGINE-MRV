/**
 * Page 12 — Compliance Calendar & Alerts (`/regulator/compliance`).
 * The NCCC's "who reported / who is late" instrument: reporting obligations
 * per facility/stream, deadline grid, consolidated alerts panel.
 * Demo date: 15 July 2026 — June 2026 reports are due TODAY.
 */
import { useMemo, useState } from 'react'
import type { ReactNode } from 'react'
import { Link } from 'react-router'
import { AnimatePresence, motion } from 'framer-motion'
import {
  ArrowDownUp,
  Check,
  ChevronLeft,
  ChevronRight,
  Clock,
  Settings2,
} from 'lucide-react'
import AILabel from '@/components/app/AILabel'
import LedgerRule from '@/components/app/LedgerRule'
import DataTable, {
  DataTableCell,
  DataTableHead,
  DataTableRow,
} from '@/components/app/DataTable'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { ANOMALY_RULES } from '@/lib/demo-data'
import { cn } from '@/lib/utils'
import { Diamond, EASE, Panel, Reveal, useCountUpInView } from './shared'

/* ---------------------------------------------------------- demo model */

type ChipTone = 'teal' | 'copper' | 'alert' | 'muted'

interface ObligationChip {
  id: string
  label: string
  tone: ChipTone
  detail: string
  facilityId: 'FAC-RIV-004' | 'FAC-KOG-002' | null
}

interface TickEvent {
  day: number
  label: string
}

interface MonthData {
  chips: Record<number, ObligationChip[]>
  ticks: TickEvent[]
}

const JUNE_CHIPS: ObligationChip[] = [
  {
    id: 'jun-flaring',
    label: 'FS-4 · flaring Jun ✓ uploaded — pending verification',
    tone: 'copper',
    detail: 'Flaring (S1) · June 2026 · uploaded 15 Jul 2026 07:52 · AI estimate 3,718 tCO₂e ±8% — awaiting human verification.',
    facilityId: 'FAC-RIV-004',
  },
  {
    id: 'jun-fuelgas',
    label: 'FS-4 · fuel gas Jun ✓ uploaded — pending',
    tone: 'copper',
    detail: 'Fuel gas (S2) · June 2026 · SUB-2607-003 · 1.42 MMscf/d · AI estimate 2,602 tCO₂e ±6% · no flags.',
    facilityId: 'FAC-RIV-004',
  },
  {
    id: 'jun-diesel',
    label: 'FS-4 · diesel Jun — DUE TODAY, not uploaded',
    tone: 'alert',
    detail: 'Diesel (S3) · June 2026 · no upload received as of 15 Jul 2026. A recorded event — it moves DQI timeliness and stays on the immutable history.',
    facilityId: 'FAC-RIV-004',
  },
  {
    id: 'jun-clinker',
    label: 'SCW-L2 · clinker Jun ✓',
    tone: 'copper',
    detail: 'Clinker (S1) · June 2026 · uploaded 15 Jul 2026 07:31 · AI estimate pending human verification.',
    facilityId: 'FAC-KOG-002',
  },
  {
    id: 'jun-petcoke',
    label: 'SCW-L2 · petcoke Jun ✓',
    tone: 'copper',
    detail: 'Petcoke (S2) · June 2026 · SUB-2607-007 · 9,588 t · AI estimate 28,417 tCO₂e ±7% · flag: peer deviation (borderline).',
    facilityId: 'FAC-KOG-002',
  },
  {
    id: 'jun-kilngas',
    label: 'SCW-L2 · kiln gas Jun ✓',
    tone: 'copper',
    detail: 'Kiln gas (S3) · June 2026 · uploaded 15 Jul 2026 07:44 · AI estimate pending human verification.',
    facilityId: 'FAC-KOG-002',
  },
]

function tealChips(period: string, dayUploaded: string): ObligationChip[] {
  const mk = (
    id: string,
    label: string,
    detail: string,
    facilityId: ObligationChip['facilityId'],
  ): ObligationChip => ({ id, label, tone: 'teal', detail, facilityId })
  return [
    mk(`${period}-f1`, `FS-4 · flaring ${period} ✓ verified`, `Flaring (S1) · uploaded ${dayUploaded} · verified and in the official record.`, 'FAC-RIV-004'),
    mk(`${period}-f2`, `FS-4 · fuel gas ${period} ✓ verified`, `Fuel gas (S2) · uploaded ${dayUploaded} · verified and in the official record.`, 'FAC-RIV-004'),
    mk(`${period}-f3`, `FS-4 · diesel ${period} ✓ verified`, `Diesel (S3) · uploaded ${dayUploaded} · verified and in the official record.`, 'FAC-RIV-004'),
    mk(`${period}-c1`, `SCW-L2 · clinker ${period} ✓ verified`, `Clinker (S1) · uploaded ${dayUploaded} · verified and in the official record.`, 'FAC-KOG-002'),
    mk(`${period}-c2`, `SCW-L2 · petcoke ${period} ✓ verified`, `Petcoke (S2) · uploaded ${dayUploaded} · verified and in the official record.`, 'FAC-KOG-002'),
    mk(`${period}-c3`, `SCW-L2 · kiln gas ${period} ✓ verified`, `Kiln gas (S3) · uploaded ${dayUploaded} · verified and in the official record.`, 'FAC-KOG-002'),
  ]
}

const FUTURE_CHIPS: ObligationChip[] = [
  ...(['flaring', 'fuel gas', 'diesel'] as const).map(
    (s, i): ObligationChip => ({
      id: `aug-f${i}`,
      label: `FS-4 · ${s} Jul — due`,
      tone: 'muted',
      detail: `${s} · July 2026 · obligation opens 1 Aug 2026 — deadline 15 Aug 2026.`,
      facilityId: 'FAC-RIV-004',
    }),
  ),
  ...(['clinker', 'petcoke', 'kiln gas'] as const).map(
    (s, i): ObligationChip => ({
      id: `aug-c${i}`,
      label: `SCW-L2 · ${s} Jul — due`,
      tone: 'muted',
      detail: `${s} · July 2026 · obligation opens 1 Aug 2026 — deadline 15 Aug 2026.`,
      facilityId: 'FAC-KOG-002',
    }),
  ),
]

const MONTH_DATA: Record<string, MonthData> = {
  '2026-02': {
    chips: {
      15: [
        ...tealChips('Jan', '15 Feb 2026').filter((c) => c.id !== 'Jan-c1'),
        {
          id: 'Jan-c1',
          label: 'SCW-L2 · clinker Jan — LATE by 2 days',
          tone: 'alert',
          detail: 'Uploaded 17 Feb 2026 — recorded in DQI timeliness component.',
          facilityId: 'FAC-KOG-002',
        },
      ],
    },
    ticks: [],
  },
  '2026-06': { chips: { 15: tealChips('May', '15 Jun 2026') }, ticks: [] },
  '2026-07': { chips: { 15: JUNE_CHIPS }, ticks: [] },
  '2026-08': {
    chips: { 15: FUTURE_CHIPS },
    ticks: [{ day: 30, label: 'BS-22 / WF-07 calibration due (SCW-L2)' }],
  },
  '2026-09': {
    chips: { 15: [] },
    ticks: [{ day: 15, label: 'FL-201 calibration due (FS-4)' }],
  },
}

const MONTH_KEYS = ['2026-02', '2026-03', '2026-04', '2026-05', '2026-06', '2026-07', '2026-08', '2026-09']

const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
]

const WEEKDAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']

/* ------------------------------------------------------- calendar chip */

const CHIP_CLASSES: Record<ChipTone, string> = {
  teal: 'bg-petrol text-ivory',
  copper: 'border border-copper text-copper bg-transparent',
  alert: 'bg-alert text-ivory',
  muted: 'border border-line/70 text-muted bg-transparent border-dashed',
}

function CalendarChip({ chip, index }: { chip: ObligationChip; index: number }) {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <motion.button
          type="button"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.25, ease: EASE, delay: 0.3 + index * 0.05 }}
          className={cn(
            'block w-full rounded-[2px] px-1.5 py-1 text-left font-sans text-[9.5px] font-semibold leading-[1.3]',
            CHIP_CLASSES[chip.tone],
          )}
        >
          {chip.label}
        </motion.button>
      </PopoverTrigger>
      <PopoverContent
        align="start"
        className="w-[300px] rounded-[2px] border-line bg-ivory p-4"
      >
        <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ duration: 0.2, ease: EASE }}>
          <p className="font-sans text-[12px] font-semibold text-ink">{chip.label}</p>
          <p className="data-s mt-2 leading-[1.5] text-muted">{chip.detail}</p>
          <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 border-t border-line/40 pt-3">
            {chip.facilityId && (
              <Link
                to={`/regulator/facilities/${chip.facilityId}`}
                className="link-sweep font-sans text-[12px] font-medium text-petrol"
              >
                Open facility →
              </Link>
            )}
            <Link to="/operator/uploads" className="link-sweep font-sans text-[12px] font-medium text-petrol">
              Open upload →
            </Link>
          </div>
        </motion.div>
      </PopoverContent>
    </Popover>
  )
}

/* ------------------------------------------------------- calendar grid */

function CalendarGrid({ monthKey }: { monthKey: string }) {
  const [y, m] = monthKey.split('-').map(Number)
  const firstDow = (new Date(Date.UTC(y, m - 1, 1)).getUTCDay() + 6) % 7 // Monday-first
  const daysInMonth = new Date(Date.UTC(y, m, 0)).getUTCDate()
  const data = MONTH_DATA[monthKey] ?? { chips: {}, ticks: {} }
  const isCurrent = monthKey === '2026-07'
  const cells: Array<number | null> = [
    ...Array.from({ length: firstDow }, () => null),
    ...Array.from({ length: daysInMonth }, (_, i) => i + 1),
  ]
  while (cells.length % 7 !== 0) cells.push(null)

  return (
    <div>
      {/* weekday header */}
      <div className="grid grid-cols-7 border-b border-line/60">
        {WEEKDAYS.map((d) => (
          <p key={d} className="kicker px-2 py-2 text-muted">
            {d}
          </p>
        ))}
      </div>
      <div className="grid grid-cols-7">
        {cells.map((day, i) => {
          const chips = day ? (data.chips[day] ?? []) : []
          const ticks = day ? data.ticks.filter((t) => t.day === day) : []
          const isToday = isCurrent && day === 15
          const lastRow = i >= cells.length - 7
          return (
            <motion.div
              key={i}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: i * 0.01 }}
              className={cn(
                'relative min-h-[120px] border-line/40 p-1.5',
                !lastRow && 'border-b',
                i % 7 !== 6 && 'border-r',
                day === null && 'bg-sand/50',
              )}
            >
              {isToday && (
                <motion.span
                  aria-hidden="true"
                  className="pointer-events-none absolute inset-0 border border-copper"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.6, delay: 0.2 }}
                />
              )}
              {day !== null && (
                <>
                  <p
                    className={cn(
                      'px-0.5 font-sans text-[12px]',
                      isToday ? 'font-semibold text-copper' : 'text-muted',
                    )}
                  >
                    {day}
                    {isToday && <span className="data-s ml-1.5 uppercase">today</span>}
                  </p>
                  <div className="mt-1 flex flex-col gap-1">
                    {chips.map((c, ci) => (
                      <CalendarChip key={c.id} chip={c} index={ci} />
                    ))}
                    {ticks.map((t) => (
                      <p key={t.label} className="flex items-start gap-1.5 px-0.5 pt-1">
                        <span className="mt-[3px] h-[6px] w-[6px] shrink-0 bg-copper" />
                        <span className="font-mono text-[9.5px] leading-[1.35] tracking-[0.02em] text-muted">
                          {t.label}
                        </span>
                      </p>
                    ))}
                  </div>
                </>
              )}
            </motion.div>
          )
        })}
      </div>
    </div>
  )
}

/* ---------------------------------------------------------- list view */

interface ObligationRow {
  obligation: string
  facility: string
  facilityId: string
  stream: string
  period: string
  deadline: string
  status: string
  statusRank: number // 0 = breach, 1 = pending, 2 = verified
  variance: number // days vs deadline (+ = late)
  dqiImpact: string
}

const OBLIGATIONS: ObligationRow[] = [
  { obligation: 'Monthly activity data', facility: 'NigerDelta Flow Station 4', facilityId: 'FAC-RIV-004', stream: 'S1 · Associated gas flared', period: 'Jun 2026', deadline: '15 Jul 2026', status: 'Uploaded — pending verification', statusRank: 1, variance: 0, dqiImpact: '—' },
  { obligation: 'Monthly activity data', facility: 'NigerDelta Flow Station 4', facilityId: 'FAC-RIV-004', stream: 'S2 · Fuel gas consumed', period: 'Jun 2026', deadline: '15 Jul 2026', status: 'Uploaded — pending verification', statusRank: 1, variance: 0, dqiImpact: '—' },
  { obligation: 'Monthly activity data', facility: 'NigerDelta Flow Station 4', facilityId: 'FAC-RIV-004', stream: 'S3 · Diesel consumed', period: 'Jun 2026', deadline: '15 Jul 2026', status: 'Due today — not uploaded', statusRank: 0, variance: 0, dqiImpact: 'timeliness at risk' },
  { obligation: 'Monthly activity data', facility: 'Sahel Cement Works, Line 2', facilityId: 'FAC-KOG-002', stream: 'S1 · Clinker production', period: 'Jun 2026', deadline: '15 Jul 2026', status: 'Uploaded — pending verification', statusRank: 1, variance: 0, dqiImpact: '—' },
  { obligation: 'Monthly activity data', facility: 'Sahel Cement Works, Line 2', facilityId: 'FAC-KOG-002', stream: 'S2 · Kiln fuel — petcoke', period: 'Jun 2026', deadline: '15 Jul 2026', status: 'Uploaded — pending verification', statusRank: 1, variance: 0, dqiImpact: '—' },
  { obligation: 'Monthly activity data', facility: 'Sahel Cement Works, Line 2', facilityId: 'FAC-KOG-002', stream: 'S3 · Kiln fuel — natural gas', period: 'Jun 2026', deadline: '15 Jul 2026', status: 'Uploaded — pending verification', statusRank: 1, variance: 0, dqiImpact: '—' },
  { obligation: 'Monthly activity data', facility: 'Sahel Cement Works, Line 2', facilityId: 'FAC-KOG-002', stream: 'S1 · Clinker production', period: 'Jan 2026', deadline: '15 Feb 2026', status: 'Uploaded late — verified', statusRank: 0, variance: 2, dqiImpact: 'recorded in timeliness' },
]

function statusCell(r: ObligationRow) {
  if (r.status.startsWith('Due today'))
    return <span className="font-sans text-[12px] font-semibold text-alert">{r.status}</span>
  if (r.status.startsWith('Uploaded late'))
    return <span className="font-sans text-[12px] font-semibold text-alert">{r.status}</span>
  return (
    <span className="flex flex-col gap-1">
      <span className="font-sans text-[12px] font-medium text-copper">{r.status}</span>
      <AILabel />
    </span>
  )
}

function ListView() {
  const [sortKey, setSortKey] = useState<'status' | 'variance' | null>(null)
  const [dir, setDir] = useState<1 | -1>(1)
  const rows = useMemo(() => {
    if (!sortKey) return OBLIGATIONS
    const sorted = [...OBLIGATIONS].sort((a, b) => {
      const v = sortKey === 'status' ? a.statusRank - b.statusRank : a.variance - b.variance
      return v * dir
    })
    return sorted
  }, [sortKey, dir])

  const toggleSort = (k: 'status' | 'variance') => {
    if (sortKey === k) setDir((d) => (d === 1 ? -1 : 1))
    else {
      setSortKey(k)
      setDir(1)
    }
  }

  const sortableHeader = (label: string, k: 'status' | 'variance') => (
    <button
      type="button"
      onClick={() => toggleSort(k)}
      className="inline-flex items-center gap-1.5 uppercase tracking-kicker transition-colors hover:text-ink"
    >
      {label}
      <span className={cn('font-mono text-[10px]', sortKey === k ? 'text-copper' : 'text-line')}>
        {sortKey === k ? (dir === 1 ? '▲' : '▼') : <ArrowDownUp className="h-3 w-3" strokeWidth={1.75} />}
      </span>
    </button>
  )

  return (
    <DataTable>
      <DataTableHead
        columns={[
          'Obligation',
          'Facility',
          'Stream',
          'Period',
          'Deadline',
          sortableHeader('Status', 'status'),
          sortableHeader('Days variance', 'variance'),
          'DQI impact',
        ]}
      />
      <tbody>
        {rows.map((r, i) => (
          <DataTableRow key={`${r.facilityId}-${r.stream}-${r.period}`}>
            <DataTableCell mono={false}>
              <motion.span
                className="block"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.35, ease: EASE, delay: i * 0.03 }}
              >
                {r.obligation}
              </motion.span>
            </DataTableCell>
            <DataTableCell mono={false}>
              <Link to={`/regulator/facilities/${r.facilityId}`} className="link-sweep text-petrol">
                {r.facility}
              </Link>
            </DataTableCell>
            <DataTableCell mono={false}>{r.stream}</DataTableCell>
            <DataTableCell>{r.period}</DataTableCell>
            <DataTableCell>{r.deadline}</DataTableCell>
            <DataTableCell mono={false}>{statusCell(r)}</DataTableCell>
            <DataTableCell className={cn(r.variance > 0 && 'font-semibold text-alert')}>
              {r.variance > 0 ? `+${r.variance}` : '0'}
            </DataTableCell>
            <DataTableCell mono={false}>
              <span className="font-sans text-[12px] text-muted">{r.dqiImpact}</span>
            </DataTableCell>
          </DataTableRow>
        ))}
      </tbody>
    </DataTable>
  )
}

/* -------------------------------------------------------- alerts panel */

interface AlertRow {
  glyph: 'diamond-alert' | 'diamond-copper' | 'clock-alert' | 'clock-copper' | 'check'
  text: string
  ts: string
  to: string
  queue?: boolean
}

const ALERT_GROUPS: Array<{ title: string; rows: AlertRow[] }> = [
  {
    title: 'Anomaly flags',
    rows: [
      { glyph: 'diamond-alert', text: 'Flaring intensity +45% — FS-4, Mar 2026 — pending verification', ts: 'flag raised 15 Apr 2026', to: '/regulator/facilities/FAC-RIV-004', queue: true },
      { glyph: 'diamond-alert', text: 'Repeated identical values — SCW-L2 clinker, Feb 2026 — queried 3 days ago', ts: 'queried 12 Jul 2026', to: '/regulator/facilities/FAC-KOG-002', queue: true },
      { glyph: 'diamond-copper', text: 'Peer deviation borderline — SCW-L2 petcoke, Jun 2026', ts: 'flag raised 15 Jul 2026', to: '/regulator/facilities/FAC-KOG-002', queue: true },
    ],
  },
  {
    title: 'Deadlines',
    rows: [
      { glyph: 'clock-alert', text: 'Diesel Jun 2026 — due today, not uploaded (FS-4)', ts: '15 Jul 2026 · due today', to: '/regulator/facilities/FAC-RIV-004' },
    ],
  },
  {
    title: 'Calibration & permits',
    rows: [
      { glyph: 'clock-copper', text: 'FL-201 calibration due in 62 days — ultrasonic meter, FS-4 flaring', ts: 'due 15 Sep 2026', to: '/regulator/facilities/FAC-RIV-004' },
      { glyph: 'clock-copper', text: 'BS-22 & WF-07 due in 46 days — belt scale / weighfeeder, SCW-L2', ts: 'due 30 Aug 2026', to: '/regulator/facilities/FAC-KOG-002' },
    ],
  },
  {
    title: 'Approvals',
    rows: [
      { glyph: 'check', text: 'No plans awaiting approval', ts: 'as of 15 Jul 2026', to: '/regulator' },
    ],
  },
]

function AlertGlyph({ glyph }: { glyph: AlertRow['glyph'] }) {
  if (glyph === 'diamond-alert') return <Diamond tone="alert" />
  if (glyph === 'diamond-copper') return <Diamond tone="copper" />
  if (glyph === 'clock-alert') return <Clock className="h-3.5 w-3.5 shrink-0 text-alert" strokeWidth={1.75} />
  if (glyph === 'clock-copper') return <Clock className="h-3.5 w-3.5 shrink-0 text-copper" strokeWidth={1.75} />
  return <Check className="h-3.5 w-3.5 shrink-0 text-petrol" strokeWidth={2} />
}

function AlertsPanel() {
  return (
    <div className="flex flex-col gap-8">
      {ALERT_GROUPS.map((g, gi) => (
        <div key={g.title}>
          <div className="mb-3 flex items-center gap-3">
            <p className="kicker shrink-0 text-muted">{g.title}</p>
            <motion.span
              className="h-px w-full origin-left bg-line/60"
              initial={{ scaleX: 0 }}
              whileInView={{ scaleX: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, ease: EASE, delay: gi * 0.1 }}
            />
          </div>
          <div className="flex flex-col">
            {g.rows.map((r, i) => (
              <motion.div
                key={r.text}
                initial={{ opacity: 0, x: -16 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, amount: 0.4 }}
                transition={{ duration: 0.45, ease: EASE, delay: gi * 0.1 + i * 0.05 }}
                className={cn(
                  'flex flex-wrap items-center gap-x-4 gap-y-2 border-b border-line/40 py-3.5 last:border-b-0',
                  r.glyph === 'check' && 'opacity-70',
                )}
              >
                <span className="flex min-w-0 flex-1 items-center gap-3">
                  <AlertGlyph glyph={r.glyph} />
                  <span className="font-sans text-[13px] text-ink">{r.text}</span>
                </span>
                <span className="data-s shrink-0 text-muted">{r.ts}</span>
                <span className="flex shrink-0 items-center gap-4">
                  <Link to={r.to} className="link-sweep font-sans text-[12px] font-medium text-petrol">
                    View →
                  </Link>
                  {r.queue && (
                    <span className="flex items-center gap-1.5">
                      <Link to="/verifier" className="link-sweep font-sans text-[12px] font-medium text-petrol">
                        Open in verifier queue →
                      </Link>
                      <span className="data-s text-muted">(verifier workspace — read access)</span>
                    </span>
                  )}
                </span>
              </motion.div>
            ))}
          </div>
        </div>
      ))}
    </div>
  )
}

/* ---------------------------------------------------- notification rules */

function RulesModal() {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <button
          type="button"
          aria-label="Notification rules"
          className="rounded-[2px] border border-line/60 p-2 text-muted transition-colors hover:border-ink hover:text-ink"
        >
          <Settings2 className="h-4 w-4" strokeWidth={1.75} />
        </button>
      </DialogTrigger>
      <DialogContent className="max-w-[560px] rounded-[2px] border-line bg-ivory">
        <DialogHeader>
          <DialogTitle className="font-display text-[24px] font-normal text-ink">
            Notification rules
          </DialogTitle>
          <DialogDescription className="font-sans text-[13px] text-muted">
            Read-only display — rules are set by the MRV Directorate and versioned on the chain.
          </DialogDescription>
        </DialogHeader>
        <div className="flex flex-col divide-y divide-line/40">
          {[
            ['Reporting deadline', 'Activity data due by the 15th of the following month.'],
            ...ANOMALY_RULES.map((r) => ['Anomaly rule', r] as [string, string]),
            ['Calibration warnings', '90 / 60 / 30 days before calibration due date.'],
            ['Escalation', 'Persistent breach escalates to the Director, MRV — recorded on the chain.'],
          ].map(([k, v]) => (
            <div key={v} className="grid grid-cols-[170px_1fr] gap-4 py-3">
              <p className="kicker pt-0.5 text-muted">{k}</p>
              <p className="font-sans text-[13px] leading-[1.5] text-ink">{v}</p>
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  )
}

/* ==================================================================== */

function CompactStat({
  label,
  value,
  tone,
  sub,
  delay,
}: {
  label: string
  value: number
  tone: 'teal' | 'copper' | 'alert' | 'ink'
  sub?: ReactNode
  delay: number
}) {
  const [v, ref] = useCountUpInView(value, 1000)
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, ease: EASE, delay }}
      className="flex flex-col gap-1.5"
    >
      <span className="kicker text-muted">{label}</span>
      <span
        ref={ref}
        className={cn(
          'font-display text-[40px] leading-none',
          tone === 'teal' && 'text-petrol',
          tone === 'copper' && 'text-copper',
          tone === 'alert' && 'text-alert',
          tone === 'ink' && 'text-ink',
        )}
      >
        {Math.round(v)}
      </span>
      {sub && <span className="font-sans text-[12px] text-muted">{sub}</span>}
    </motion.div>
  )
}

export default function Compliance() {
  const [monthIdx, setMonthIdx] = useState(MONTH_KEYS.indexOf('2026-07'))
  const [slideDir, setSlideDir] = useState<1 | -1>(1)
  const [view, setView] = useState<'calendar' | 'list'>('calendar')
  const monthKey = MONTH_KEYS[monthIdx]
  const [y, m] = monthKey.split('-').map(Number)
  const monthLabel = `${MONTH_NAMES[m - 1]} ${y}`

  const go = (delta: number) => {
    const next = monthIdx + delta
    if (next < 0 || next >= MONTH_KEYS.length) return
    setSlideDir(delta > 0 ? 1 : -1)
    setMonthIdx(next)
  }

  return (
    <div className="flex flex-col gap-10">
      {/* ── Section 1 — page header ─────────────────────────────────── */}
      <motion.header
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: EASE }}
        className="flex flex-wrap items-end justify-between gap-6"
      >
        <div>
          <p className="kicker text-muted">NCCC / Compliance</p>
          <h1 className="mt-3 font-display text-[40px] leading-[1.05] text-ink">
            Compliance calendar.
          </h1>
          <p className="mt-3 max-w-[640px] font-sans text-[15px] leading-[1.6] text-muted">
            Reporting obligations, deadlines and breaches across the portfolio. Rule: activity data
            due by the 15th of the following month.
          </p>
        </div>
        <div className="flex items-center gap-3">
          {/* month navigator (mono) */}
          <div className="flex items-center rounded-[2px] border border-line/60">
            <button
              type="button"
              onClick={() => go(-1)}
              disabled={monthIdx === 0}
              aria-label="Previous month"
              className="p-2 text-muted transition-colors hover:text-ink disabled:opacity-40 disabled:hover:text-muted"
            >
              <ChevronLeft className="h-4 w-4" strokeWidth={1.75} />
            </button>
            <span className="min-w-[110px] text-center font-mono text-[12px] text-ink">
              {monthLabel}
            </span>
            <button
              type="button"
              onClick={() => go(1)}
              disabled={monthIdx === MONTH_KEYS.length - 1}
              aria-label="Next month"
              className="p-2 text-muted transition-colors hover:text-ink disabled:opacity-40 disabled:hover:text-muted"
            >
              <ChevronRight className="h-4 w-4" strokeWidth={1.75} />
            </button>
          </div>
          {/* view toggle */}
          <div className="flex rounded-[2px] border border-line/60">
            {(['calendar', 'list'] as const).map((v) => (
              <button
                key={v}
                type="button"
                onClick={() => setView(v)}
                className={cn(
                  'px-3 py-[7px] font-sans text-[11px] font-semibold uppercase tracking-chip transition-colors duration-200',
                  view === v ? 'bg-petrol text-ivory' : 'text-muted hover:text-ink',
                )}
              >
                {v}
              </button>
            ))}
          </div>
          <RulesModal />
        </div>
      </motion.header>

      {/* ── Section 2 — status summary band (June 2026 cycle) ───────── */}
      <Reveal>
        <section className="rounded-[2px] border border-line/60 bg-ivory px-8 py-6">
          <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
            <p className="kicker text-muted">June 2026 cycle — 6 obligations (2 facilities × 3 streams)</p>
            <p className="data-s text-muted">due 15 Jul 2026 · today</p>
          </div>
          <div className="grid grid-cols-2 gap-6 md:grid-cols-4">
            <CompactStat label="Reported" value={5} tone="teal" delay={0} sub="uploaded on or before deadline" />
            <CompactStat
              label="Pending verification"
              value={4}
              tone="copper"
              delay={0.08}
              sub={
                <span className="flex flex-col gap-1.5">
                  <AILabel />
                </span>
              }
            />
            <CompactStat label="Due today — not uploaded" value={1} tone="alert" delay={0.16} sub="FS-4 · diesel (S3)" />
            <CompactStat label="Late" value={0} tone="ink" delay={0.24} sub="no breach this cycle" />
          </div>
        </section>
      </Reveal>

      {/* ── Section 3 / 4 — calendar grid · list view ───────────────── */}
      <Reveal>
        <Panel
          kicker={view === 'calendar' ? `${monthLabel} — obligations` : 'All obligations — portfolio'}
          right={
            view === 'calendar' ? (
              <p className="data-s text-muted">
                deadline day: 15th · tick = calibration / permit event
              </p>
            ) : undefined
          }
          bodyClassName={view === 'calendar' ? 'p-0' : undefined}
        >
          <AnimatePresence mode="wait">
            {view === 'calendar' ? (
              <motion.div
                key={`cal-${monthKey}`}
                initial={{ opacity: 0, x: 24 * slideDir }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -24 * slideDir }}
                transition={{ duration: 0.3, ease: EASE }}
              >
                <CalendarGrid monthKey={monthKey} />
              </motion.div>
            ) : (
              <motion.div
                key="list"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.25, ease: EASE }}
              >
                <ListView />
              </motion.div>
            )}
          </AnimatePresence>
        </Panel>
      </Reveal>

      {/* legend */}
      {view === 'calendar' && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.4, delay: 0.3 }}
          className="-mt-6 flex flex-wrap items-center gap-x-6 gap-y-2"
        >
          <span className="kicker text-muted">Legend</span>
          <span className="flex items-center gap-2">
            <span className="h-[10px] w-[10px] rounded-[2px] bg-petrol" />
            <span className="data-s text-muted">reported / verified</span>
          </span>
          <span className="flex items-center gap-2">
            <span className="h-[10px] w-[10px] rounded-[2px] border border-copper" />
            <span className="data-s text-muted">uploaded, pending verification</span>
          </span>
          <span className="flex items-center gap-2">
            <span className="h-[10px] w-[10px] rounded-[2px] bg-alert" />
            <span className="data-s text-muted">late / due today</span>
          </span>
          <span className="flex items-center gap-2">
            <span className="h-[6px] w-[6px] bg-copper" />
            <span className="data-s text-muted">calibration / permit event</span>
          </span>
        </motion.div>
      )}

      {/* ── Section 5 — alerts panel (consolidated) ─────────────────── */}
      <Reveal>
        <section>
          <LedgerRule className="mb-4" />
          <p className="kicker mb-6 text-muted">All alerts — portfolio</p>
          <AlertsPanel />
        </section>
      </Reveal>

      {/* ── Section 6 — escalation note (dark band) ─────────────────── */}
      <Reveal>
        <motion.section
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.25 }}
          transition={{ duration: 0.6, ease: EASE }}
          className="rounded-[2px] bg-petrol-deep px-8 py-10"
        >
          <p className="kicker text-copper-light">Escalation discipline</p>
          <p className="mt-4 max-w-[820px] font-sans text-[14px] leading-[1.7] text-ivory/85">
            A missed deadline is not a phone call. It is a recorded event: it moves DQI, it appears
            here, and it stays on the facility&apos;s immutable history. Persistent breach escalates
            to the Director, MRV — and that escalation is also on the chain.
          </p>
        </motion.section>
      </Reveal>
    </div>
  )
}
