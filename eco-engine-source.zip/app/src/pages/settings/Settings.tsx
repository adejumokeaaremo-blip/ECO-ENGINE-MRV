/**
 * Page 15 — Settings & Demo Controls (`/settings`), settings-demo.md.
 * Shared settings for all roles + the Demonstrator presenter console:
 * reset data, replay tours, switch roles, watermark, presentation mode.
 */
import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router'
import { AnimatePresence, motion } from 'framer-motion'
import {
  Check,
  KeyRound,
  Laptop,
  RotateCcw,
  Smartphone,
  TriangleAlert,
} from 'lucide-react'
import { toast } from 'sonner'
import HashChip from '@/components/app/HashChip'
import LedgerRule from '@/components/app/LedgerRule'
import DataTable, {
  DataTableCell,
  DataTableHead,
  DataTableRow,
} from '@/components/app/DataTable'
import {
  appendAudit,
  demoHash,
  resetDemo,
  useAuditTrail,
  useRole,
  useSubmissions,
  type Role,
} from '@/lib/store'
import { COMPANY, PERSONAS } from '@/lib/demo-data'
import { cn } from '@/lib/utils'

/* ------------------------------------------------------------ role records */

const ROLE_EMAILS: Record<Role, string> = {
  operator: 't.wokoma@deltacrest-demo.ng',
  verifier: 'f.okafor@greenline-demo.ng',
  regulator: 'a.bello@nccc-demo.gov.ng',
  compiler: 's.eze@nimo-demo.gov.ng',
}

const ROLE_ORGS: Record<Role, Array<[string, string]>> = {
  operator: [
    ['Organisation', 'Delta Crest Energy Ltd (demo)'],
    ['RC / TIN', 'RC 1884210 · TIN 20884411-0001 (demo)'],
    ['Sector', 'Oil & Gas (upstream)'],
    ['Primary contact', 'Engr. T. Wokoma — Facility Environmental Manager'],
  ],
  verifier: [
    ['Organisation', 'Greenline Assurance Partners (demo) — independent assurance provider'],
    ['Accreditation', 'AV/2024/0142 (demo) · ISO 14065'],
    ['Sector', 'Third-party verification & assurance'],
    ['Primary contact', 'Dr. F. Okafor — Accredited Verifier'],
  ],
  regulator: [
    ['Organisation', 'National Council on Climate Change — MRV Directorate'],
    ['Mandate', 'National oversight of industrial GHG reporting (demo)'],
    ['Sector', 'Government · climate regulation'],
    ['Primary contact', 'A. Bello — Deputy Director, MRV Directorate'],
  ],
  compiler: [
    ['Organisation', 'NIMO — National Inventory Management Office'],
    ['Mandate', 'National GHG inventory compilation, IPCC 2006/2019 (demo)'],
    ['Sector', 'Government · national inventory'],
    ['Primary contact', 'S. Eze — National Inventory Compiler'],
  ],
}

interface Session {
  id: string
  device: string
  kind: 'laptop' | 'phone'
  location: string
  lastActive: string
  current: boolean
}

const SESSIONS_SEED: Session[] = [
  { id: 'ses-01', device: 'Chrome 138 · Windows 11 (this device)', kind: 'laptop', location: 'Abuja, FCT (demo)', lastActive: 'Active now', current: true },
  { id: 'ses-02', device: 'Safari · iPhone 15 (demo)', kind: 'phone', location: 'Abuja, FCT (demo)', lastActive: '14 Jul 2026 21:40', current: false },
]

const DEMO_SCRIPT_STEPS = [
  'Operator uploads June data',
  'AI estimate + flag',
  'Verifier accepts',
  'Regulator dashboard',
  'NIMO export',
]

const VISITED_KEY = 'ecoengine-visited-roles'

type TabId = 'profile' | 'organisation' | 'security' | 'demonstrator' | 'about'

const TABS: Array<[TabId, string]> = [
  ['profile', 'Profile'],
  ['organisation', 'Organisation'],
  ['security', 'Security'],
  ['demonstrator', 'Demonstrator'],
  ['about', 'About'],
]

/* ------------------------------------------------------------------- page */

export default function Settings() {
  const { role, persona, setRole } = useRole()
  const audit = useAuditTrail()
  const submissions = useSubmissions()
  const navigate = useNavigate()

  const [tab, setTab] = useState<TabId>('profile')
  const [editing, setEditing] = useState(false)
  const [profile, setProfile] = useState({ name: persona.name, email: ROLE_EMAILS[role], phone: '+234 803 … (demo)' })
  const [sessions, setSessions] = useState<Session[]>(SESSIONS_SEED)
  const [confirmReset, setConfirmReset] = useState(false)
  const [resetting, setResetting] = useState(false)
  const [presentation, setPresentation] = useState(false)

  /* keep profile fields in step with the active persona */
  useEffect(() => {
    setProfile({ name: persona.name, email: ROLE_EMAILS[role], phone: '+234 803 … (demo)' })
    setEditing(false)
  }, [persona.name, role])

  /* presentation mode: +12% base font, broadcast so pages tuck filters behind "Advanced" */
  useEffect(() => {
    const root = document.documentElement
    const prev = root.style.fontSize
    if (presentation) root.style.fontSize = '112%'
    window.dispatchEvent(new CustomEvent('ecoengine:presentation-mode', { detail: { on: presentation } }))
    return () => {
      root.style.fontSize = prev
    }
  }, [presentation])

  const visitedRoles = useMemo<Role[]>(() => {
    try {
      return JSON.parse(localStorage.getItem(VISITED_KEY) ?? '[]') as Role[]
    } catch {
      return []
    }
  }, [presentation]) // eslint-disable-line react-hooks/exhaustive-deps

  const switchRole = (r: Role) => {
    const home = PERSONAS.find((p) => p.role === r)?.home ?? '/'
    const visited = Array.from(new Set([...visitedRoles, role]))
    try {
      localStorage.setItem(VISITED_KEY, JSON.stringify(visited))
    } catch {
      /* demonstrator continues in-memory */
    }
    setRole(r)
    navigate(home)
  }

  const replayTour = (r: Role) => {
    window.dispatchEvent(new CustomEvent('ecoengine:replay-tour', { detail: { role: r } }))
    toast(`Replaying the ${r} guided tour.`)
  }

  const saveProfile = () => {
    setEditing(false)
    appendAudit({
      actor: persona.name,
      role,
      action: 'PROFILE_UPDATED',
      entity: 'profile',
      detail: 'Profile details updated via Settings',
    })
    toast.success('Profile updated — logged to audit chain.')
  }

  const revokeSession = (s: Session) => {
    setSessions((list) => list.filter((x) => x.id !== s.id))
    appendAudit({
      actor: persona.name,
      role,
      action: 'SESSION_REVOKED',
      entity: s.id,
      detail: `Session revoked — ${s.device}`,
    })
    toast('Session revoked — logged to audit chain.')
  }

  const doReset = () => {
    setConfirmReset(false)
    setResetting(true)
    setTimeout(() => {
      resetDemo()
      setResetting(false)
      setSessions(SESSIONS_SEED)
      toast.success('Scenario restored — 2 facilities, 12 months, the seeded anomalies.')
    }, 1500)
  }

  /* demo-script checklist ticks, derived from live demo state */
  const scriptTicks: boolean[] = [
    submissions.some((s) => s.period === 'June 2026'),
    submissions.some((s) => s.flag !== null),
    submissions.some((s) => s.status === 'Accepted'),
    visitedRoles.includes('regulator') || role === 'regulator',
    audit.some((e) => e.action === 'EXPORT_GENERATED'),
  ]

  const loginEvents = useMemo(
    () => audit.filter((e) => e.action === 'LOGIN').slice(-3).reverse(),
    [audit],
  )

  const orgRows = ROLE_ORGS[role]

  return (
    <div className="flex flex-col gap-8">
      {/* §1 — header */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      >
        <p className="kicker text-muted">{role} / Settings</p>
        <h1 className="mt-2 font-display text-[40px] leading-[1.05] text-ink">Settings.</h1>
      </motion.div>

      {/* §2 — tab rail + content */}
      <div className="grid grid-cols-1 gap-8 md:grid-cols-[200px_1fr]">
        <div className="flex flex-row gap-1 overflow-x-auto md:flex-col md:gap-0">
          {TABS.map(([id, label]) => (
            <button
              key={id}
              type="button"
              onClick={() => setTab(id)}
              className={cn(
                'kicker relative whitespace-nowrap px-4 py-3 text-left transition-colors',
                tab === id
                  ? 'text-petrol before:absolute before:bottom-0 before:left-0 before:h-[2px] before:w-full before:bg-petrol md:before:h-full md:before:w-[2px]'
                  : 'text-muted hover:text-ink',
              )}
            >
              {label}
            </button>
          ))}
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={tab}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="min-w-0"
          >
            {/* ---------------------------------------------- Tab 1 — Profile */}
            {tab === 'profile' && (
              <section className="rounded-[2px] border border-line/60 bg-ivory p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="flex h-9 w-9 items-center justify-center bg-petrol font-mono text-[12px] font-medium text-ivory">
                      {persona.initials}
                    </span>
                    <div>
                      <p className="font-sans text-[15px] font-semibold text-ink">{persona.name}</p>
                      <p className="font-sans text-[12px] text-muted">{persona.detail}</p>
                    </div>
                  </div>
                  {editing ? (
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setEditing(false)}
                        className="rounded-[2px] border border-ink/30 px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ink transition-all duration-200 hover:-translate-y-px hover:border-ink hover:bg-sand"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        onClick={saveProfile}
                        className="rounded-[2px] bg-petrol px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ivory transition-all duration-200 hover:-translate-y-px hover:bg-petrol-deep"
                      >
                        Save
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setEditing(true)}
                      className="rounded-[2px] border border-ink/30 px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ink transition-all duration-200 hover:-translate-y-px hover:border-ink hover:bg-sand"
                    >
                      Edit
                    </button>
                  )}
                </div>
                <div className="mt-6 flex flex-col">
                  {(
                    [
                      ['Name', 'name'],
                      ['Role', null],
                      ['Accreditation', null],
                      ['Email', 'email'],
                      ['Phone', 'phone'],
                    ] as Array<[string, 'name' | 'email' | 'phone' | null]>
                  ).map(([label, field]) => (
                    <div key={label} className="flex flex-col gap-1 border-b border-line/40 py-3 sm:flex-row sm:items-center sm:justify-between">
                      <span className="kicker text-muted">{label}</span>
                      {editing && field ? (
                        <input
                          value={profile[field]}
                          onChange={(e) => setProfile((p) => ({ ...p, [field]: e.target.value }))}
                          className="w-full max-w-[360px] rounded-[2px] border border-line bg-sand px-3 py-2 font-sans text-[14px] text-ink"
                        />
                      ) : (
                        <span className="font-sans text-[14px] text-ink">
                          {field === 'name' && profile.name}
                          {field === 'email' && profile.email}
                          {field === 'phone' && profile.phone}
                          {label === 'Role' && persona.title}
                          {label === 'Accreditation' &&
                            (role === 'verifier' ? 'AV/2024/0142 (demo)' : '—')}
                        </span>
                      )}
                    </div>
                  ))}
                </div>
                <p className="mt-4 font-sans text-[12px] leading-[1.5] text-muted">
                  Even profile edits are audit events — saving appends an entry to the hash chain.
                </p>
              </section>
            )}

            {/* ----------------------------------------- Tab 2 — Organisation */}
            {tab === 'organisation' && (
              <section className="rounded-[2px] border border-line/60 bg-ivory p-6">
                <LedgerRule className="mb-4" />
                <p className="kicker text-muted">Organisation record</p>
                <div className="mt-4 flex flex-col">
                  {orgRows.map(([k, v]) => (
                    <div key={k} className="flex flex-col gap-1 border-b border-line/40 py-3 sm:flex-row sm:items-center sm:justify-between">
                      <span className="kicker text-muted">{k}</span>
                      <span className="max-w-[480px] font-sans text-[14px] text-ink sm:text-right">{v}</span>
                    </div>
                  ))}
                </div>
                <p className="mt-4 font-sans text-[12px] leading-[1.5] text-muted">
                  Organisation records are regulator-maintained in the demonstrator and read-only
                  here.
                </p>
              </section>
            )}

            {/* ---------------------------------------------- Tab 3 — Security */}
            {tab === 'security' && (
              <div className="flex flex-col gap-6">
                <section className="rounded-[2px] border border-line/60 bg-ivory p-6">
                  <LedgerRule className="mb-4" />
                  <p className="kicker text-muted">Active sessions</p>
                  <div className="mt-4">
                    <DataTable>
                      <DataTableHead columns={['Device', 'Location', 'Last active', '']} />
                      <tbody>
                        <AnimatePresence initial={false}>
                          {sessions.map((s) => (
                            <DataTableRow key={s.id}>
                              <DataTableCell mono={false}>
                                <motion.span
                                  layout
                                  exit={{ opacity: 0, height: 0 }}
                                  transition={{ duration: 0.3 }}
                                  className="flex items-center gap-2 font-sans text-[13px] text-ink"
                                >
                                  {s.kind === 'laptop' ? (
                                    <Laptop className="h-3.5 w-3.5 text-muted" strokeWidth={1.75} />
                                  ) : (
                                    <Smartphone className="h-3.5 w-3.5 text-muted" strokeWidth={1.75} />
                                  )}
                                  {s.device}
                                </motion.span>
                              </DataTableCell>
                              <DataTableCell mono={false} className="text-muted">{s.location}</DataTableCell>
                              <DataTableCell className={s.current ? 'text-petrol' : undefined}>{s.lastActive}</DataTableCell>
                              <DataTableCell mono={false} className="text-right">
                                {s.current ? (
                                  <span className="data-s text-muted">current</span>
                                ) : (
                                  <button
                                    type="button"
                                    onClick={() => revokeSession(s)}
                                    className="font-sans text-[12px] font-semibold text-alert transition-colors hover:underline"
                                  >
                                    Revoke
                                  </button>
                                )}
                              </DataTableCell>
                            </DataTableRow>
                          ))}
                        </AnimatePresence>
                      </tbody>
                    </DataTable>
                  </div>
                </section>

                <section className="rounded-[2px] border border-line/60 bg-ivory p-6">
                  <div className="flex flex-col gap-1 border-b border-line/40 py-3 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                      <span className="kicker text-muted">Password</span>
                      <p className="mt-1 font-sans text-[12px] text-muted">
                        Authentication is simulated in the demonstrator.
                      </p>
                    </div>
                    <button
                      type="button"
                      disabled
                      className="rounded-[2px] border border-ink/30 px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ink opacity-40"
                    >
                      Change password
                    </button>
                  </div>
                  <div className="flex flex-col gap-1 border-b border-line/40 py-3 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                      <span className="kicker text-muted">Two-factor authentication</span>
                      <p className="mt-1 font-sans text-[12px] text-muted">
                        Disabled in the demonstration build.
                      </p>
                    </div>
                    <span className="relative inline-flex h-5 w-9 items-center rounded-full bg-line/60">
                      <span className="absolute left-0.5 h-4 w-4 rounded-full bg-ivory" />
                    </span>
                  </div>
                </section>

                <section className="rounded-[2px] border border-line/60 bg-ivory p-6">
                  <LedgerRule className="mb-4" />
                  <p className="kicker text-muted">Login history — chain events</p>
                  <div className="mt-4 flex flex-col gap-3">
                    {loginEvents.length === 0 && (
                      <p className="font-sans text-[13px] text-muted">No login events on the chain yet.</p>
                    )}
                    {loginEvents.map((e) => (
                      <div key={e.seq} className="flex flex-wrap items-center justify-between gap-3 border-b border-line/40 pb-3">
                        <div className="flex items-center gap-2">
                          <KeyRound className="h-3.5 w-3.5 text-muted" strokeWidth={1.75} />
                          <span className="font-sans text-[13px] text-ink">{e.actor}</span>
                          <span className="data-s text-muted">#{e.seq} · {e.ts.slice(0, 10)}</span>
                        </div>
                        <HashChip hash={e.hash} />
                      </div>
                    ))}
                  </div>
                </section>
              </div>
            )}

            {/* ------------------------------------------ Tab 4 — Demonstrator */}
            {tab === 'demonstrator' && (
              <div className="flex flex-col gap-6">
                <motion.section
                  initial="hidden"
                  animate="show"
                  variants={{ show: { transition: { staggerChildren: 0.06 } } }}
                  className="rounded-[2px] border border-copper/50 bg-ivory p-6"
                >
                  <LedgerRule className="mb-4" />
                  <p className="kicker text-copper">Demonstrator controls</p>

                  {/* 1 — reset */}
                  <motion.div variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0 } }} className="flex flex-col gap-2 border-b border-line/40 py-4 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                      <p className="font-sans text-[14px] font-semibold text-ink">Reset demonstration data</p>
                      <p className="mt-1 max-w-[520px] font-sans text-[12px] leading-[1.5] text-muted">
                        Restores the seeded scenario: 2 facilities, 12 months of records, the March
                        flare spike, the February identical-values query, and the pending June uploads.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setConfirmReset(true)}
                      className="flex shrink-0 items-center gap-2 rounded-[2px] border border-alert px-[18px] py-[10px] font-sans text-[13px] font-semibold text-alert transition-all duration-200 hover:-translate-y-px hover:bg-alert hover:text-ivory"
                    >
                      <RotateCcw className="h-3.5 w-3.5" strokeWidth={1.75} />
                      Reset demo data
                    </button>
                  </motion.div>

                  {/* 2 — replay tours */}
                  <motion.div variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0 } }} className="flex flex-col gap-2 border-b border-line/40 py-4">
                    <p className="font-sans text-[14px] font-semibold text-ink">Replay guided tour</p>
                    <div className="mt-1 flex flex-wrap gap-x-5 gap-y-2">
                      {PERSONAS.map((p) => (
                        <button
                          key={p.role}
                          type="button"
                          onClick={() => replayTour(p.role)}
                          className="link-sweep font-sans text-[13px] font-semibold text-petrol"
                        >
                          {p.role.charAt(0).toUpperCase() + p.role.slice(1)} tour
                        </button>
                      ))}
                    </div>
                  </motion.div>

                  {/* 3 — switch role */}
                  <motion.div variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0 } }} className="flex flex-col gap-1 border-b border-line/40 py-4">
                    <p className="font-sans text-[14px] font-semibold text-ink">Switch role</p>
                    {PERSONAS.map((p) => (
                      <button
                        key={p.role}
                        type="button"
                        onClick={() => switchRole(p.role)}
                        className="group flex items-center justify-between gap-3 rounded-[2px] px-2 py-2.5 text-left transition-colors hover:bg-sand"
                      >
                        <span className="flex items-center gap-3">
                          <span className="flex h-7 w-7 items-center justify-center bg-petrol font-mono text-[11px] font-medium text-ivory">
                            {p.initials}
                          </span>
                          <span>
                            <span className="block font-sans text-[13px] font-medium text-ink">
                              {p.name}
                              {p.role === role && <span className="ml-2 font-mono text-[10px] text-copper">● current</span>}
                            </span>
                            <span className="data-s text-muted">{p.detail}</span>
                          </span>
                        </span>
                        <span className="font-sans text-[12px] font-semibold text-petrol opacity-0 transition-opacity group-hover:opacity-100">
                          Enter as →
                        </span>
                      </button>
                    ))}
                  </motion.div>

                  {/* 4 — watermark (locked on) */}
                  <motion.div variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0 } }} className="flex flex-col gap-2 border-b border-line/40 py-4 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                      <p className="font-sans text-[14px] font-semibold text-ink">Demo watermark</p>
                      <p className="mt-1 max-w-[520px] font-sans text-[12px] leading-[1.5] text-muted">
                        The DEMONSTRATOR watermark is a condition of the demonstration build and
                        cannot be removed.
                      </p>
                    </div>
                    <span className="relative inline-flex h-5 w-9 shrink-0 cursor-not-allowed items-center rounded-full bg-petrol">
                      <span className="absolute right-0.5 h-4 w-4 rounded-full bg-ivory" />
                    </span>
                  </motion.div>

                  {/* 5 — presentation mode */}
                  <motion.div variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0 } }} className="flex flex-col gap-2 py-4 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                      <p className="font-sans text-[14px] font-semibold text-ink">Presentation mode</p>
                      <p className="mt-1 max-w-[520px] font-sans text-[12px] leading-[1.5] text-muted">
                        Enlarges the base font by 12%, tucks filter bars behind an “Advanced”
                        disclosure, and pins the demo-script checklist while you present.
                      </p>
                    </div>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={presentation}
                      onClick={() => setPresentation((p) => !p)}
                      className={cn(
                        'relative inline-flex h-5 w-9 shrink-0 items-center rounded-full transition-colors',
                        presentation ? 'bg-petrol' : 'bg-line/60',
                      )}
                    >
                      <span
                        className={cn(
                          'absolute h-4 w-4 rounded-full bg-ivory transition-all',
                          presentation ? 'right-0.5' : 'left-0.5',
                        )}
                      />
                    </button>
                  </motion.div>
                </motion.section>
              </div>
            )}

            {/* ------------------------------------------------- Tab 5 — About */}
            {tab === 'about' && (
              <section className="rounded-[2px] border border-line/60 bg-ivory p-6">
                <div className="flex items-center gap-3">
                  <img src="/logo-mark.svg" alt="" className="h-10 w-10" />
                  <div>
                    <p className="font-display text-[28px] leading-none text-ink">ECO ENGINE</p>
                    <p className="data-s mt-1 text-muted">MRV demonstrator v0.9 — Stage 1</p>
                  </div>
                </div>
                <div className="mt-6 flex flex-col">
                  {[
                    ['Company', `${COMPANY.name} · ${COMPANY.rc}`],
                    ['Incorporated', `${COMPANY.incorporated} · ${COMPANY.city}`],
                    ['Purpose', 'Built for demonstration to the National Council on Climate Change, grant juries and fellowship panels.'],
                  ].map(([k, v]) => (
                    <div key={k} className="flex flex-col gap-1 border-b border-line/40 py-3 sm:flex-row sm:items-center sm:justify-between">
                      <span className="kicker text-muted">{k}</span>
                      <span className="max-w-[480px] font-sans text-[14px] text-ink sm:text-right">{v}</span>
                    </div>
                  ))}
                  <div className="flex flex-col gap-1 border-b border-line/40 py-3 sm:flex-row sm:items-center sm:justify-between">
                    <span className="kicker text-muted">Build hash</span>
                    <HashChip hash={demoHash('ECO-ENGINE-demonstrator-v0.9-stage-1')} />
                  </div>
                </div>
                <p className="data-s mt-4 text-muted">
                  All entities, figures and documents are demonstration data.
                </p>
              </section>
            )}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* presentation mode — pinned demo-script checklist (right-docked) */}
      <AnimatePresence>
        {presentation && (
          <motion.aside
            initial={{ x: 40, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: 40, opacity: 0 }}
            transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
            className="fixed right-4 top-24 z-40 w-[280px] rounded-[2px] border border-copper/50 bg-ivory p-4 shadow-panel"
          >
            <p className="kicker text-copper">Demo script — Annex A</p>
            <div className="mt-3 flex flex-col gap-2.5">
              {DEMO_SCRIPT_STEPS.map((step, i) => (
                <div key={step} className="flex items-center gap-2.5">
                  <span
                    className={cn(
                      'flex h-4 w-4 shrink-0 items-center justify-center rounded-[2px]',
                      scriptTicks[i] ? 'bg-petrol' : 'border border-line',
                    )}
                  >
                    {scriptTicks[i] && (
                      <motion.span
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ duration: 0.3 }}
                      >
                        <Check className="h-3 w-3 text-ivory" strokeWidth={3} />
                      </motion.span>
                    )}
                  </span>
                  <span className={cn('font-sans text-[12px]', scriptTicks[i] ? 'text-ink' : 'text-muted')}>
                    {step}
                  </span>
                </div>
              ))}
            </div>
            <p className="data-s mt-3 text-muted">Ticks follow live demo state.</p>
          </motion.aside>
        )}
      </AnimatePresence>

      {/* reset confirmation modal */}
      <AnimatePresence>
        {confirmReset && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25 }}
              onClick={() => setConfirmReset(false)}
              className="fixed inset-0 z-50 bg-petrol-deep/60 backdrop-blur-[4px]"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.97 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.97 }}
              transition={{ duration: 0.25 }}
              role="dialog"
              aria-modal="true"
              className="fixed left-1/2 top-1/2 z-50 w-[min(560px,calc(100vw-40px))] -translate-x-1/2 -translate-y-1/2 rounded-[2px] border border-line bg-ivory p-6"
            >
              <div className="flex items-start gap-3">
                <TriangleAlert className="mt-0.5 h-5 w-5 shrink-0 text-alert" strokeWidth={1.75} />
                <div>
                  <p className="kicker text-muted">Reset demonstration data</p>
                  <h3 className="mt-2 font-sans text-[18px] font-semibold text-ink">
                    Restore the seeded scenario?
                  </h3>
                </div>
              </div>
              <p className="mt-3 font-sans text-[13px] leading-[1.6] text-muted">
                Restores the seeded scenario: 2 facilities, 12 months of records, the March flare
                spike, the February identical-values query, and the pending June uploads. All demo
                state you changed will be discarded.
              </p>
              <div className="mt-6 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setConfirmReset(false)}
                  className="rounded-[2px] border border-ink/30 px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ink transition-all duration-200 hover:-translate-y-px hover:border-ink hover:bg-sand"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={doReset}
                  className="rounded-[2px] border border-alert px-[18px] py-[10px] font-sans text-[13px] font-semibold text-alert transition-all duration-200 hover:-translate-y-px hover:bg-alert hover:text-ivory"
                >
                  Reset demo data
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* resetting overlay — chain redraw */}
      <AnimatePresence>
        {resetting && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex items-center justify-center bg-petrol-deep/70 backdrop-blur-[4px]"
          >
            <div className="w-[320px] rounded-[2px] border border-ivory/15 bg-petrol-deep p-6">
              <p className="kicker text-copper-light">Restoring scenario</p>
              <div className="mt-4 flex items-center gap-2">
                {Array.from({ length: 8 }).map((_, i) => (
                  <motion.span
                    key={i}
                    className="h-2 w-2 rounded-[1px] bg-copper"
                    initial={{ opacity: 0.15, scale: 0.8 }}
                    animate={{ opacity: [0.15, 1, 0.15], scale: [0.8, 1, 0.8] }}
                    transition={{ duration: 1.5, delay: i * 0.12, repeat: Infinity }}
                  />
                ))}
              </div>
              <motion.div
                className="mt-4 h-px origin-left bg-copper-light"
                initial={{ scaleX: 0 }}
                animate={{ scaleX: 1 }}
                transition={{ duration: 1.5, ease: [0.22, 1, 0.36, 1] }}
              />
              <p className="data-s mt-3 text-ivory/60">reseeding hash chain…</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
