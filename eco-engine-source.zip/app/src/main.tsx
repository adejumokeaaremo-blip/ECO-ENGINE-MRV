import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.tsx'

// No <React.StrictMode> — it double-runs canvas/WebGL effects (react-dev.md).
createRoot(document.getElementById('root')!).render(<App />)
