import { cn } from '@/lib/utils'

/**
 * The ledger rule (design.md §4 signature motif):
 * a 1px horizontal hairline with a small 6×6px copper square tick at its left end.
 */
export default function LedgerRule({
  dark = false,
  className,
}: {
  dark?: boolean
  className?: string
}) {
  return (
    <div className={cn('flex items-center', className)} aria-hidden="true">
      <span className="h-[6px] w-[6px] shrink-0 bg-copper" />
      <span className={cn('h-px w-full', dark ? 'bg-ivory/15' : 'bg-line/60')} />
    </div>
  )
}
