import type { ReactNode } from 'react'
import { cn } from '@/lib/utils'

/**
 * Data table primitives (design.md §6.8): kicker headers with hairline rule,
 * 44px rows with hairline row rules, mono numerals, hover sand→ivory shift with
 * a 2px copper left tick, ledger empty state.
 * Compose with DataTableHead / DataTableRow / DataTableCell, or pass children.
 */
export default function DataTable({
  children,
  className,
}: {
  children: ReactNode
  className?: string
}) {
  return (
    <div className={cn('w-full overflow-x-auto', className)}>
      <table className="w-full border-collapse text-left">{children}</table>
    </div>
  )
}

export function DataTableHead({
  columns,
  className,
}: {
  columns: ReactNode[]
  className?: string
}) {
  return (
    <thead className={className}>
      <tr className="border-b border-line">
        {columns.map((c, i) => (
          <th
            key={i}
            scope="col"
            className="kicker py-3 pr-4 font-semibold text-muted last:pr-0"
          >
            {c}
          </th>
        ))}
      </tr>
    </thead>
  )
}

export function DataTableRow({
  children,
  className,
  onClick,
}: {
  children: ReactNode
  className?: string
  onClick?: () => void
}) {
  return (
    <tr
      onClick={onClick}
      className={cn(
        'group relative border-b border-line/40 transition-colors duration-150',
        'hover:bg-ivory',
        onClick && 'cursor-pointer',
        /* 2px copper left tick slides in on hover */
        'before:absolute before:left-0 before:top-0 before:h-full before:w-[2px] before:bg-copper before:opacity-0 before:transition-opacity before:duration-150 hover:before:opacity-100',
        className,
      )}
    >
      {children}
    </tr>
  )
}

export function DataTableCell({
  children,
  mono = true,
  className,
}: {
  children: ReactNode
  mono?: boolean
  className?: string
}) {
  return (
    <td
      className={cn(
        'min-h-[44px] py-3 pr-4 align-middle last:pr-0',
        mono ? 'font-mono text-[13px] leading-[1.45] text-ink' : 'font-sans text-[13px] text-ink',
        className,
      )}
    >
      {children}
    </td>
  )
}

/** Ledger empty state (§6.8): serif H3 + Body S guidance + primary action. */
export function DataTableEmpty({
  title = 'Nothing on the record yet.',
  guidance,
  action,
  colSpan = 1,
}: {
  title?: string
  guidance?: string
  action?: ReactNode
  colSpan?: number
}) {
  return (
    <tr>
      <td colSpan={colSpan} className="py-16 text-center">
        <p className="font-display text-[20px] text-ink">{title}</p>
        {guidance && <p className="mx-auto mt-2 max-w-[420px] font-sans text-[13px] text-muted">{guidance}</p>}
        {action && <div className="mt-6 flex justify-center">{action}</div>}
      </td>
    </tr>
  )
}
