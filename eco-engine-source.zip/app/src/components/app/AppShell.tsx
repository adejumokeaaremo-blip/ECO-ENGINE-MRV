import { useMemo, useState } from 'react'
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router'
import { Bell, ChevronDown, Settings, LogOut, RotateCcw } from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { cn } from '@/lib/utils'
import { FACILITIES, PERSONAS, COMPANY, type Persona } from '@/lib/demo-data'
import { useRole, useSubmissions } from '@/lib/store'

/* ------------------------------------------------------- nav sets (§7) */

interface NavItem {
  num: string
  label: string
  to: string
  /** matcher for active state; defaults to exact `to` prefix */
  match?: string
}
interface NavGroup {
  group: string
  items: NavItem[]
}

const NAV_SETS: Record<Persona['role'], NavGroup[]> = {
  operator: [
    {
      group: 'Reporting',
      items: [
        { num: '01', label: 'Dashboard', to: '/operator', match: '/operator' },
        { num: '02', label: 'Facility', to: '/operator/facility' },
        { num: '03', label: 'Monitoring Plan', to: '/operator/plan' },
        { num: '04', label: 'Uploads', to: '/operator/uploads' },
      ],
    },
    {
      group: 'Quality',
      items: [{ num: '05', label: 'DQI', to: '/operator/dqi' }],
    },
    {
      group: 'Outputs',
      items: [
        { num: '06', label: 'Disclosure Packs', to: '/operator/disclosures' },
        { num: '07', label: 'Audit Trail', to: '/audit' },
      ],
    },
  ],
  verifier: [
    {
      group: 'Workspace',
      items: [
        { num: '01', label: 'Queue', to: '/verifier', match: '/verifier' },
        { num: '02', label: 'Decisions Log', to: '/audit?view=decisions', match: '/audit' },
        { num: '03', label: 'Audit Trail', to: '/audit', match: '__audit_trail__' },
      ],
    },
  ],
  regulator: [
    {
      group: 'Oversight',
      items: [
        { num: '01', label: 'National Dashboard', to: '/regulator', match: '/regulator' },
        { num: '02', label: 'Compliance Calendar', to: '/regulator/compliance' },
        { num: '03', label: 'Facilities', to: '/regulator/facilities/FAC-RIV-004', match: '/regulator/facilities' },
        { num: '04', label: 'Audit Trail', to: '/audit' },
      ],
    },
  ],
  compiler: [
    {
      group: 'Inventory',
      items: [
        { num: '01', label: 'Export Builder', to: '/compiler', match: '/compiler' },
        { num: '02', label: 'Package History', to: '/compiler?view=history', match: '__history__' },
        { num: '03', label: 'Audit Trail', to: '/audit' },
      ],
    },
  ],
}

const ROLE_LABELS: Record<Persona['role'], string> = {
  operator: 'OPERATOR',
  verifier: 'VERIFIER',
  regulator: 'REGULATOR · NCCC',
  compiler: 'COMPILER · NIMO',
}

const SECTION_LABELS: Record<string, string> = {
  operator: 'OPERATOR',
  verifier: 'VERIFIER',
  regulator: 'REGULATOR',
  compiler: 'COMPILER',
  audit: 'AUDIT TRAIL',
  settings: 'SETTINGS',
  facility: 'FACILITY',
  facilities: 'FACILITIES',
  plan: 'MONITORING PLAN',
  uploads: 'UPLOADS',
  dqi: 'DQI',
  disclosures: 'DISCLOSURE PACKS',
  review: 'REVIEW',
  compliance: 'COMPLIANCE CALENDAR',
}

/* ------------------------------------------------------------- AppShell */

export default function AppShell() {
  const { role, persona, setRole, markTourSeen } = useRole()
  const submissions = useSubmissions()
  const navigate = useNavigate()
  const location = useLocation()
  const [facilityId, setFacilityId] = useState(FACILITIES[0].id)

  const unread = useMemo(() => submissions.some((s) => s.status === 'Pending'), [submissions])
  const navGroups = NAV_SETS[role]

  const crumbs = location.pathname
    .split('/')
    .filter(Boolean)
    .slice(0, 2)
    .map((seg) => SECTION_LABELS[seg] ?? seg.toUpperCase())

  const switchRole = (p: Persona) => {
    setRole(p.role)
    navigate(p.home)
  }

  const replayTour = () => {
    markTourSeen(role) // keep record; page agents listen for the replay event
    window.dispatchEvent(new CustomEvent('ecoengine:replay-tour', { detail: { role } }))
  }

  const isActive = (item: NavItem) => {
    const match = item.match ?? item.to
    if (match.startsWith('__')) return false
    if (match === '/operator' || match === '/verifier' || match === '/regulator' || match === '/compiler')
      return location.pathname === match
    return location.pathname.startsWith(match)
  }

  return (
    <div className="min-h-[100dvh] bg-sand text-ink">
      {/* 6.1 — demo watermark strip (persistent, cannot be dismissed) */}
      <div className="sticky top-0 z-50 flex h-8 items-center justify-center bg-petrol-deep">
        <p className="font-sans text-[11px] font-semibold uppercase tracking-kicker text-copper-light">
          Demonstrator — demonstration data · not an official record
        </p>
        <button
          type="button"
          onClick={replayTour}
          className="absolute right-4 font-sans text-[11px] uppercase tracking-[0.12em] text-ivory/60 transition-colors hover:text-ivory"
        >
          Replay guided tour
        </button>
      </div>

      <div className="flex">
        {/* 6.2 — sidebar (248px, petrol-deep) */}
        <aside className="sticky top-8 flex h-[calc(100dvh-2rem)] w-[248px] shrink-0 flex-col bg-petrol-deep">
          <div className="border-b border-ivory/10 px-6 py-5">
            <Link to="/" className="flex items-center gap-2.5">
              <img src="/logo-mark.svg" alt="" className="h-7 w-7" />
              <span className="flex flex-col">
                <span className="font-display text-[22px] leading-none text-ivory">ECO ENGINE</span>
                <span className="mt-1 font-sans text-[9px] font-semibold uppercase tracking-kicker text-ivory/50">
                  MRV System
                </span>
              </span>
            </Link>
          </div>

          <nav className="flex-1 overflow-y-auto px-0 py-4">
            {navGroups.map((g) => (
              <div key={g.group} className="mb-4">
                <p className="px-6 pb-2 font-sans text-[10px] font-semibold uppercase tracking-kicker text-ivory/40">
                  {g.group}
                </p>
                {g.items.map((item) => (
                  <NavLink
                    key={item.num + item.label}
                    to={item.to}
                    className={cn(
                      'relative flex items-baseline gap-3 px-6 py-2.5 transition-colors duration-150',
                      isActive(item)
                        ? 'bg-ivory/[0.06] text-ivory before:absolute before:left-0 before:top-0 before:h-full before:w-[2px] before:bg-copper'
                        : 'text-ivory/60 hover:bg-ivory/[0.04] hover:text-ivory',
                    )}
                  >
                    <span className="font-mono text-[11px] text-copper-light">{item.num}</span>
                    <span className="font-sans text-[14px]">{item.label}</span>
                  </NavLink>
                ))}
              </div>
            ))}
          </nav>

          <div className="border-t border-ivory/10 px-6 py-4">
            <p className="data-s text-ivory/40">
              {COMPANY.name} · {COMPANY.rc}
            </p>
            <p className="mt-2 flex items-center gap-2">
              <span className="h-2 w-2 shrink-0 rounded-full bg-petrol" style={{ backgroundColor: '#2E8B9A' }} />
              <span className="data-s text-ivory/60">Audit chain intact</span>
            </p>
          </div>
        </aside>

        {/* main column */}
        <div className="flex min-w-0 flex-1 flex-col">
          {/* 6.2 — top bar (56px, ivory, hairline bottom rule) */}
          <header className="sticky top-8 z-40 flex h-14 items-center gap-4 border-b border-line/60 bg-ivory px-6">
            <p className="kicker text-muted">
              {crumbs.map((c, i) => (
                <span key={i}>
                  {i > 0 && <span className="mx-2 text-line">/</span>}
                  {c}
                </span>
              ))}
            </p>

            {/* centre: facility context switcher (operator) */}
            <div className="flex flex-1 justify-center">
              {role === 'operator' && (
                <DropdownMenu>
                  <DropdownMenuTrigger className="flex items-center gap-2 rounded-[2px] border border-line/60 px-3 py-1.5 font-sans text-[12px] text-ink transition-colors hover:border-ink">
                    <span className="font-mono text-[11px] text-muted">{facilityId}</span>
                    <span className="max-w-[220px] truncate">
                      {FACILITIES.find((f) => f.id === facilityId)?.name}
                    </span>
                    <ChevronDown className="h-3.5 w-3.5 text-muted" strokeWidth={1.75} />
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="center" className="w-[320px] rounded-[2px]">
                    <DropdownMenuLabel className="kicker text-muted">Facility context</DropdownMenuLabel>
                    {FACILITIES.map((f) => (
                      <DropdownMenuItem
                        key={f.id}
                        onSelect={() => setFacilityId(f.id)}
                        className="flex flex-col items-start gap-0.5"
                      >
                        <span className="font-sans text-[13px] font-medium">{f.name}</span>
                        <span className="data-s text-muted">
                          {f.id} · {f.state}
                        </span>
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </div>

            {/* right: role switcher, bell, user menu */}
            <DropdownMenu>
              <DropdownMenuTrigger className="flex items-center gap-2 rounded-[2px] border border-copper/60 px-3 py-1.5 font-sans text-[11px] font-semibold uppercase tracking-[0.12em] text-copper transition-colors hover:bg-copper hover:text-ivory">
                Viewing as: {ROLE_LABELS[role]}
                <ChevronDown className="h-3.5 w-3.5" strokeWidth={1.75} />
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-[320px] rounded-[2px]">
                <DropdownMenuLabel className="kicker text-muted">
                  Demo personas — switch seat
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                {PERSONAS.map((p) => (
                  <DropdownMenuItem
                    key={p.role}
                    onSelect={() => switchRole(p)}
                    className="flex flex-col items-start gap-0.5"
                  >
                    <span className="font-sans text-[13px] font-medium">
                      {p.name}
                      {p.role === role && <span className="ml-2 font-mono text-[10px] text-copper">● current</span>}
                    </span>
                    <span className="data-s text-muted">{p.detail}</span>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            <button
              type="button"
              aria-label="Notifications"
              className="relative rounded-[2px] p-2 text-muted transition-colors hover:text-ink"
            >
              <Bell className="h-4 w-4" strokeWidth={1.75} />
              {unread && <span className="absolute right-1.5 top-1.5 h-1.5 w-1.5 rounded-full bg-copper" />}
            </button>

            <DropdownMenu>
              <DropdownMenuTrigger className="flex items-center gap-2.5 rounded-[2px] py-1 pl-1 pr-2 transition-colors hover:bg-sand">
                <span className="flex h-7 w-7 items-center justify-center bg-petrol font-mono text-[11px] font-medium text-ivory">
                  {persona.initials}
                </span>
                <span className="hidden flex-col items-start leading-tight md:flex">
                  <span className="font-sans text-[13px] font-medium text-ink">{persona.name}</span>
                  <span className="font-sans text-[11px] text-muted">{persona.title}</span>
                </span>
                <ChevronDown className="h-3.5 w-3.5 text-muted" strokeWidth={1.75} />
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-[280px] rounded-[2px]">
                <DropdownMenuLabel className="flex flex-col gap-0.5">
                  <span className="font-sans text-[13px] font-medium">{persona.name}</span>
                  <span className="data-s font-normal text-muted">{persona.detail}</span>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onSelect={() => navigate('/settings')}>
                  <Settings className="mr-2 h-3.5 w-3.5" strokeWidth={1.75} />
                  Settings
                </DropdownMenuItem>
                <DropdownMenuItem onSelect={replayTour}>
                  <RotateCcw className="mr-2 h-3.5 w-3.5" strokeWidth={1.75} />
                  Replay guided tour
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onSelect={() => navigate('/')}>
                  <LogOut className="mr-2 h-3.5 w-3.5" strokeWidth={1.75} />
                  Exit demonstrator
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </header>

          <main className="mx-auto w-full max-w-[1200px] flex-1 px-8 py-8">
            <Outlet />
          </main>
        </div>
      </div>
    </div>
  )
}
