import { cn } from '@/lib/utils'

/**
 * Status chips (design.md §6.6): 10px Liter 600 uppercase, 0.12em, 2px radius.
 * Semantic mapping (§2): verified→petrol, pending/AI→copper, rejected→alert, neutral→ink.
 */
export type StatusKind = 'verified' | 'pending' | 'rejected' | 'neutral'

const KIND_CLASSES: Record<StatusKind, string> = {
  verified: 'bg-petrol text-ivory',
  pending: 'border border-copper text-copper bg-transparent',
  rejected: 'bg-alert text-ivory',
  neutral: 'bg-ink/10 text-ink',
}

/** Map a free-form status string to a chip kind. */
export function statusKind(status: string): StatusKind {
  const s = status.toLowerCase()
  if (/(verif|approv|accept|report)/.test(s)) return 'verified'
  if (/(reject|late|anomal|fail|overdue)/.test(s)) return 'rejected'
  if (/(ai|pend|quer|draft|due)/.test(s)) return 'pending'
  return 'neutral'
}

export default function StatusChip({
  status,
  kind,
  className,
}: {
  status: string
  kind?: StatusKind
  className?: string
}) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-[2px] px-[10px] py-[6px] font-sans text-[10px] font-semibold uppercase tracking-chip',
        KIND_CLASSES[kind ?? statusKind(status)],
        className,
      )}
    >
      {status}
    </span>
  )
}
