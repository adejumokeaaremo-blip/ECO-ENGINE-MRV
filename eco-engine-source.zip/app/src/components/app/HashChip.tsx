import { Copy } from 'lucide-react'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'
import { truncateHash } from '@/lib/store'

/**
 * Hash chip (design.md §6.11): IBM Plex Mono 11px muted-on-ink/5% chip with
 * truncated hash 0x9f2c…e41a + copy icon. Click copies full hash and toasts
 * "Hash copied — verify against chain." `expanded` shows the full hash (audit page).
 */
export default function HashChip({
  hash,
  expanded = false,
  className,
}: {
  hash: string
  expanded?: boolean
  className?: string
}) {
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(hash)
    } catch {
      /* clipboard unavailable — still surface the toast for the demo */
    }
    toast('Hash copied — verify against chain.')
  }
  return (
    <button
      type="button"
      onClick={copy}
      title={hash}
      className={cn(
        'inline-flex items-center gap-1.5 rounded-[2px] bg-ink/5 px-2 py-1 font-mono text-[11px] tracking-[0.02em] text-muted transition-colors duration-200 hover:bg-ink/10 hover:text-ink',
        expanded && 'w-full justify-between',
        className,
      )}
    >
      <span className={cn(expanded && 'break-all text-left')}>
        {expanded ? hash : truncateHash(hash)}
      </span>
      <Copy className="h-3 w-3 shrink-0" strokeWidth={1.75} />
    </button>
  )
}
