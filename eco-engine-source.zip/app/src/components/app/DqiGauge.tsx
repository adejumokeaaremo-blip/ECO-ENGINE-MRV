import { useEffect, useRef, useState } from 'react'
import { cn } from '@/lib/utils'

/**
 * DQI gauge (design.md §6.10): semicircular arc, 160–220px.
 * Track line; value arc petrol (≥80), copper (60–79), alert (<60).
 * Centre Oranienbaum numeral + "DQI" kicker; ticks at 0/25/50/75/100.
 * Arc animates from 0 with stroke-dashoffset over 1.2s when in view.
 */
export default function DqiGauge({
  value,
  size = 200,
  dark = false,
  className,
}: {
  value: number // 0–100
  size?: number
  dark?: boolean
  className?: string
}) {
  const clamped = Math.max(0, Math.min(100, value))
  const color = clamped >= 80 ? '#0F4C5C' : clamped >= 60 ? '#B5651D' : '#A63D2F'
  const r = 80
  const cx = 100
  const cy = 100
  const arcLen = Math.PI * r // semicircle length
  const [progress, setProgress] = useState(() =>
    typeof window !== 'undefined' &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches
      ? 1
      : 0,
  )
  const ref = useRef<SVGSVGElement | null>(null)
  const started = useRef(false)

  useEffect(() => {
    const el = ref.current
    if (!el) return
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
    const io = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !started.current) {
          started.current = true
          const t0 = performance.now()
          const tick = (now: number) => {
            const p = Math.min(1, (now - t0) / 1200)
            setProgress(1 - Math.pow(1 - p, 3))
            if (p < 1) requestAnimationFrame(tick)
          }
          requestAnimationFrame(tick)
          io.disconnect()
        }
      },
      { threshold: 0.4 },
    )
    io.observe(el)
    return () => io.disconnect()
  }, [])

  const shown = clamped * progress
  const dash = (shown / 100) * arcLen
  const trackColor = dark ? 'rgba(245,240,230,0.18)' : '#C9BBA2'

  return (
    <div className={cn('inline-flex flex-col items-center', className)} style={{ width: size }}>
      <svg
        ref={ref}
        viewBox="0 0 200 116"
        style={{ width: size, height: (size * 116) / 200 }}
        role="img"
        aria-label={`DQI ${clamped} of 100`}
      >
        {/* track */}
        <path
          d={`M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}`}
          fill="none"
          stroke={trackColor}
          strokeWidth="6"
        />
        {/* value arc */}
        <path
          d={`M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}`}
          fill="none"
          stroke={color}
          strokeWidth="6"
          strokeDasharray={`${dash} ${arcLen}`}
        />
        {/* tick labels 0/25/50/75/100 */}
        {[0, 25, 50, 75, 100].map((t) => {
          const angle = Math.PI * (1 - t / 100)
          const x = cx + Math.cos(angle) * (r + 14)
          const y = cy - Math.sin(angle) * (r + 14)
          return (
            <text
              key={t}
              x={x}
              y={y + 3}
              textAnchor="middle"
              className="fill-current"
              fontSize="9"
              fontFamily="'IBM Plex Mono', monospace"
              opacity={dark ? 0.6 : 0.55}
              color={dark ? '#F5F0E6' : '#5F7168'}
            >
              {t}
            </text>
          )
        })}
        <text
          x={cx}
          y={cy - 14}
          textAnchor="middle"
          fontSize="44"
          fontFamily="Oranienbaum, Georgia, serif"
          fill={dark ? '#F5F0E6' : '#1C2B28'}
        >
          {Math.round(shown)}
        </text>
        <text
          x={cx}
          y={cy + 4}
          textAnchor="middle"
          fontSize="9"
          letterSpacing="2"
          fontFamily="Liter, sans-serif"
          fontWeight="600"
          fill={dark ? 'rgba(245,240,230,0.55)' : '#5F7168'}
        >
          DQI
        </text>
      </svg>
    </div>
  )
}
