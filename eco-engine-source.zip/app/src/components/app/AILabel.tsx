import { Info } from 'lucide-react'
import { cn } from '@/lib/utils'

/**
 * The AI label (design.md §6.7 — signature component, non-negotiable).
 * Copper variant: 6×6px copper square + "AI ESTIMATE — PENDING HUMAN VERIFICATION".
 * Teal variant once accepted: "VERIFIED — accepted by [name], [timestamp]".
 */
export default function AILabel({
  verified = false,
  verifierName,
  timestamp,
  size = 'sm',
  className,
}: {
  verified?: boolean
  verifierName?: string
  timestamp?: string
  size?: 'sm' | 'lg'
  className?: string
}) {
  if (verified) {
    return (
      <span
        className={cn(
          'inline-flex items-center gap-2 font-sans font-semibold uppercase tracking-ai-label text-petrol',
          size === 'lg' ? 'text-[12px]' : 'text-[10px]',
          className,
        )}
      >
        <span className="h-[6px] w-[6px] shrink-0 bg-petrol" />
        Verified{verifierName ? ` — accepted by ${verifierName}` : ''}
        {timestamp ? `, ${timestamp}` : ''}
      </span>
    )
  }
  return (
    <span
      className={cn(
        'inline-flex items-center gap-2 font-sans font-semibold uppercase tracking-ai-label text-copper',
        size === 'lg' ? 'text-[12px]' : 'text-[10px]',
        className,
      )}
    >
      <span data-ai-square className="h-[6px] w-[6px] shrink-0 bg-copper" />
      AI Estimate — Pending Human Verification
      <Info className={cn('shrink-0', size === 'lg' ? 'h-4 w-4' : 'h-3 w-3')} strokeWidth={1.75} />
    </span>
  )
}
