import { useEffect, useRef, useState } from 'react'
import { cn } from '@/lib/utils'

function useCountUp(target: number, duration = 1200, decimals = 0) {
  const [value, setValue] = useState(() =>
    typeof window !== 'undefined' &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches
      ? target
      : 0,
  )
  const ref = useRef<HTMLSpanElement | null>(null)
  const started = useRef(false)
  useEffect(() => {
    const el = ref.current
    if (!el) return
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
    const io = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !started.current) {
          started.current = true
          const t0 = performance.now()
          const tick = (now: number) => {
            const p = Math.min(1, (now - t0) / duration)
            const eased = 1 - Math.pow(1 - p, 3)
            setValue(Number((target * eased).toFixed(decimals)))
            if (p < 1) requestAnimationFrame(tick)
          }
          requestAnimationFrame(tick)
          io.disconnect()
        }
      },
      { threshold: 0.4 },
    )
    io.observe(el)
    return () => io.disconnect()
  }, [target, duration, decimals])
  return [value, ref] as const
}

/**
 * KPI stat block (design.md §6.9): kicker label → Oranienbaum numeral →
 * Body S sub-line with optional delta arrow (▲ teal / ▼ alert). Count-up 1.2s.
 */
export default function KpiStat({
  label,
  value,
  format,
  suffix,
  sub,
  delta,
  deltaDirection,
  dark = false,
  className,
}: {
  label: string
  value: number
  /** custom formatter; defaults to toLocaleString */
  format?: (v: number) => string
  suffix?: string
  sub?: string
  delta?: string
  deltaDirection?: 'up' | 'down'
  dark?: boolean
  className?: string
}) {
  const [animated, ref] = useCountUp(value)
  const display = format ? format(animated) : Math.round(animated).toLocaleString('en-US')
  return (
    <div className={cn('flex flex-col gap-2', className)}>
      <span className={cn('kicker', dark ? 'text-ivory/50' : 'text-muted')}>{label}</span>
      <span
        ref={ref}
        className={cn(
          'font-display leading-none',
          dark ? 'text-ivory' : 'text-ink',
          'text-[56px] md:text-[72px]',
        )}
      >
        {display}
        {suffix ? <span className="text-[0.5em]">{suffix}</span> : null}
      </span>
      {(sub || delta) && (
        <span className={cn('font-sans text-[13px] leading-[1.5]', dark ? 'text-ivory/60' : 'text-muted')}>
          {delta && (
            <span
              className={cn(
                'mr-2 font-mono text-[12px]',
                deltaDirection === 'down' ? 'text-alert' : 'text-petrol',
                dark && deltaDirection !== 'down' && 'text-copper-light',
              )}
            >
              {deltaDirection === 'down' ? '▼' : '▲'} {delta}
            </span>
          )}
          {sub}
        </span>
      )}
    </div>
  )
}
