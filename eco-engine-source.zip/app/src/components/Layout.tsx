import { Outlet } from 'react-router'
import Navbar from './Navbar'
import Footer from './Footer'

/**
 * Landing layout wrapper. Demo strip (first thin bar, home.md §0) +
 * overlay Navbar (fixed, transparent over hero) + page + Footer.
 * The full-bleed hero opts out of any nav offset inside the page.
 */
export default function Layout() {
  return (
    <div className="min-h-[100dvh] bg-petrol-deep text-ivory">
      {/* Demo strip — 32px, petrol-darkest, first thin bar (home.md §0) */}
      <div className="flex h-8 items-center justify-center bg-petrol-darkest">
        <p className="font-sans text-[10px] font-semibold uppercase tracking-kicker text-copper-light">
          Demonstrator — demonstration data · not an official record
        </p>
      </div>
      <Navbar />
      <Outlet />
      <Footer />
    </div>
  )
}
