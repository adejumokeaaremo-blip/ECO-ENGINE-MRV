/**
 * Landing footer (design.md §6.4): petrol-deep, top hairline, three columns
 * (wordmark / contact / founders) + bottom row.
 */
export default function Footer() {
  return (
    <footer id="contact" className="border-t border-ivory/10 bg-petrol-deep text-ivory">
      <div className="mx-auto grid max-w-[1280px] gap-12 px-8 py-16 max-md:px-5 md:grid-cols-3">
        <div>
          <div className="flex items-center gap-3">
            <img src="/logo-mark.svg" alt="" className="h-8 w-8" />
            <span className="font-display text-[20px] leading-none">ECO ENGINE</span>
          </div>
          <p className="mt-4 font-sans text-[13px] text-ivory/80">Nigeria&rsquo;s Climate-Data Rails</p>
          <p className="mt-3 font-mono text-[11px] leading-[1.6] tracking-[0.02em] text-ivory/50">
            RC 9666441 · Incorporated 8 July 2026
            <br />
            Abuja, FCT
          </p>
        </div>

        <div>
          <p className="kicker text-ivory/50">Contact</p>
          <p className="mt-4 font-sans text-[13px] leading-[1.7] text-ivory/80">
            hello@ecoengine.ng (demo)
            <br />
            4th Floor, Rivers House,
            <br />
            Central Business District, Abuja
            <br />
            <span className="text-ivory/50">(demo address)</span>
          </p>
        </div>

        <div>
          <p className="kicker text-ivory/50">Founders</p>
          <div className="mt-4 space-y-3">
            <p className="font-sans text-[13px] text-ivory/80">
              Adejumoke R. Aremo
              <span className="block text-[12px] text-ivory/60">Co-founder &amp; CEO</span>
            </p>
            <p className="font-sans text-[13px] text-ivory/80">
              Aroyehun A. Sunkanmi
              <span className="block text-[12px] text-ivory/60">Co-founder &amp; COO</span>
            </p>
          </div>
        </div>
      </div>

      <div className="border-t border-ivory/10">
        <div className="mx-auto flex max-w-[1280px] flex-wrap items-center justify-between gap-3 px-8 py-5 max-md:px-5">
          <p className="font-sans text-[12px] text-ivory/60">Private Infrastructure · National Standard</p>
          <p className="font-sans text-[11px] font-semibold uppercase tracking-kicker text-copper-light">
            Demonstrator — demonstration data
          </p>
          <p className="font-mono text-[11px] text-ivory/50">© 2026</p>
        </div>
      </div>
    </footer>
  )
}
