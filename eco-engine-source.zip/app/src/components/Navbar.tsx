import { useEffect, useState } from 'react'
import { Link } from 'react-router'
import { motion } from 'framer-motion'
import { cn } from '@/lib/utils'

const NAV_LINKS = [
  { label: 'The Gap', href: '#gap' },
  { label: 'The Method', href: '#method' },
  { label: 'Integrity', href: '#integrity' },
  { label: 'Roles', href: '#roles' },
  { label: 'Contact', href: '#contact' },
]

/**
 * Public landing navbar (design.md §6.3, home.md §0):
 * transparent over hero → petrol-deep + hairline ivory/10% rule after 40px
 * scroll (0.3s tween); slides down from −100% on load.
 */
export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <motion.header
      initial={{ y: '-100%' }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1], delay: 0.2 }}
      className={cn(
        'fixed inset-x-0 top-0 z-50 transition-[background-color,border-color] duration-300',
        scrolled ? 'border-b border-ivory/10 bg-petrol-deep' : 'border-b border-transparent bg-transparent',
      )}
    >
      <div className="mx-auto flex h-16 max-w-[1280px] items-center justify-between px-8 max-md:px-5">
        <Link to="/" className="flex items-center gap-3">
          <img src="/logo-mark.svg" alt="ECO ENGINE ledger glyph" className="h-8 w-8" />
          <span className="flex flex-col">
            <span className="font-display text-[20px] leading-none text-ivory">ECO ENGINE</span>
            <span className="mt-0.5 font-sans text-[9px] font-semibold uppercase tracking-kicker text-ivory/50">
              MRV System
            </span>
          </span>
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          {NAV_LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="link-sweep font-sans text-[13px] text-ivory/80 transition-colors hover:text-ivory"
            >
              {l.label}
            </a>
          ))}
        </nav>

        <a
          href="#roles"
          className="rounded-[2px] bg-copper px-[18px] py-[10px] font-sans text-[13px] font-semibold text-ivory transition-all duration-200 hover:-translate-y-px hover:bg-copper-light hover:text-ink"
        >
          Enter the demonstrator
        </a>
      </div>
    </motion.header>
  )
}
